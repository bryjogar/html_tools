#!/usr/bin/env python3
"""Report which layouts have actually been collected for a company.

CLI wrapper around doc_coverage.
"""
import sys
from doc_coverage import (
    REVIEW_LAYOUTS,
    SCOPE_LAYOUTS,
    coverage,
    collected_layouts,
    is_collected,
    db_path,
    main,
)

if __name__ == "__main__":
    main()