#!/usr/bin/env python3
"""Render a Hudu documentation-review article from evaluator output.

Deterministic. No model in the loop. Reads the same JSON that evaluate.py
emits and produces the HTML described in references/report-template.md.

Why this exists: rendering 500+ findings into HTML inside a model context is
slow and fragile. Collection, evaluation, and rendering are all mechanical and
belong in code. The model's only job is the prose judgment (C1/C2) and the
verdict paragraph, which it patches in afterwards.

Usage:
    python3 render.py <company_id> [--out FILE] [--verdict TEXT]

Writes .staging/<company_id>.html by default and prints the path.
"""
import json, os, subprocess, sys, html, collections, re

HERE = os.path.dirname(os.path.abspath(__file__))
STATE = os.environ.get("HUDU_STATE_DIR") or os.path.join(HERE, "..", "state")
STAGING = os.path.join(HERE, "..", ".staging")

from rubric import (
    LAYOUT_NAMES,
    GROUPS,
    REGISTRY,
    SEV_ORDER,
    SCOPE_ALL,
    SCOPE_LAYOUTS,
    TIER,
    layout_components,
    layout_out_of_scope_components,
)

# Components that read two layouts and report against the company.
CROSS_LAYOUT = {cid for cid, info in REGISTRY.items() if info.get("section") == "layout"}

# Components that get their own section at the end of the report. They are
# excluded from the per-layout tables so a finding is never drawn twice.
CROSS_CUTTING = {cid for cid, info in REGISTRY.items() if info.get("section") == "cutting"}


def tier_severities(tier):
    """Return set of severity strings to render for a given tier."""
    return {sev for sev, t in TIER.items() if t == tier}

STYLE_BLOCK = """<style>
.hdr{color:#5f6b7a;font-size:0.85rem;}
.tbl-detail{width:100%;border-collapse:collapse;font-size:0.82rem;margin-bottom:1.5rem;}
.tbl-detail th{text-align:left;padding:0.4rem 0.5rem;background:#f9fafb;font-size:0.72rem;text-transform:uppercase;color:#5f6b7a;border-bottom:1px solid #d9e0ea;}
.tbl-detail td{padding:0.4rem 0.5rem;border-bottom:1px solid #eef2f7;vertical-align:top;}
.tbl-detail th:first-child,.tbl-detail th:nth-child(2),.tbl-detail td:first-child,.tbl-detail td:nth-child(2){white-space:nowrap;}
.b{font-size:0.7rem;font-weight:700;padding:2px 6px;border-radius:4px;}
.c{background:#feecec;color:#b91c1c;}
.h{background:#fff5df;color:#b45309;}
.m{background:#eef2f7;color:#5f6b7a;}
.l{background:#f9fafb;color:#5f6b7a;}
.sub{font-weight:400;color:#5f6b7a;font-size:0.85rem;}
.ok{color:#15803d;font-size:0.85rem;margin:0.2rem 0 1rem;}
.prose{background:#f9fafb;border-left:3px solid #d9e0ea;padding:0.6rem 0.8rem;font-size:0.82rem;margin-bottom:1rem;}
.method{font-size:0.8rem;color:#5f6b7a;}
</style>"""

SEV_CLASS = {"Critical": "c", "High": "h", "Medium": "m", "Low": "l"}


def badge(text, style):
    """style is a (bg, fg) tuple or a class name."""
    if isinstance(style, str):
        return f'<span class="b {style}">{text}</span>'
    bg, fg = style
    return (f'<span style="background:{bg};color:{fg};font-size:0.7rem;'
            f'font-weight:700;padding:2px 6px;border-radius:4px;">{text}</span>')


def esc(v):
    """HTML-escape, then convert non-ASCII to numeric entities.

    The output is pure ASCII, so it renders correctly regardless of the
    charset the viewer assumes. Without this, an em dash (UTF-8 E2 80 94)
    read as Windows-1252 shows up as 'â€”' — the mojibake seen in the browser
    view and in Hudu.
    """
    s = html.escape(str(v if v is not None else ""))
    return "".join(ch if ord(ch) < 128 else f"&#{ord(ch)};" for ch in s)


def canon_detail(detail):
    """Normalize a detail string so identical problems group together.

    'Manufacturer missing (\'Unknown\'); Model missing (\'Unknown\')' and
    'Manufacturer missing (\'\'); Model missing (\'\')' are the same problem
    and should render as one row with two records listed.
    """
    import re
    d = re.sub(r"\s*\('[^']*'\)", "", detail)   # drop quoted values
    d = re.sub(r"\s*\([^)]*\)", "", d)          # drop parentheticals
    return d.strip()


def short_url(url):
    """Make an asset permalink relative to the Hudu host.

    https://kb.enabletech.com/a/pcpc-anynode-vm-05e671aea4bb
      -> /a/pcpc-anynode-vm-05e671aea4bb

    The slug is REQUIRED — dropping it 404s. The scheme and host are not:
    a relative link resolves correctly inside a Hudu article (verified by the
    client owner against a live draft). This saves ~5KB on a large report,
    which is the difference between fitting the API limit and not.
    """
    import re
    if not url:
        return url
    m = re.match(r"^https?://[^/]+(/.*)$", url)
    return m.group(1) if m else url


def natural_sort_key(s):
    """Sort strings with embedded integers naturally: 'I2' before 'I10'."""
    return [int(text) if text.isdigit() else text.lower()
            for text in re.split(r'(\d+)', str(s))]


def lookup_asset_url(company_id, asset_id):
    """Look up the Hudu URL for an asset from the state database."""
    import sqlite3
    path = os.path.join(STATE, f"{company_id}.sqlite")
    if not os.path.exists(path):
        return None
    try:
        con = sqlite3.connect(f"file:{os.path.abspath(path)}?mode=ro", uri=True)
    except Exception:
        con = sqlite3.connect(path)
    try:
        cur = con.cursor()
        row = cur.execute("SELECT hudu_url FROM assets WHERE company_id = ? AND id = ?",
                          (company_id, asset_id)).fetchone()
        if row and row[0]:
            return row[0]
    except Exception:
        pass
    finally:
        con.close()
    return None


def render_detail(f, company_id=None):
    """Render finding detail HTML, linking the first asset for X2."""
    det = f.get("detail", "")
    if f.get("component") == "X2":
        m = re.search(r"shared with (\d+)", det)
        if m:
            other_id = int(m.group(1))
            other_url = f.get("other_url")
            if not other_url and company_id:
                other_url = lookup_asset_url(company_id, other_id)
            if other_url:
                surl = short_url(other_url)
                prefix = esc(det[:m.start(1)])
                link_html = f'<a href="{esc(surl)}">{m.group(1)}</a>'
                suffix = esc(det[m.end(1):])
                return f"{prefix}{link_html}{suffix}"
    return esc(det)


def link(f):
    """Asset name as a permalink, or plain text when there is no URL."""
    name = esc(f.get("asset") or "(unknown)")
    url = short_url(f.get("hudu_url"))
    if url:
        return f'<a href="{esc(url)}">{name}</a>'
    return name


def load_data_from_db(company_id):
    """Load evaluation data from state database without re-evaluating."""
    import sqlite3
    path = os.path.join(STATE, f"{company_id}.sqlite")
    if not os.path.exists(path):
        return None
    try:
        con = sqlite3.connect(f"file:{os.path.abspath(path)}?mode=ro", uri=True)
    except Exception:
        con = sqlite3.connect(path)
    cur = con.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='layout_evaluations'")
    if not cur.fetchone():
        con.close()
        return None

    cur.execute("SELECT layout_id, data FROM layout_evaluations WHERE company_id = ?", (company_id,))
    rows = cur.fetchall()
    con.close()

    if len(rows) < len(LAYOUT_NAMES):
        return None

    out = {}
    for lid, data_str in rows:
        try:
            out[int(lid)] = json.loads(data_str)
        except Exception:
            return None
    return out if len(out) == len(LAYOUT_NAMES) else None



def run_evaluator(company_id):
    """Run evaluate.py for every layout and collect the JSON.

    Captures and prints the stderr of every failed evaluator run, and tracks failed layouts.
    """
    out = {}
    failed_layouts = []
    env = os.environ.copy()
    if STATE:
        env["HUDU_STATE_DIR"] = STATE
    for lid in LAYOUT_NAMES:
        r = subprocess.run(
            [sys.executable, os.path.join(HERE, "evaluate.py"),
             str(company_id), str(lid), LAYOUT_NAMES[lid], "--json"],
            env=env, capture_output=True, text=True)
        if r.returncode != 0:
            print(f"Evaluator failed for layout {lid} ({LAYOUT_NAMES.get(lid)}): exit code {r.returncode}\n{r.stderr}",
                  file=sys.stderr)
            failed_layouts.append(lid)
            continue
        try:
            out[lid] = json.loads(r.stdout)
        except json.JSONDecodeError as e:
            print(f"Evaluator output invalid JSON for layout {lid} ({LAYOUT_NAMES.get(lid)}): {e}\nstdout: {r.stdout[:200]}\nstderr: {r.stderr}",
                  file=sys.stderr)
            failed_layouts.append(lid)
            continue
    return out, failed_layouts


def company_name(company_id):
    """Read the client name from the collected state."""
    import sqlite3
    path = os.path.join(STATE, f"{company_id}.sqlite")
    if not os.path.exists(path):
        return f"company {company_id}"
    try:
        c = sqlite3.connect(path)
        row = c.execute("select raw from assets limit 1").fetchone()
        if row and row[0]:
            return json.loads(row[0]).get("company_name") or f"company {company_id}"
    except Exception:
        pass
    return f"company {company_id}"


def review_date(company_id):
    """Read the collection timestamp from the state database.

    If absent, state that explicitly ('date unavailable').
    """
    import sqlite3, datetime
    path = os.path.join(STATE, f"{company_id}.sqlite")
    if not os.path.exists(path):
        return "date unavailable"
    try:
        con = sqlite3.connect(f"file:{os.path.abspath(path)}?mode=ro", uri=True)
    except Exception:
        con = sqlite3.connect(path)
    try:
        cur = con.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='fetch_log'")
        if cur.fetchone():
            row = cur.execute("SELECT max(ts) FROM fetch_log WHERE company_id = ?", (company_id,)).fetchone()
            if row and row[0]:
                return datetime.datetime.fromtimestamp(row[0], tz=datetime.timezone.utc).strftime("%Y-%m-%d")
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='assets'")
        if cur.fetchone():
            row = cur.execute("SELECT max(fetched_at) FROM assets WHERE company_id = ?", (company_id,)).fetchone()
            if row and row[0]:
                return datetime.datetime.fromtimestamp(row[0], tz=datetime.timezone.utc).strftime("%Y-%m-%d")
    except Exception:
        pass
    finally:
        con.close()
    return "date unavailable"


def aggregate_components(data, verdicts=None):
    """Aggregate per-component statuses across all collected layouts.

    Returns dict mapping cid -> {
        "status": "clean" | "missing" | "partial" | "not_evaluated" | "not_applicable",
        "reason": str or None,
        "note": str or None,
    }
    """
    verdicts = verdicts or {}
    agg = {}
    collected_lids = set(data.keys())

    for cid, info in REGISTRY.items():
        kind = info.get("kind")
        layouts = info.get("layouts")
        if layouts is SCOPE_ALL:
            comp_collected_lids = list(collected_lids)
        elif layouts:
            comp_collected_lids = [lid for lid in layouts if lid in collected_lids]
        else:
            comp_collected_lids = []

        if not comp_collected_lids:
            agg[cid] = {
                "status": "not_applicable",
                "reason": "the component's layout is not part of this render",
                "note": None,
            }
            continue

        if kind == "out_of_scope":
            agg[cid] = {
                "status": "not_evaluated",
                "reason": info.get("reason") or "out of scope by decision",
                "note": None,
            }
            continue

        if kind == "prose":
            if cid in verdicts:
                v = verdicts[cid]
                v_st = v.get("status", "not_evaluated")
                agg[cid] = {
                    "status": v_st,
                    "reason": None if v_st in ("clean", "missing") else "prose judgment not supplied",
                    "note": v.get("note"),
                }
            else:
                agg[cid] = {
                    "status": "not_evaluated",
                    "reason": "prose judgment not supplied",
                    "note": None,
                }
            continue

        # kind == "code"
        statuses = []
        reasons = []
        for lid in comp_collected_lids:
            comp_entry = next((c for c in data[lid].get("components", []) if c.get("id") == cid), None)
            if comp_entry:
                statuses.append(comp_entry.get("status"))
                if comp_entry.get("reason"):
                    reasons.append(comp_entry.get("reason"))
            else:
                findings = [f for f in data[lid].get("findings", []) if f.get("component") == cid]
                if findings:
                    statuses.append("partial" if cid in ("I8", "CM9", "CM10", "PH14") else "missing")
                else:
                    statuses.append("clean")

        if all(s == "not_applicable" for s in statuses):
            status = "not_applicable"
            reason = "the component's layout is not part of this render"
        elif "missing" in statuses:
            status = "missing"
            reason = None
        elif "partial" in statuses:
            status = "partial"
            reason = None
        elif "clean" in statuses:
            status = "clean"
            reason = None
        else:
            status = "not_evaluated"
            reason = "; ".join(reasons) if reasons else "component did not run"

        agg[cid] = {
            "status": status,
            "reason": reason,
            "note": None,
        }

    return agg


def render(company_id, data, verdict=None, verdicts=None, tier=1,
           partial_banner=None, failed_layouts=None):
    if verdicts:
        for d in data.values():
            for c in d.get("components", []):
                if c.get("id") in verdicts:
                    v = verdicts[c["id"]]
                    c["status"] = v.get("status", c["status"])
                    c["note"] = v.get("note")
                    c["reason"] = None

    render_sevs = tier_severities(tier)

    # ---- totals ----
    # Counts reflect what is RENDERED, not what was evaluated.
    counts = collections.Counter()
    total_findings = 0
    for d in data.values():
        for f in d.get("findings", []):
            if f["severity"] in render_sevs:
                counts[f["severity"]] += 1
                total_findings += 1

    # ---- component completeness ----
    comp_agg = aggregate_components(data, verdicts=verdicts)
    clean_comps = [cid for cid, s in comp_agg.items()
                   if s["status"] == "clean" and REGISTRY[cid].get("kind") in ("code", "prose")]
    missing_comps = [cid for cid, s in comp_agg.items()
                     if s["status"] == "missing" and REGISTRY[cid].get("kind") in ("code", "prose")]
    partial_comps = [cid for cid, s in comp_agg.items()
                     if s["status"] == "partial" and REGISTRY[cid].get("kind") in ("code", "prose")]
    not_eval_comps = [cid for cid, s in comp_agg.items()
                      if s["status"] == "not_evaluated"]

    passed = len(clean_comps)
    denom = len(clean_comps) + len(missing_comps) + len(partial_comps)
    pct = round(100 * passed / denom) if denom else 0

    not_eval_str = ""
    if not_eval_comps:
        reasons_map = collections.defaultdict(list)
        for cid in sorted(not_eval_comps):
            info = REGISTRY[cid]
            if info.get("kind") == "prose":
                cat = "prose judgment not supplied"
            elif info.get("kind") == "out_of_scope":
                cat = "out of scope"
            else:
                cat = comp_agg[cid].get("reason") or "did not run"
            reasons_map[cat].append(cid)
        cat_strs = [f"{cat}: {', '.join(sorted(cids))}" for cat, cids in sorted(reasons_map.items())]
        c_word = "components" if len(not_eval_comps) != 1 else "component"
        not_eval_str = f" {len(not_eval_comps)} {c_word} not evaluated ({'; '.join(cat_strs)})."

    r_date = review_date(company_id)
    name = company_name(company_id)

    # All findings across all reviewed layouts, regardless of tier
    all_findings = [f for d in data.values() for f in d.get("findings", [])]
    total_by_sev = collections.Counter(f["severity"] for f in all_findings)

    rendered_count = sum(total_by_sev[s] for s in render_sevs)
    r_word = "findings" if rendered_count != 1 else "finding"
    rendered_sevs_list = [s for s in SEV_ORDER if s in render_sevs]
    rendered_breakdown = ", ".join(f"{total_by_sev[s]} {s}" for s in rendered_sevs_list)
    tier_label = ", ".join(rendered_sevs_list)

    if tier >= 3:
        deferred_str = " &#183; 0 deferred"
    else:
        deferred_sevs = [s for s in SEV_ORDER if TIER.get(s, 0) > tier]
        deferred_count = sum(total_by_sev[s] for s in deferred_sevs)
        if deferred_count == 0:
            deferred_str = " &#183; 0 deferred"
        else:
            def_breakdown = ", ".join(f"{total_by_sev[s]} {s}" for s in deferred_sevs)
            deferred_str = f" &#183; {deferred_count} deferred to ledger ({def_breakdown})"

    tier_line = f"Tier {tier} ({tier_label}) &#183; {rendered_count} {r_word} ({rendered_breakdown}){deferred_str}"

    layout_word = "layout reviewed" if len(data) == 1 else "layouts reviewed"

    H = [STYLE_BLOCK]
    # Meta charset is retained so staged HTML files display with correct encoding
    # when opened directly in a browser or outside the Hudu wrapper.
    H.append('<meta charset="utf-8">')
    H.append(f"<h1>Documentation Review &#8212; {esc(name)}</h1>")
    if partial_banner:
        n_coll, n_tot, missing_lids = partial_banner
        missing_ids_str = ", ".join(str(m) for m in sorted(missing_lids))
        H.append(f'<p class="hdr banner">Partial review: {n_coll} of {n_tot} layouts collected. '
                 f'Missing: {missing_ids_str}. Findings for the missing layouts are absent, not clean.</p>')
    H.append(f'<p class="hdr">{esc(name)} &#183; reviewed: {r_date} &#183; '
             f'company_id {company_id} &#183; {len(data)} {layout_word}</p>')
    H.append(f"<p>{tier_line}<br>\n"
             f"<strong>{pct}% component completeness</strong> "
             f"({passed} of {denom}).{not_eval_str}</p>")

    if verdict:
        H.append(f"<p>{verdict}</p>")
    else:
        H.append("<!-- VERDICT: model writes the systemic-issues paragraph here -->")

    # ---- per group / layout ----
    for group, lids in GROUPS:
        present = [l for l in lids if l in data or (failed_layouts and l in failed_layouts)]
        if not present:
            continue
        H.append(f"<h2>{esc(group)}</h2>")
        for lid in present:
            if failed_layouts and lid in failed_layouts:
                H.append(f"<h3>{esc(LAYOUT_NAMES.get(lid, f'Layout {lid}'))}</h3>")
                H.append('<p class="hdr">Not reviewed: evaluator failed.</p>')
                continue
            d = data[lid]
            # Cross-cutting (X1-X3) and cross-layout (I8, CM9, CM10) findings
            # get their own sections at the end of the report. Excluding them
            # here is what stops a finding being drawn twice.
            findings = [f for f in d.get("findings", [])
                        if f["severity"] in render_sevs
                        and f["component"] not in CROSS_CUTTING
                        and f["component"] not in CROSS_LAYOUT]
            prose_items = d.get("prose", [])
            nassets = d.get("assets", 0)

            asset_word = "assets" if nassets != 1 else "asset"
            if findings:
                f_word = "findings" if len(findings) != 1 else "finding"
                H.append(f"<h3>{esc(LAYOUT_NAMES[lid])} "
                         f'<span class="sub">({nassets} {asset_word}, '
                         f'{len(findings)} {f_word})</span></h3>')
            else:
                H.append(f"<h3>{esc(LAYOUT_NAMES[lid])} "
                         f'<span class="sub">({nassets} {asset_word})</span></h3>')

            if findings:
                # findings detail — grouped by problem, records listed inline.
                # One row per distinct problem rather than one row per record:
                # 'IP Address missing' appears once with every affected asset
                # linked, instead of 46 near-identical rows.
                H.append('<table class="tbl-detail">')
                H.append('<colgroup><col style="width:6rem">'
                         '<col style="width:5.5rem"><col>'
                         '<col style="width:32%"></colgroup>')
                H.append("<thead><tr><th>Severity</th><th>Component</th>"
                         "<th>Finding</th><th>Records</th></tr></thead><tbody>")
                groups = {}
                for f in findings:
                    key = (f["severity"], f["component"],
                           canon_detail(f["detail"]))
                    groups.setdefault(key, []).append(f)
                for (sev, comp, detail), fs in sorted(
                        groups.items(), key=lambda kv: (
                            SEV_ORDER.index(kv[0][0]), natural_sort_key(kv[0][1]), kv[0][2])):
                    links = ", ".join(link(f) for f in fs)
                    det_html = render_detail(fs[0], company_id)
                    H.append(f"<tr><td>{badge(sev, SEV_CLASS[sev])}</td>"
                             f"<td>{esc(comp)}</td>"
                             f"<td>{det_html}</td>"
                             f"<td>{links}</td></tr>")
                H.append("</tbody></table>")
            elif not prose_items:
                eval_cids = layout_components(lid)
                if not eval_cids:
                    oos = layout_out_of_scope_components(lid)
                    reason = REGISTRY[oos[0]].get("reason") if oos else "out of scope by decision"
                    H.append(f'<p class="hdr">Not reviewed: {reason}.</p>')
                else:
                    H.append('<p class="ok">No findings.</p>')

            # Prose components live under their own layout heading, not in a
            # section at the bottom. C1/C2 belong to Client Overview; a reader
            # looking at that layout should see them there.
            for p in prose_items:
                cid = p['component']
                H.append(f"<h4>{esc(cid)} &#8212; "
                         f"{esc(p['field'])} "
                         f'<span class="sub">needs review</span></h4>')
                H.append('<p class="hdr">A judgment, not a string comparison. '
                         'Raw value below; the reviewer decides pass or fail.'
                         '</p>')
                H.append(f'<div class="prose">{esc(p["value"])}</div>')
                v = (verdicts or {}).get(cid)
                if v and v.get("note"):
                    H.append(f'<p>{esc(v["note"])}</p>')

    # ---- cross-layout ----
    cross = []
    for lid, d in data.items():
        for f in d.get("findings", []):
            if f["component"] in CROSS_LAYOUT and f["severity"] in render_sevs:
                cross.append(f)
    if cross:
        H.append("<h2>Cross-Layout Findings</h2>")
        H.append('<p class="hdr">These read two '
                 'layouts at once and are reported against the company.</p>')
        H.append('<table class="tbl-detail">')
        H.append('<colgroup><col style="width:6rem">'
                 '<col style="width:5.5rem"><col></colgroup>')
        H.append("<thead><tr><th>Severity</th><th>Component</th>"
                 "<th>Finding</th></tr></thead><tbody>")
        for f in sorted(cross, key=lambda x: (SEV_ORDER.index(x["severity"]),
                                              natural_sort_key(x["component"]),
                                              x.get("detail", ""))):
            det_html = render_detail(f, company_id)
            H.append(f"<tr><td>"
                     f"{badge(f['severity'], SEV_CLASS[f['severity']])}</td>"
                     f"<td>{esc(f['component'])}</td>"
                     f"<td>{det_html}</td></tr>")
        H.append("</tbody></table>")

    # ---- cross-cutting ----
    xc = []
    for lid, d in data.items():
        for f in d.get("findings", []):
            if f["component"] in CROSS_CUTTING and f["severity"] in render_sevs:
                xc.append((LAYOUT_NAMES.get(lid, lid), f))
    if xc:
        H.append("<h2>Cross-Cutting Findings</h2>")
        H.append('<table class="tbl-detail">')
        H.append('<colgroup><col style="width:12rem">'
                 '<col style="width:6rem"><col style="width:5.5rem">'
                 '<col><col style="width:32%"></colgroup>')
        H.append("<thead><tr><th>Layout</th><th>Severity</th>"
                 "<th>Component</th><th>Finding</th><th>Records</th></tr></thead><tbody>")
        for lname, f in sorted(xc, key=lambda item: (
                SEV_ORDER.index(item[1]["severity"]),
                natural_sort_key(item[1]["component"]),
                item[0],
                item[1].get("detail", ""))):
            rec_link = link(f) if f.get("asset_id") else ""
            det_html = render_detail(f, company_id)
            H.append(f"<tr><td>{esc(lname)}</td>"
                     f"<td>"
                     f"{badge(f['severity'], SEV_CLASS[f['severity']])}</td>"
                     f"<td>{esc(f['component'])}</td>"
                     f"<td>{det_html}</td>"
                     f"<td>{rec_link}</td></tr>")
        H.append("</tbody></table>")

    # ---- method ----
    H.append("<h2>Method</h2>")
    H.append('<p class="method">Generated by '
             'hudu-doc-review &#183; rules: client-identity v0.6, infrastructure '
             'v0.8, services v0.1, commercial v0.4, physical v0.2, '
             'cross-cutting v0.2</p>')

    # Final pass: force pure ASCII. Any non-ASCII character that slipped in
    # through a literal or a raw prose value becomes a numeric entity, so the
    # document renders identically under any charset assumption.
    doc = "\n".join(H)
    return "".join(ch if ord(ch) < 128 else f"&#{ord(ch)};" for ch in doc)


def generate_inventory():
    def format_layouts(info):
        if info["layouts"] is SCOPE_ALL:
            return "all"
        s = ", ".join(str(l) for l in info["layouts"])
        if info.get("section") == "layout":
            return f"{s} *(cross-layout)*"
        return s

    group_meta = [
        ("client-identity", "Client identity", "client-identity.md"),
        ("infrastructure", "Infrastructure", "infrastructure.md"),
        ("services", "Services", "services.md"),
        ("commercial", "Commercial", "commercial.md"),
        ("physical", "Physical", "physical.md"),
        ("cross-cutting", "Cross-cutting", "cross-cutting.md"),
    ]
    parts = []
    for grp_key, grp_title, grp_file in group_meta:
        lines = [
            f"### {grp_title} — `{grp_file}`",
            "",
            "| ID | Component | Severity | Layout |",
            "| --- | --- | --- | --- |",
        ]
        for cid, info in REGISTRY.items():
            if info["group"] == grp_key:
                lay = format_layouts(info)
                lines.append(f"| {cid} | {info['name']} | {info['severity']} | {lay} |")
        parts.append("\n".join(lines))
    return "\n\n".join(parts)


def run_check():
    from rubric import check_registry
    has_fatal_error = False

    # 1. Registry self-check
    try:
        check_registry()
    except Exception as e:
        print(f"Registry check failed: {e}")
        has_fatal_error = True

    # 2. Reference file status version vs changelog
    ref_dir = os.path.join(HERE, "..", "references")
    if os.path.exists(ref_dir):
        for fname in sorted(os.listdir(ref_dir)):
            if not fname.endswith(".md"):
                continue
            p = os.path.join(ref_dir, fname)
            with open(p) as f:
                text = f.read()
            status_m = re.search(r"Status:\*?\*\s*draft\s+(v[0-9.]+)", text, re.IGNORECASE)
            if not status_m:
                continue
            status_ver = status_m.group(1).lower()

            cl_m = re.search(r"##\s*Changelog\s*\n(.*?)(?=\n##|\Z)", text, re.DOTALL | re.IGNORECASE)
            if not cl_m:
                continue
            ver_matches = re.findall(r"-\s*(v[0-9.]+)", cl_m.group(1), re.IGNORECASE)
            if not ver_matches:
                continue
            newest_ver = ver_matches[0].lower()
            if status_ver != newest_ver:
                print(f"{fname}: status {status_ver} != newest changelog version {newest_ver}")
                has_fatal_error = True

    # 3. Inventory generated vs report-template.md inventory section
    tmpl_path = os.path.join(ref_dir, "report-template.md")
    if not os.path.exists(tmpl_path):
        print(f"Missing {tmpl_path}")
        has_fatal_error = True
    else:
        with open(tmpl_path) as f:
            tmpl_text = f.read()
        start_marker = "### Client identity"
        end_marker = "\n---\n"
        start = tmpl_text.find(start_marker)
        end = tmpl_text.find(end_marker, start)
        if start == -1 or end == -1:
            print("report-template.md: could not locate inventory section")
            has_fatal_error = True
        else:
            current_inv = tmpl_text[start:end].strip()
            gen_inv = generate_inventory().strip()
            if current_inv != gen_inv:
                print("report-template.md: inventory section does not match --inventory output")
                has_fatal_error = True

    return 1 if has_fatal_error else 0


if __name__ == "__main__":
    if "--inventory" in sys.argv:
        print(generate_inventory())
        sys.exit(0)

    if "--check" in sys.argv:
        sys.exit(run_check())

    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    company = int(sys.argv[1])
    out_path = None
    verdict = None
    verdicts_path = None
    verdicts = None
    tier = 1
    args = sys.argv[2:]
    allow_partial = False
    for i, a in enumerate(args):
        if a == "--out" and i + 1 < len(args):
            out_path = args[i + 1]
        if a == "--verdict" and i + 1 < len(args):
            verdict = args[i + 1]
        if a == "--verdicts" and i + 1 < len(args):
            verdicts_path = args[i + 1]
        if a == "--tier" and i + 1 < len(args):
            tier = int(args[i + 1])
        if a == "--allow-partial":
            allow_partial = True

    try:
        from doc_coverage import coverage as compute_coverage
    except ImportError:
        from coverage import coverage as compute_coverage

    cov = compute_coverage(company)
    missing = cov.get("missing", [])
    partial_banner = None
    if missing:
        if not allow_partial:
            missing_str = ", ".join(str(m) for m in sorted(missing))
            print(f"Error: incomplete coverage: {len(missing)} of {len(SCOPE_LAYOUTS)} layouts in scope were never collected: [{missing_str}]. "
                  f"Pass --allow-partial to render anyway.", file=sys.stderr)
            sys.exit(2)
        partial_banner = (cov.get("n_collected", len(SCOPE_LAYOUTS) - len(missing)), len(SCOPE_LAYOUTS), missing)

    if verdicts_path:
        with open(verdicts_path, "r", encoding="utf-8") as vf:
            verdicts = json.load(vf)

    data = load_data_from_db(company)
    failed_layouts = []
    if not data:
        data, failed_layouts = run_evaluator(company)
    if not data and not failed_layouts:
        print(f"no evaluator output for company {company}", file=sys.stderr)
        sys.exit(1)

    if verdicts is None:
        prose_cids = []
        for lid in data:
            for cid, info in REGISTRY.items():
                if info.get("kind") == "prose" and info.get("layouts") and lid in info.get("layouts"):
                    if cid not in prose_cids:
                        prose_cids.append(cid)
        if prose_cids:
            print(f"warning: --verdicts not passed; prose components not evaluated: {', '.join(sorted(prose_cids))}", file=sys.stderr)

    doc = render(company, data, verdict, verdicts=verdicts, tier=tier,
                 partial_banner=partial_banner, failed_layouts=failed_layouts)
    os.makedirs(STAGING, exist_ok=True)
    out_path = out_path or os.path.join(STAGING, f"{company}.html")
    with open(out_path, "w") as fh:
        fh.write(doc)
    print(f"wrote {out_path} ({len(doc)} bytes, {len(data)} layouts)")