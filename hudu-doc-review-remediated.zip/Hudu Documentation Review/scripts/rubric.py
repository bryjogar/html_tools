#!/usr/bin/env python3
"""Single source of truth for the Hudu documentation review rubric.

Declares all components, severity tiers, layout mappings, and groups.
No other module may declare these facts.
"""
import sys
import os

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

GROUP_ORDER = ["client-identity", "infrastructure", "services", "commercial", "physical"]
SEV_ORDER = ["Critical", "High", "Medium", "Low"]

TIER = {
    "Critical": 1,
    "High": 1,
    "Medium": 2,
    "Low": 3,
}

# The 31 layout ids a review covers, matching coverage.py REVIEW_LAYOUTS exactly.
SCOPE_LAYOUTS = [
    33, 2, 3, 4, 18, 17, 25, 29, 27,
    13, 14, 15, 16, 12, 21, 23,
    19, 32, 22,
    5, 6, 8, 9, 10, 11, 36, 20, 24, 30, 35, 34,
]


class _ScopeAllSentinel:
    """Sentinel meaning every layout in SCOPE_LAYOUTS."""

    def __repr__(self):
        return "SCOPE_ALL"

    def __iter__(self):
        return iter(SCOPE_LAYOUTS)

    def __contains__(self, item):
        return item in SCOPE_LAYOUTS

    def __len__(self):
        return len(SCOPE_LAYOUTS)

    def __eq__(self, other):
        return other is self or other == "SCOPE_ALL"


SCOPE_ALL = _ScopeAllSentinel()

# Layout id to display name, taken verbatim from render.py LAYOUTS minus 7 and 41.
LAYOUT_NAMES = {
    2: "Sites",
    3: "Servers",
    4: "Network Devices",
    5: "Printers & Scanners",
    6: "Building Security",
    8: "Building Automation",
    9: "Audio Visual",
    10: "Mobile Devices",
    11: "Phones",
    12: "Identity Providers (IdP)",
    13: "Applications & Services",
    14: "Backups",
    15: "Email",
    16: "File Sharing",
    17: "WAN",
    18: "LAN",
    19: "Licensing",
    20: "Printing",
    21: "Remote Access",
    22: "Vendors",
    23: "Virtualization",
    24: "Phone Systems",
    25: "Wi-Fi",
    27: "IPMI",
    29: "SSIDs",
    30: "Analog Lines",
    32: "Contracts",
    33: "Client Overview",
    34: "Security & Compliance",
    35: "SSL Certificates",
    36: "Power Management",
}

# Group -> ordered layout ids matching template structure.
GROUPS = [
    ("Client identity", [33, 2]),
    ("Infrastructure", [3, 4, 18, 17, 25, 29, 27]),
    ("Services", [13, 14, 15, 16, 12, 21, 23]),
    ("Commercial", [19, 32, 22]),
    ("Physical", [5, 20, 11, 24, 30, 9, 8, 6, 10, 36, 35, 34]),
]


def layout_group(layout_id):
    """Return the rules group name for a layout id, or None."""
    for info in REGISTRY.values():
        if info.get("group") != "cross-cutting" and info.get("layouts") is not SCOPE_ALL:
            if layout_id in info.get("layouts", []):
                return info["group"]
    return None


def layout_components(layout_id):
    """Return component ids applicable to layout_id whose kind is code or prose."""
    out = []
    for cid, info in REGISTRY.items():
        if info.get("section") == "cutting":
            continue
        layouts = info.get("layouts")
        if layouts is not SCOPE_ALL and layout_id in layouts:
            if info.get("kind") in ("code", "prose"):
                out.append(cid)
    return out


def layout_out_of_scope_components(layout_id):
    """Return component ids for layout_id whose kind is out_of_scope."""
    out = []
    for cid, info in REGISTRY.items():
        if info.get("section") == "cutting":
            continue
        layouts = info.get("layouts")
        if layouts is not SCOPE_ALL and layout_id in layouts:
            if info.get("kind") == "out_of_scope":
                out.append(cid)
    return out


REGISTRY = {
    # -------------------------------------------------------- Client Identity
    "C1": dict(
        name="Agreement Clarity", severity="Critical", layouts=[33],
        group="client-identity", kind="prose", section=None,
    ),
    "C2": dict(
        name="Maintenance Window", severity="High", layouts=[33],
        group="client-identity", kind="prose", section=None,
    ),
    "C3": dict(
        name="Contact & Authorization Chain", severity="Critical", layouts=[33],
        group="client-identity", kind="code", section=None,
    ),
    "C3a": dict(
        name="Single Point of Contact", severity="Low", layouts=[33],
        group="client-identity", kind="code", section=None,
    ),
    "C4": dict(
        name="Service Scope Consistency", severity="Critical", layouts=[33],
        group="client-identity", kind="code", section=None,
    ),
    "S1": dict(
        name="Site Validity & Coverage", severity="Medium", layouts=[2],
        group="client-identity", kind="code", section=None,
    ),

    # --------------------------------------------------------- Infrastructure
    "I1": dict(
        name="Device Identity", severity="Critical", layouts=[3, 4],
        group="infrastructure", kind="code", section=None,
    ),
    "I2": dict(
        name="Location", severity="High", layouts=[3, 4],
        group="infrastructure", kind="code", section=None,
    ),
    "I3": dict(
        name="Reachability", severity="High", layouts=[3, 4],
        group="infrastructure", kind="code", section=None,
    ),
    "I4": dict(
        name="Lifecycle", severity="High", layouts=[3, 4],
        group="infrastructure", kind="code", section=None,
    ),
    "I5": dict(
        name="Hardware Identity", severity="Medium", layouts=[3, 4],
        group="infrastructure", kind="code", section=None,
    ),
    "I6": dict(
        name="Platform", severity="Medium", layouts=[3],
        group="infrastructure", kind="code", section=None,
    ),
    "I7": dict(
        name="Layout Correctness", severity="Medium", layouts=[4],
        group="infrastructure", kind="code", section=None,
    ),
    "I8": dict(
        name="Controller Placement", severity="Medium", layouts=[4],
        group="infrastructure", kind="code", section="layout",
    ),
    "L1": dict(
        name="Segment Identity", severity="Critical", layouts=[18],
        group="infrastructure", kind="code", section=None,
    ),
    "L2": dict(
        name="Site", severity="High", layouts=[18],
        group="infrastructure", kind="code", section=None,
    ),
    "L3": dict(
        name="Gateway & DNS", severity="High", layouts=[18],
        group="infrastructure", kind="code", section=None,
    ),
    "L4": dict(
        name="DHCP", severity="Medium", layouts=[18],
        group="infrastructure", kind="code", section=None,
    ),
    "W1": dict(
        name="Circuit Identity", severity="Critical", layouts=[17],
        group="infrastructure", kind="code", section=None,
    ),
    "W2": dict(
        name="Site", severity="High", layouts=[17],
        group="infrastructure", kind="code", section=None,
    ),
    "W3": dict(
        name="Transport", severity="High", layouts=[17],
        group="infrastructure", kind="code", section=None,
    ),
    "W4": dict(
        name="Termination", severity="Medium", layouts=[17],
        group="infrastructure", kind="code", section=None,
    ),
    "W5": dict(
        name="Redundancy", severity="Medium", layouts=[17],
        group="infrastructure", kind="code", section=None,
    ),
    "WF1": dict(
        name="Site", severity="High", layouts=[25],
        group="infrastructure", kind="code", section=None,
    ),
    "WF2": dict(
        name="Controller", severity="High", layouts=[25],
        group="infrastructure", kind="code", section=None,
    ),
    "WF3": dict(
        name="Access Points", severity="High", layouts=[25],
        group="infrastructure", kind="code", section=None,
    ),
    "WF4": dict(
        name="SSIDs", severity="Medium", layouts=[25],
        group="infrastructure", kind="code", section=None,
    ),
    "WF5": dict(
        name="Management", severity="Medium", layouts=[25],
        group="infrastructure", kind="code", section=None,
    ),
    "SS1": dict(
        name="Security Configuration", severity="Critical", layouts=[29],
        group="infrastructure", kind="code", section=None,
    ),
    "SS2": dict(
        name="Passphrase", severity="Critical", layouts=[29],
        group="infrastructure", kind="code", section=None,
    ),
    "SS3": dict(
        name="LAN", severity="High", layouts=[29],
        group="infrastructure", kind="code", section=None,
    ),
    "SS4": dict(
        name="Client Isolation", severity="Medium", layouts=[29],
        group="infrastructure", kind="code", section=None,
    ),
    "IP1": dict(
        name="Management Interface", severity="High", layouts=[27],
        group="infrastructure", kind="code", section=None,
    ),

    # ------------------------------------------------------------- Services
    "SV1": dict(
        name="Application Identity & Hosting", severity="Critical", layouts=[13],
        group="services", kind="code", section=None,
    ),
    "SV2": dict(
        name="Application Ownership", severity="Medium", layouts=[13],
        group="services", kind="code", section=None,
    ),
    "SV3": dict(
        name="Backup Coverage", severity="Critical", layouts=[14],
        group="services", kind="code", section=None,
    ),
    "SV4": dict(
        name="Backup Retention", severity="Medium", layouts=[14],
        group="services", kind="code", section=None,
    ),
    "SV5": dict(
        name="Email Platform", severity="High", layouts=[15],
        group="services", kind="code", section=None,
    ),
    "SV6": dict(
        name="File Share Access", severity="High", layouts=[16],
        group="services", kind="code", section=None,
    ),
    "SV7": dict(
        name="Directory Identity", severity="Critical", layouts=[12],
        group="services", kind="code", section=None,
    ),
    "SV8": dict(
        name="Directory Sync", severity="Medium", layouts=[12],
        group="services", kind="code", section=None,
    ),
    "SV9": dict(
        name="Remote Access Method", severity="High", layouts=[21],
        group="services", kind="code", section=None,
    ),
    "SV10": dict(
        name="Virtualization Platform", severity="High", layouts=[23],
        group="services", kind="code", section=None,
    ),

    # ----------------------------------------------------------- Commercial
    "CM1": dict(
        name="License Identity", severity="Critical", layouts=[19],
        group="commercial", kind="code", section=None,
    ),
    "CM2": dict(
        name="License Lifecycle", severity="High", layouts=[19],
        group="commercial", kind="code", section=None,
    ),
    "CM2a": dict(
        name="Renewal Price", severity="Low", layouts=[19],
        group="commercial", kind="code", section=None,
    ),
    "CM4": dict(
        name="Contract Identity", severity="Critical", layouts=[32],
        group="commercial", kind="code", section=None,
    ),
    "CM5": dict(
        name="Contract Lifecycle", severity="High", layouts=[32],
        group="commercial", kind="code", section=None,
    ),
    "CM6": dict(
        name="Contract Price", severity="Medium", layouts=[32],
        group="commercial", kind="code", section=None,
    ),
    "CM7": dict(
        name="Vendor Contact", severity="High", layouts=[22],
        group="commercial", kind="code", section=None,
    ),
    "CM9": dict(
        name="Network License Coverage", severity="High", layouts=[19],
        group="commercial", kind="code", section="layout",
    ),
    "CM10": dict(
        name="Network License Count", severity="Medium", layouts=[19],
        group="commercial", kind="code", section="layout",
    ),

    # ------------------------------------------------------------- Physical
    "PH1": dict(
        name="Device Identity", severity="Critical", layouts=[5, 6, 8, 9, 10, 11, 36],
        group="physical", kind="code", section=None,
    ),
    "PH2": dict(
        name="Device Location", severity="High", layouts=[5, 6, 8, 9, 10, 11, 36],
        group="physical", kind="code", section=None,
    ),
    "PH3": dict(
        name="Device Reachability", severity="High", layouts=[5, 6, 8, 9, 10, 11, 36],
        group="physical", kind="code", section=None,
    ),
    "PH4": dict(
        name="Device Hardware Identity", severity="Medium", layouts=[5, 6, 8, 9, 10, 11, 36],
        group="physical", kind="code", section=None,
    ),
    "PH5": dict(
        name="Device Lifecycle", severity="High", layouts=[5, 6, 8, 9, 10, 11, 36],
        group="physical", kind="code", section=None,
    ),
    "PH6": dict(
        name="Printer Driver Config", severity="Medium", layouts=[5],
        group="physical", kind="code", section=None,
    ),
    "PH7": dict(
        name="Printing Deployment", severity="High", layouts=[20],
        group="physical", kind="code", section=None,
    ),
    "PH8": dict(
        name="Phone System Identity", severity="Critical", layouts=[24],
        group="physical", kind="code", section=None,
    ),
    "PH9": dict(
        name="Analog Line Identity", severity="High", layouts=[30],
        group="physical", kind="code", section=None,
    ),
    "PH10": dict(
        name="Power Device Identity", severity="Critical", layouts=[36],
        group="physical", kind="code", section=None,
    ),
    "PH11": dict(
        name="Certificate Identity", severity="Critical", layouts=[35],
        group="physical", kind="code", section=None,
    ),
    "PH13": dict(
        name="Security Posture", severity="High", layouts=[34],
        group="physical", kind="out_of_scope",
        reason="out of scope by decision", section=None,
    ),
    "PH14": dict(
        name="UPS Battery Pairing", severity="High", layouts=[36],
        group="physical", kind="code", section=None,
    ),

    # -------------------------------------------------------- Cross-cutting
    "X1": dict(
        name="Empty Layout", severity="Medium", layouts=SCOPE_ALL,
        group="cross-cutting", kind="code", section="cutting",
    ),
    "X2": dict(
        name="Duplicate Records", severity="Medium", layouts=SCOPE_ALL,
        group="cross-cutting", kind="code", section="cutting",
    ),
    "X3": dict(
        name="Placeholder Record Name", severity="High", layouts=SCOPE_ALL,
        group="cross-cutting", kind="code", section="cutting",
    ),
}

# Import-time assertion: SCOPE_LAYOUTS equals coverage.py REVIEW_LAYOUTS
# and equals the union of every entry's layouts in REGISTRY plus layouts
# that carry only cross-cutting checks.
_union_layouts = set()
for _comp in REGISTRY.values():
    if _comp["layouts"] is not SCOPE_ALL:
        _union_layouts.update(_comp["layouts"])

assert set(SCOPE_LAYOUTS) == _union_layouts, (
    f"SCOPE_LAYOUTS does not match union of REGISTRY layouts: {set(SCOPE_LAYOUTS) ^ _union_layouts}"
)

try:
    try:
        import doc_coverage as _cov_mod
    except ImportError:
        import coverage as _cov_mod
    assert list(SCOPE_LAYOUTS) == list(getattr(_cov_mod, "REVIEW_LAYOUTS", SCOPE_LAYOUTS)), (
        f"SCOPE_LAYOUTS ({SCOPE_LAYOUTS}) != coverage.REVIEW_LAYOUTS ({getattr(_cov_mod, 'REVIEW_LAYOUTS', None)})"
    )
except ImportError:
    pass


def check_registry():
    """Validate REGISTRY invariants; raises ValueError with a specific message on failure."""
    valid_groups = set(GROUP_ORDER) | {"cross-cutting"}
    valid_kinds = {"code", "prose", "out_of_scope"}
    valid_sections = {None, "cutting", "layout"}

    # 1. SCOPE_LAYOUTS disagrees with coverage.py REVIEW_LAYOUTS
    try:
        try:
            import doc_coverage as _cov_mod
        except ImportError:
            import coverage as _cov_mod
        if hasattr(_cov_mod, "REVIEW_LAYOUTS"):
            if list(SCOPE_LAYOUTS) != list(_cov_mod.REVIEW_LAYOUTS):
                raise ValueError(
                    f"SCOPE_LAYOUTS disagrees with coverage.py REVIEW_LAYOUTS: "
                    f"{SCOPE_LAYOUTS} != {_cov_mod.REVIEW_LAYOUTS}"
                )
    except ImportError:
        pass

    # Track seen component ids per group to verify no id appears in more than one group
    comp_groups = {}

    for comp_id, info in REGISTRY.items():
        grp = info.get("group")
        if not grp or grp not in valid_groups:
            raise ValueError(f"Component {comp_id} has invalid group {grp!r}")

        if comp_id in comp_groups and comp_groups[comp_id] != grp:
            raise ValueError(
                f"Component {comp_id} appears in more than one group: "
                f"{comp_groups[comp_id]} and {grp}"
            )
        comp_groups[comp_id] = grp

        # 2. Layout id outside SCOPE_LAYOUTS
        layouts = info.get("layouts")
        if layouts is not SCOPE_ALL:
            if not isinstance(layouts, (list, tuple, set)):
                raise ValueError(f"Component {comp_id} layouts must be a list or SCOPE_ALL")
            for lid in layouts:
                if lid not in SCOPE_LAYOUTS:
                    raise ValueError(
                        f"Component {comp_id} declares layout id {lid} outside SCOPE_LAYOUTS"
                    )

        # 3. Severity not in SEV_ORDER
        sev = info.get("severity")
        if sev not in SEV_ORDER:
            raise ValueError(f"Component {comp_id} severity {sev!r} is not in SEV_ORDER")

        # 4. Kind not one of the three
        kind = info.get("kind")
        if kind not in valid_kinds:
            raise ValueError(f"Component {comp_id} kind {kind!r} is not one of {valid_kinds}")

        # Name / description validation
        desc = info.get("name") or info.get("description")
        if not desc or not isinstance(desc, str) or not desc.strip():
            raise ValueError(f"Component {comp_id} has empty or missing description")

        # Section validation
        sec = info.get("section")
        if sec not in valid_sections:
            raise ValueError(f"Component {comp_id} section {sec!r} is not one of {valid_sections}")


if __name__ == "__main__":
    check_registry()
    print(f"Registry OK: {len(REGISTRY)} components across {len(SCOPE_LAYOUTS)} layouts.")
