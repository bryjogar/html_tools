#!/usr/bin/env python3
"""Collect Hudu assets into local SQLite, bypassing model context entirely.

The MCP tool-result path truncates large payloads (~15KB) before they reach a
model. Calling the MCP server directly over HTTP avoids that entirely: a full
layout collects in seconds with no truncation and no model context consumed.

Usage:
    python3 collect.py <company_id> <layout_id> [per_page]

Writes to state/<company_id>.sqlite next to this script. Re-running a company
refreshes its rows in place (insert or replace), so a re-run never mixes data
from two companies. Sweeps stale rows older than the collection run start.
"""
import json, sqlite3, urllib.request, sys, time, os

HERE = os.path.dirname(os.path.abspath(__file__))
STATE = os.environ.get("HUDU_STATE_DIR") or os.path.join(HERE, "..", "state")

from hudu import get_token, rpc, call_tool


def db_path(company_id):
    os.makedirs(STATE, exist_ok=True)
    return os.path.join(STATE, f"{company_id}.sqlite")


def init_db(path):
    c = sqlite3.connect(path)
    c.executescript("""
    create table if not exists assets(
      id integer primary key, name text, company_id int, layout_id int,
      layout_name text, hudu_url text, raw text, fetched_at int);
    create table if not exists fields(
      asset_id int, label text, value text, field_type text, position int);
    create table if not exists cards(
      asset_id int, integrator text, data text);
    create table if not exists fetch_log(
      company_id int, layout_id int, page int, n int, bytes int, ts int);
    """)
    return c


def collect(token, company_id, layout_id, per_page=25):
    path = db_path(company_id)
    c = init_db(path)
    run_start = int(time.time())
    page, total, got = 1, None, 0
    while True:
        res = call_tool(token, "asset_index_tool", {
            "company_id": company_id, "asset_layout_id": layout_id,
            "include": ["fields", "cards"], "per_page": per_page, "page": page}, _id=page)
        data = res.get("data", [])
        pag = res.get("pagination", {})

        # Requirement 2.2: require total_count and total_pages from pagination block.
        if "total_count" not in pag or pag.get("total_count") is None:
            print(
                f"Error: unverified collection: pagination block is missing 'total_count' (got {pag}). "
                f"Cannot verify collection completeness.",
                file=sys.stderr
            )
            sys.exit(1)

        total = pag.get("total_count")
        total_pages = pag.get("total_pages")
        if total_pages is None:
            print(
                f"Error: unverified collection: pagination block is missing 'total_pages' (got {pag}). "
                f"Cannot verify collection completeness.",
                file=sys.stderr
            )
            sys.exit(1)

        if len(data) >= per_page and total_pages <= 1:
            print(
                f"Error: unverified pagination state: page {page} returned a full page of "
                f"{len(data)} records (per_page={per_page}) while total_pages is {total_pages}. "
                f"Collection cannot be verified.",
                file=sys.stderr
            )
            sys.exit(1)

        now = int(time.time())
        for a in data:
            c.execute("insert or replace into assets values(?,?,?,?,?,?,?,?)",
                      (a["id"], a.get("name"), a.get("company_id"),
                       a.get("asset_layout_id"), a.get("asset_layout_name"),
                       a.get("hudu_url"), json.dumps(a), now))
            c.execute("delete from fields where asset_id=?", (a["id"],))
            for f in a.get("fields", []):
                c.execute("insert into fields values(?,?,?,?,?)",
                          (a["id"], f.get("label"), f.get("value"),
                           f.get("field_type"), f.get("position")))
            # Integrator cards (ConnectWise etc). Sites carry their address here.
            c.execute("delete from cards where asset_id=?", (a["id"],))
            for card in a.get("cards") or []:
                c.execute("insert into cards values(?,?,?)",
                          (a["id"], card.get("integrator_name"),
                           json.dumps(card.get("data"))))
        got += len(data)
        c.execute("insert into fetch_log values(?,?,?,?,?,?)",
                  (company_id, layout_id, page, len(data),
                   len(json.dumps(res)), int(time.time())))
        c.commit()
        print(f"  page {page}: {len(data)} assets (total_count={total})",
              file=sys.stderr)
        if not data or page >= total_pages:
            break
        page += 1

    # Requirement 2.1: sweep stale rows older than run_start for this company and layout
    stale_rows = c.execute(
        "select id from assets where company_id=? and layout_id=? and fetched_at < ?",
        (company_id, layout_id, run_start)
    ).fetchall()
    stale_ids = [r[0] for r in stale_rows]
    stale_count = len(stale_ids)
    if stale_count > 0:
        placeholders = ",".join("?" for _ in stale_ids)
        c.execute(f"delete from fields where asset_id in ({placeholders})", stale_ids)
        c.execute(f"delete from cards where asset_id in ({placeholders})", stale_ids)
        c.execute(f"delete from assets where id in ({placeholders})", stale_ids)
        c.commit()

    return got, total, path, stale_count


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(2)
    company = int(sys.argv[1]); layout = int(sys.argv[2])
    pp = int(sys.argv[3]) if len(sys.argv) > 3 else 25
    tok = get_token()
    t0 = time.time()
    got, total, path, removed = collect(tok, company, layout, pp)
    print(f"collected {got} of {total} in {time.time()-t0:.1f}s ({removed} stale removed) -> {path}")