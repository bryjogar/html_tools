#!/usr/bin/env python3
"""Report which layouts have actually been collected for a company.

The evaluator cannot tell "this layout is empty" from "this layout was never
fetched" — both look like zero assets. That distinction matters: an empty
layout is a real X1 finding, an uncollected one is a hole in our own data.

This module is the single source of truth for that question. `evaluate.py`
uses it to suppress X1 on uncollected layouts; the sweep uses it to decide
what still needs fetching.
"""
import glob
import json
import os
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
STATE = os.environ.get("HUDU_STATE_DIR") or os.path.join(HERE, "..", "state")

from rubric import SCOPE_LAYOUTS

REVIEW_LAYOUTS = SCOPE_LAYOUTS


def db_path(company_id):
    return os.path.join(STATE, f"{company_id}.sqlite")


def collected_layouts(company_id):
    """Layout ids with at least one successful fetch recorded.

    A fetch that returned zero assets still counts as collected — the layout
    was queried and the answer was "nothing here". That is a real X1 finding.
    """
    path = db_path(company_id)
    if not os.path.exists(path):
        return set()
    try:
        c = sqlite3.connect(path)
        return {r[0] for r in c.execute("select distinct layout_id from fetch_log")}
    except sqlite3.OperationalError:
        return set()


def coverage(company_id):
    got = collected_layouts(company_id)
    missing = [l for l in REVIEW_LAYOUTS if l not in got]
    return {
        "company_id": company_id,
        "collected": sorted(got & set(REVIEW_LAYOUTS)),
        "missing": missing,
        "n_collected": len(got & set(REVIEW_LAYOUTS)),
        "n_required": len(REVIEW_LAYOUTS),
        "complete": not missing,
    }


def is_collected(company_id, layout_id):
    return layout_id in collected_layouts(company_id)


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(2)

    if args[0] == "--all":
        rows = []
        for p in sorted(glob.glob(os.path.join(STATE, "*.sqlite"))):
            cid = int(os.path.basename(p)[:-7])
            rows.append(coverage(cid))
        rows.sort(key=lambda r: (-r["n_collected"], r["company_id"]))
        for r in rows:
            flag = "COMPLETE" if r["complete"] else f"{r['n_collected']:>2}/{len(REVIEW_LAYOUTS)}"
            print(f"  {r['company_id']:>4}  {flag}")
        complete = sum(1 for r in rows if r["complete"])
        print(f"\n{len(rows)} companies, {complete} complete")
        sys.exit(0)

    cid = int(args[0])
    cov = coverage(cid)
    if "--json" in args:
        print(json.dumps(cov, indent=1))
    else:
        print(f"company {cid}: {cov['n_collected']}/{cov['n_required']} layouts collected")
        if cov["missing"]:
            print(f"  missing: {cov['missing']}")
        else:
            print("  complete")


if __name__ == "__main__":
    main()
