#!/usr/bin/env python3
"""Ledger inspection tool for Hudu documentation review findings.

Read-only. Inspects findings recorded in company state databases.

Usage:
    ledger.py COMPANY_ID [--tier N] [--json]
    ledger.py --all [--json]
    ledger.py [COMPANY_ID] --resolved-since VAL [--json]
"""
import argparse
import collections
import json
import os
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
STATE = os.environ.get("HUDU_STATE_DIR") or os.path.join(HERE, "..", "state")


def open_ro_db(path):
    """Open SQLite database in strict read-only mode."""
    if not os.path.exists(path):
        return None
    try:
        uri = f"file:{os.path.abspath(path)}?mode=ro"
        return sqlite3.connect(uri, uri=True)
    except Exception:
        # Fallback if URI mode fails
        con = sqlite3.connect(path)
        return con


def get_company_db(company_id):
    path = os.path.join(STATE, f"{company_id}.sqlite")
    return open_ro_db(path)


def list_company_dbs():
    """Return dict mapping company_id -> db_path for all sqlite files in STATE."""
    if not os.path.exists(STATE):
        return {}
    dbs = {}
    for fname in sorted(os.listdir(STATE)):
        if fname.endswith(".sqlite"):
            base = fname[:-7]
            try:
                cid = int(base)
                dbs[cid] = os.path.join(STATE, fname)
            except ValueError:
                continue
    return dbs


def tally_company(con, company_id, tier=None):
    """Compute per-company findings tallies."""
    cur = con.cursor()
    # Check if findings table exists
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='findings'")
    if not cur.fetchone():
        return {
            "company_id": company_id,
            "tier": tier,
            "counts_by_tier": {},
            "counts_by_component": {},
            "counts_by_status": {"open": 0, "resolved": 0},
            "total": 0,
        }

    where_clauses = ["company_id = ?"]
    params = [company_id]
    if tier is not None:
        where_clauses.append("tier = ?")
        params.append(tier)

    where_sql = " WHERE " + " AND ".join(where_clauses)

    # Status counts
    cur.execute(f"SELECT status, count(*) FROM findings {where_sql} GROUP BY status", params)
    status_counts = {"open": 0, "resolved": 0}
    for st, cnt in cur.fetchall():
        status_counts[st] = cnt

    # Tier counts (unfiltered by tier for global context unless tier specified)
    if tier is None:
        cur.execute("SELECT tier, count(*) FROM findings WHERE company_id = ? GROUP BY tier ORDER BY tier", (company_id,))
        tier_counts = {str(r[0]): r[1] for r in cur.fetchall()}
    else:
        tier_counts = {str(tier): sum(status_counts.values())}

    # Component counts
    cur.execute(f"SELECT component, count(*) FROM findings {where_sql} GROUP BY component ORDER BY component", params)
    comp_counts = collections.OrderedDict((r[0], r[1]) for r in cur.fetchall())

    total = sum(status_counts.values())

    return {
        "company_id": company_id,
        "tier": tier,
        "counts_by_tier": tier_counts,
        "counts_by_status": status_counts,
        "counts_by_component": comp_counts,
        "total": total,
    }


def sweep_rollup(as_json=False):
    """Print sweep rollup: one line per company with counts per tier, plus a total line."""
    dbs = list_company_dbs()
    rollup = []
    totals = {"tier_1": 0, "tier_2": 0, "tier_3": 0, "total": 0}

    for cid, path in sorted(dbs.items()):
        con = open_ro_db(path)
        if not con:
            continue
        cur = con.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='findings'")
        if not cur.fetchone():
            con.close()
            continue

        cur.execute("SELECT tier, count(*) FROM findings WHERE company_id = ? AND status = 'open' GROUP BY tier", (cid,))
        tcounts = {r[0]: r[1] for r in cur.fetchall()}
        con.close()

        t1 = tcounts.get(1, 0)
        t2 = tcounts.get(2, 0)
        t3 = tcounts.get(3, 0)
        tot = t1 + t2 + t3

        totals["tier_1"] += t1
        totals["tier_2"] += t2
        totals["tier_3"] += t3
        totals["total"] += tot

        rollup.append({
            "company_id": cid,
            "tier_1": t1,
            "tier_2": t2,
            "tier_3": t3,
            "total": tot,
        })

    if as_json:
        print(json.dumps({"companies": rollup, "total": totals}, indent=2))
        return

    # Text output: one line per company plus total
    for item in rollup:
        print(f"Company {item['company_id']}: Tier 1: {item['tier_1']}, Tier 2: {item['tier_2']}, Tier 3: {item['tier_3']} (Total: {item['total']})")
    print(f"Total: Tier 1: {totals['tier_1']}, Tier 2: {totals['tier_2']}, Tier 3: {totals['tier_3']} (Total: {totals['total']})")


def list_resolved_since(val_str, company_id=None, as_json=False):
    """List what was closed since a prior timestamp or run_id."""
    try:
        val = int(val_str)
    except ValueError:
        print(f"Error: resolved-since argument must be an integer timestamp or run_id: {val_str}", file=sys.stderr)
        sys.exit(1)

    dbs = {}
    if company_id is not None:
        path = os.path.join(STATE, f"{company_id}.sqlite")
        if os.path.exists(path):
            dbs[company_id] = path
    else:
        dbs = list_company_dbs()

    resolved = []
    for cid, path in sorted(dbs.items()):
        con = open_ro_db(path)
        if not con:
            continue
        cur = con.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='findings'")
        if not cur.fetchone():
            con.close()
            continue

        cur.execute("""
        SELECT company_id, layout_id, component, severity, tier,
               asset_id, asset_name, detail, status, first_seen, last_seen, run_id
        FROM findings
        WHERE status = 'resolved' AND (last_seen >= ? OR run_id >= ?)
        ORDER BY last_seen DESC, run_id DESC
        """, (val, val))
        for row in cur.fetchall():
            resolved.append({
                "company_id": row[0],
                "layout_id": row[1],
                "component": row[2],
                "severity": row[3],
                "tier": row[4],
                "asset_id": row[5],
                "asset_name": row[6],
                "detail": row[7],
                "status": row[8],
                "first_seen": row[9],
                "last_seen": row[10],
                "run_id": row[11],
            })
        con.close()

    if as_json:
        print(json.dumps(resolved, indent=2))
        return

    if not resolved:
        print(f"No resolved findings found since {val}.")
        return

    print(f"Resolved findings since {val} ({len(resolved)} total):")
    for r in resolved:
        aid_str = f"asset {r['asset_id']}" if r['asset_id'] != "none" else "(layout)"
        aname_str = f" ({r['asset_name']})" if r['asset_name'] else ""
        print(f"  [Company {r['company_id']}] Layout {r['layout_id']} | {r['component']} ({r['severity']}) | {aid_str}{aname_str}: {r['detail']} (last_seen: {r['last_seen']}, run: {r['run_id']})")


def main():
    parser = argparse.ArgumentParser(description="Inspect findings ledger in company databases.")
    parser.add_argument("company_id", nargs="?", type=int, help="Company ID to inspect")
    parser.add_argument("--tier", type=int, choices=[1, 2, 3], help="Filter to specific tier (1, 2, or 3)")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON")
    parser.add_argument("--all", action="store_true", help="Print sweep rollup for all companies")
    parser.add_argument("--resolved-since", dest="resolved_since", type=str, help="List findings resolved since TIMESTAMP or run_id")

    args = parser.parse_args()

    if args.resolved_since:
        list_resolved_since(args.resolved_since, company_id=args.company_id, as_json=args.json)
        return

    if args.all:
        sweep_rollup(as_json=args.json)
        return

    if args.company_id is None:
        parser.print_help()
        sys.exit(2)

    con = get_company_db(args.company_id)
    if not con:
        print(f"Error: state database for company {args.company_id} not found in {STATE}", file=sys.stderr)
        sys.exit(1)

    tally = tally_company(con, args.company_id, tier=args.tier)
    con.close()

    if args.json:
        print(json.dumps(tally, indent=2))
        return

    tier_hdr = f" (Tier {args.tier})" if args.tier else ""
    print(f"=== Company {args.company_id} Findings Ledger{tier_hdr} ===")
    print("Status:")
    print(f"  open: {tally['counts_by_status']['open']}")
    print(f"  resolved: {tally['counts_by_status']['resolved']}")
    if args.tier is None and tally["counts_by_tier"]:
        print("Tiers:")
        for t, cnt in sorted(tally["counts_by_tier"].items()):
            print(f"  Tier {t}: {cnt}")
    print("Components:")
    if tally["counts_by_component"]:
        for comp, cnt in tally["counts_by_component"].items():
            print(f"  {comp}: {cnt}")
    else:
        print("  (none)")
    print(f"Total: {tally['total']}")


if __name__ == "__main__":
    main()
