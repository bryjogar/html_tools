#!/usr/bin/env python3
"""Tests for plumbing (Unit C Part 3).

Covers all Part 3 requirements:
1. the environment override for the MCP URL and the store path takes effect.
2. the local coverage helper is imported under its new name and is not shadowed when a module
   named coverage exists earlier on the path.
3. collect.py and publish.py both use the shared client (assert no duplicate rpc definition
   remains in either file).
"""
import importlib
import json
import os
import sqlite3
import sys
import tempfile
import urllib.request
import pytest

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPTS_DIR = os.path.dirname(TESTS_DIR)
if SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, SCRIPTS_DIR)
if TESTS_DIR not in sys.path:
    sys.path.insert(0, TESTS_DIR)

import hudu
import evaluate


# -----------------------------------------------------------------------------
# 1. Environment override for MCP URL and store path takes effect
# -----------------------------------------------------------------------------
def test_environment_override_mcp_url_and_store(tmp_path, monkeypatch):
    custom_url = "https://custom-hudu.example.com/mcp"
    custom_store_file = tmp_path / "custom_store.sqlite"
    custom_store_uri = f"file:{custom_store_file}?mode=ro"

    # Setup custom store DB
    con = sqlite3.connect(str(custom_store_file))
    con.execute("create table mcp_oauth_stores(store_json text)")
    token_json = json.dumps({"tokens": {"access_token": "secret-custom-token-xyz"}})
    con.execute("insert into mcp_oauth_stores values(?)", (token_json,))
    con.commit()
    con.close()

    monkeypatch.setenv("HUDU_MCP_URL", custom_url)
    monkeypatch.setenv("HUDU_OAUTH_STORE", custom_store_uri)

    assert hudu.get_mcp_url() == custom_url
    assert hudu.get_store_path() == custom_store_uri

    # Token retrieval uses the custom store path
    tok = hudu.get_token()
    assert tok == "secret-custom-token-xyz"

    # RPC uses the custom MCP URL
    recorded_urls = []

    class MockResponse:
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass
        def read(self):
            return json.dumps({"jsonrpc": "2.0", "id": 1, "result": {}}).encode()

    def mock_urlopen(req, timeout=None):
        recorded_urls.append(req.full_url)
        return MockResponse()

    monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

    hudu.rpc(tok, "tools/list")
    assert recorded_urls == [custom_url]


# -----------------------------------------------------------------------------
# 2. Local coverage helper is imported under new name and not shadowed
# -----------------------------------------------------------------------------
def test_coverage_helper_not_shadowed_by_coverage_pkg(tmp_path, monkeypatch):
    # Create a fake third-party 'coverage' module in a temp directory
    fake_coverage_dir = tmp_path / "site_packages"
    fake_coverage_dir.mkdir()
    fake_coverage_file = fake_coverage_dir / "coverage.py"
    fake_coverage_file.write_text("# Third-party coverage.py package dummy\nVERSION = '7.0.0'\n", encoding="utf-8")

    # Prepend fake site-packages to sys.path so 'import coverage' resolves to it
    monkeypatch.syspath_prepend(str(fake_coverage_dir))

    orig_cov = sys.modules.get("coverage")
    orig_doc_cov = sys.modules.get("doc_coverage")
    try:
        # Remove cached 'coverage' and 'doc_coverage' if already in sys.modules
        sys.modules.pop("coverage", None)
        sys.modules.pop("doc_coverage", None)

        # Verify that bare 'import coverage' would resolve to the fake module (no is_collected)
        dummy_cov = importlib.import_module("coverage")
        assert not hasattr(dummy_cov, "is_collected")
        assert getattr(dummy_cov, "VERSION", None) == "7.0.0"

        # Setup dummy database with fetch_log for company 888, layout 2
        db_file = tmp_path / "888.sqlite"
        con = sqlite3.connect(str(db_file))
        con.execute("create table fetch_log(company_id int, layout_id int, page int, n int, bytes int, ts int)")
        con.execute("insert into fetch_log values(888, 2, 1, 1, 100, 1700000000)")
        con.commit()
        con.close()

        monkeypatch.setenv("HUDU_STATE_DIR", str(tmp_path))

        # Test evaluate._layout_was_collected(): it must import doc_coverage and correctly report True for layout 2
        # and False for layout 99, completely unshadowed by the dummy coverage module.
        assert evaluate._layout_was_collected(888, 2) is True
        assert evaluate._layout_was_collected(888, 99) is False
    finally:
        if orig_cov is not None:
            sys.modules["coverage"] = orig_cov
        else:
            sys.modules.pop("coverage", None)
        if orig_doc_cov is not None:
            sys.modules["doc_coverage"] = orig_doc_cov
        else:
            sys.modules.pop("doc_coverage", None)


# -----------------------------------------------------------------------------
# 3. collect.py and publish.py use shared client with no duplicate RPC definition
# -----------------------------------------------------------------------------
def test_no_duplicate_rpc_definitions():
    collect_path = os.path.join(SCRIPTS_DIR, "collect.py")
    publish_path = os.path.join(SCRIPTS_DIR, "publish.py")

    with open(collect_path, "r", encoding="utf-8") as f:
        collect_src = f.read()

    with open(publish_path, "r", encoding="utf-8") as f:
        publish_src = f.read()

    # Neither file should define rpc, get_token, or call_tool locally
    assert "def rpc(" not in collect_src, "collect.py still defines rpc"
    assert "def rpc(" not in publish_src, "publish.py still defines rpc"
    assert "def get_token(" not in collect_src, "collect.py still defines get_token"
    assert "def get_token(" not in publish_src, "publish.py still defines get_token"
    assert "def call_tool(" not in collect_src, "collect.py still defines call_tool"
    assert "def call_tool(" not in publish_src, "publish.py still defines call_tool"

    # Both files must import from hudu
    assert "from hudu import" in collect_src, "collect.py does not import from hudu"
    assert "from hudu import" in publish_src, "publish.py does not import from hudu"


# -----------------------------------------------------------------------------
# 4. Rubric component description invariants
# -----------------------------------------------------------------------------
def test_all_components_have_non_empty_description():
    """Assert that every component in rubric has a non-empty description."""
    import rubric
    for comp_id, info in rubric.REGISTRY.items():
        desc = info.get("name") or info.get("description")
        assert desc and isinstance(desc, str) and desc.strip(), (
            f"Component {comp_id} has empty or missing description: {info}"
        )


def test_check_registry_catches_empty_description():
    """check_registry raises ValueError if a component description is empty."""
    import rubric
    orig = rubric.REGISTRY["C1"]["name"]
    try:
        rubric.REGISTRY["C1"]["name"] = ""
        with pytest.raises(ValueError, match="empty or missing description"):
            rubric.check_registry()
    finally:
        rubric.REGISTRY["C1"]["name"] = orig

