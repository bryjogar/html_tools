#!/usr/bin/env python3
"""Unit tests for publish.py guardrails (Unit C Part 1).

Covers all Part 1 test requirements with stubbed transport:
1. payload with verdict placeholder is refused, naming exact marker found.
2. payload with unevaluated-component marker is refused, allowed with --accept-unknowns.
3. default is draft; --publish produces live write; --draft is no-op alias.
4. creating new article without --allow-create is refused; with it, allowed.
5. normalize() treats hexadecimal entity differences as match.
6. normalize() treats inserted whitespace differences as match.
7. normalize() still reports real difference as mismatch with divergence offset.
8. two exact matches are refused, listing every match with its url.
9. --dry-run performs no write.
10. payload above --max-bytes is refused; --force-size allows it; size printed.
"""
import io
import os
import sys
import pytest

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPTS_DIR = os.path.dirname(TESTS_DIR)
if SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, SCRIPTS_DIR)

import publish


class DummyTransport:
    """Mock MCP tool runner recording calls without making network requests."""

    def __init__(self, index_results=None, show_result=None):
        self.calls = []
        self.index_results = index_results if index_results is not None else []
        self.show_result = show_result or {"id": 1, "name": "Test", "content": "hello"}

    def call_tool(self, token, name, args, _id=1):
        self.calls.append((name, args))
        if name == "article_index_tool":
            return {"data": self.index_results, "pagination": {"total_pages": 1, "total_count": len(self.index_results)}}
        if name == "article_show_tool":
            return {"data": self.show_result}
        if name == "article_create_tool":
            return {"data": {"id": 999, "name": args.get("name"), "draft": args.get("draft")}}
        if name == "article_edit_tool":
            return {"data": {"id": args.get("id"), "name": args.get("name"), "draft": args.get("draft")}}
        return {}


# -----------------------------------------------------------------------------
# 1. Verdict placeholder refused, marker named
# -----------------------------------------------------------------------------
def test_verdict_placeholder_comment_refused():
    content = "<html><body><!-- VERDICT: model writes the systemic-issues paragraph here --></body></html>"
    with pytest.raises(RuntimeError) as exc_info:
        publish.check_payload(content)
    msg = str(exc_info.value)
    assert "verdict placeholder found" in msg
    assert "<!-- VERDICT: model writes the systemic-issues paragraph here -->" in msg


def test_verdict_placeholder_phrase_refused():
    content = "<html><body><p>As requested, model writes the systemic-issues paragraph here.</p></body></html>"
    with pytest.raises(RuntimeError) as exc_info:
        publish.check_payload(content)
    msg = str(exc_info.value)
    assert "verdict placeholder found" in msg
    assert "model writes the systemic-issues paragraph" in msg


# -----------------------------------------------------------------------------
# 2. Unevaluated-component marker refused, --accept-unknowns allows
# -----------------------------------------------------------------------------
def test_unevaluated_components_refused():
    content = (
        "<h1>Report</h1>"
        "<p><strong>29% component completeness</strong> (17 of 58). "
        "3 components not evaluated (out of scope: PH13; prose judgment not supplied: C1, C2).</p>"
    )
    with pytest.raises(RuntimeError) as exc_info:
        publish.check_payload(content, accept_unknowns=False)
    msg = str(exc_info.value)
    assert "payload carries unevaluated components" in msg
    assert "C1" in msg
    assert "C2" in msg
    assert "PH13" in msg
    assert "--accept-unknowns" in msg

    # Allowed with accept_unknowns=True
    publish.check_payload(content, accept_unknowns=True)


# -----------------------------------------------------------------------------
# 3. Default is draft; --publish is live write; --draft is no-op
# -----------------------------------------------------------------------------
def test_default_is_draft_and_publish_is_live(monkeypatch):
    transport = DummyTransport(index_results=[{"id": 42, "name": "Review", "slug": "review", "hudu_url": "http://h/a/42"}])
    monkeypatch.setattr(publish, "call_tool", transport.call_tool)

    # Default call: draft=True
    aid, action = publish.publish("fake-tok", 1, "Review", "content", draft=True)
    assert action == "edited"
    assert transport.calls[-1] == ("article_edit_tool", {"id": 42, "name": "Review", "content": "content", "draft": True})

    # --publish call: draft=False
    aid, action = publish.publish("fake-tok", 1, "Review", "content", draft=False)
    assert action == "edited"
    assert transport.calls[-1] == ("article_edit_tool", {"id": 42, "name": "Review", "content": "content", "draft": False})


# -----------------------------------------------------------------------------
# 4. Creating new article without --allow-create refused; allowed with it
# -----------------------------------------------------------------------------
def test_create_article_requires_allow_create(monkeypatch):
    transport = DummyTransport(index_results=[])  # No matching article
    monkeypatch.setattr(publish, "call_tool", transport.call_tool)

    # Without allow_create: refused
    with pytest.raises(RuntimeError) as exc_info:
        publish.publish("fake-tok", 1, "Brand New Article", "content", allow_create=False)
    assert "--allow-create" in str(exc_info.value)
    assert len(transport.calls) == 2  # Only two index searches (pass 1 and pass 2), no create tool called!

    # With allow_create: allowed
    aid, action = publish.publish("fake-tok", 1, "Brand New Article", "content", allow_create=True)
    assert action == "created"
    assert aid == 999
    assert transport.calls[-1] == ("article_create_tool", {"name": "Brand New Article", "content": "content", "company_id": 1, "draft": True})


# -----------------------------------------------------------------------------
# 5. normalize() treats hexadecimal entity difference as match
# -----------------------------------------------------------------------------
def test_normalize_hexadecimal_entities():
    s1 = "Documentation Review &#x2014; Client Name"
    s2 = "Documentation Review &#8212; Client Name"
    s3 = "Documentation Review — Client Name"
    assert publish.normalize(s1) == publish.normalize(s2)
    assert publish.normalize(s1) == publish.normalize(s3)


# -----------------------------------------------------------------------------
# 6. normalize() treats inserted-whitespace difference as match
# -----------------------------------------------------------------------------
def test_normalize_inserted_whitespace():
    s1 = "<div>   <p>Line 1</p>\n\n  <p>Line   2</p>  </div>"
    s2 = "<div> <p>Line 1</p> <p>Line 2</p> </div>"
    assert publish.normalize(s1) == publish.normalize(s2)


# -----------------------------------------------------------------------------
# 7. normalize() reports real difference as mismatch with divergence offset
# -----------------------------------------------------------------------------
def test_normalize_reports_real_difference():
    s1 = "<p>Prefix content and then divergent text here</p>"
    s2 = "<p>Prefix content and then altered text here</p>"
    same, report = publish.diff_report(s1, s2)
    assert same is False
    assert "first divergence at offset 27" in report
    assert "stored window:" in report
    assert "local window:" in report
    assert "stored length=" in report
    assert "local length=" in report


# -----------------------------------------------------------------------------
# Unit D Part 1: Explicit assertions 1-7 for normalize() and diff_report()
# -----------------------------------------------------------------------------
def test_normalize_whitespace_inserted_between_adjacent_tags():
    # 1. whitespace INSERTED between adjacent tags where the local copy has none compares as a match
    local = "<p>a</p><p>b</p>"
    stored = "<p>a</p>\n  <p>b</p>"
    assert publish.normalize(local) == publish.normalize(stored)
    same, _ = publish.diff_report(stored, local)
    assert same is True


def test_normalize_whitespace_run_between_tags_differing_length():
    # 2. a whitespace run between tags whose length differs compares as a match
    local = "<p>a</p> <p>b</p>"
    stored = "<p>a</p>   \n\t   <p>b</p>"
    assert publish.normalize(local) == publish.normalize(stored)
    same, _ = publish.diff_report(stored, local)
    assert same is True


def test_normalize_hexadecimal_entity_difference():
    # 3. a hexadecimal entity difference compares as a match
    local = "Documentation Review &#x2014; Client Name"
    stored = "Documentation Review — Client Name"
    assert publish.normalize(local) == publish.normalize(stored)
    same, _ = publish.diff_report(stored, local)
    assert same is True


def test_normalize_decimal_entity_difference():
    # 4. a decimal entity difference compares as a match
    local = "Documentation Review &#8212; Client Name"
    stored = "Documentation Review — Client Name"
    assert publish.normalize(local) == publish.normalize(stored)
    same, _ = publish.diff_report(stored, local)
    assert same is True


def test_normalize_text_node_difference_dropped_word_or_collapsed_space():
    # 5. a real difference inside a text node, such as a dropped word or a collapsed space, still compares as a mismatch
    # 5a: dropped word
    local_word = "<p>The quick brown fox jumps</p>"
    stored_word = "<p>The brown fox jumps</p>"
    assert publish.normalize(local_word) != publish.normalize(stored_word)
    same, report = publish.diff_report(stored_word, local_word)
    assert same is False
    assert "stored window:" in report

    # 5b: collapsed space
    local_space = "<p>The quick brown fox</p>"
    stored_space = "<p>Thequick brown fox</p>"
    assert publish.normalize(local_space) != publish.normalize(stored_space)
    same, report = publish.diff_report(stored_space, local_space)
    assert same is False
    assert "stored window:" in report


def test_normalize_structural_difference_missing_element():
    # 6. a real structural difference, such as a missing element, still compares as a mismatch
    local = "<div><p>Paragraph 1</p><p>Paragraph 2</p></div>"
    stored = "<div><p>Paragraph 1</p></div>"
    assert publish.normalize(local) != publish.normalize(stored)
    same, report = publish.diff_report(stored, local)
    assert same is False
    assert "stored window:" in report


def test_normalize_mismatch_divergence_offset_points_to_difference():
    # 7. on a mismatch the reported divergence offset points into the region that actually differs
    local = "<div><p>Prefix text and then divergent content here</p></div>"
    stored = "<div>\n  <p>Prefix text and then altered content here</p></div>"
    same, report = publish.diff_report(stored, local)
    assert same is False
    norm_local = publish.normalize(local)
    norm_stored = publish.normalize(stored)
    diff_idx = 0
    while diff_idx < min(len(norm_local), len(norm_stored)) and norm_local[diff_idx] == norm_stored[diff_idx]:
        diff_idx += 1
    assert f"first divergence at offset {diff_idx}" in report
    # The divergence offset points directly at where 'divergent' vs 'altered' starts:
    assert norm_local[diff_idx] == "d"
    assert norm_stored[diff_idx] == "a"
    assert "divergent" in report
    assert "altered" in report


# -----------------------------------------------------------------------------
# 8. Two exact matches refused, message lists every match with url
# -----------------------------------------------------------------------------
def test_multiple_matches_refused_with_urls(monkeypatch):
    existing = [
        {"id": 101, "name": "Review", "slug": "review", "hudu_url": "https://kb.example.com/a/review-101"},
        {"id": 102, "name": "Review", "slug": "review-102", "hudu_url": "https://kb.example.com/a/review-102"},
    ]
    transport = DummyTransport(index_results=existing)
    monkeypatch.setattr(publish, "call_tool", transport.call_tool)

    with pytest.raises(RuntimeError) as exc_info:
        publish.publish("fake-tok", 1, "Review", "content")
    msg = str(exc_info.value)
    assert "2 articles matching title 'Review' already exist" in msg
    assert "id=101" in msg and "https://kb.example.com/a/review-101" in msg
    assert "id=102" in msg and "https://kb.example.com/a/review-102" in msg
    assert "archived by hand" in msg


# -----------------------------------------------------------------------------
# 9. --dry-run performs no write
# -----------------------------------------------------------------------------
def test_dry_run_performs_no_write(monkeypatch):
    # Test edit path dry run
    transport_edit = DummyTransport(index_results=[{"id": 50, "name": "Review", "slug": "review", "hudu_url": "http://h/50"}])
    monkeypatch.setattr(publish, "call_tool", transport_edit.call_tool)
    aid, action = publish.publish("fake-tok", 1, "Review", "content", dry_run=True)
    assert action == "would-edit"
    assert aid == 50
    # Assert no article_edit_tool call
    assert not any(c[0] == "article_edit_tool" for c in transport_edit.calls)

    # Test create path dry run
    transport_create = DummyTransport(index_results=[])
    monkeypatch.setattr(publish, "call_tool", transport_create.call_tool)
    aid, action = publish.publish("fake-tok", 1, "Review", "content", dry_run=True, allow_create=True)
    assert action == "would-create"
    assert aid is None
    # Assert no article_create_tool call
    assert not any(c[0] == "article_create_tool" for c in transport_create.calls)


# -----------------------------------------------------------------------------
# 10. Payload above --max-bytes refused; --force-size allows it; size printed
# -----------------------------------------------------------------------------
def test_max_bytes_refusal_and_force_size(capsys):
    content = "x" * 35000

    # Without force_size: refused
    with pytest.raises(RuntimeError) as exc_info:
        publish.check_size(content, max_bytes=30000, force_size=False)
    msg = str(exc_info.value)
    assert "Payload size 35000 bytes exceeds limit of 30000 bytes" in msg
    assert "--force-size" in msg

    out, err = capsys.readouterr()
    assert "payload size: 35000 bytes (max: 30000)" in out

    # With force_size: allowed
    size = publish.check_size(content, max_bytes=30000, force_size=True)
    assert size == 35000
    out, err = capsys.readouterr()
    assert "payload size: 35000 bytes (max: 30000)" in out
    assert "continuing due to --force-size" in err


def test_slug_lookup_matches_slug(monkeypatch):
    # Lookup by title matches article whose slug matches normalized title
    existing = [{"id": 77, "name": "Old Title", "slug": "00-automated-documentation-review-findings", "hudu_url": "http://h/77"}]
    transport = DummyTransport(index_results=existing)
    monkeypatch.setattr(publish, "call_tool", transport.call_tool)

    matches, near = publish.find_articles("fake-tok", 1, "00 - Automated Documentation Review Findings")
    assert len(matches) == 1
    assert matches[0]["id"] == 77
