#!/usr/bin/env python3
"""Tests asserting render.py --inventory matches references/report-template.md and --check behaviour."""
import ast
import os
import re
import shutil
import subprocess
import sys
import tempfile

SCRIPTS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT_DIR = os.path.dirname(SCRIPTS_DIR)


def _extract_template_inventory():
    """Extract inventory markdown section from report-template.md."""
    template_path = os.path.join(ROOT_DIR, "references", "report-template.md")
    with open(template_path, "r", encoding="utf-8") as f:
        tmpl_text = f.read()

    start_marker = "### Client identity"
    end_marker = "\n---\n"
    start = tmpl_text.find(start_marker)
    assert start != -1, f"Marker {start_marker!r} not found in {template_path}"
    end = tmpl_text.find(end_marker, start)
    assert end != -1, f"End marker {end_marker!r} not found after inventory in {template_path}"

    return tmpl_text[start:end].strip()


def _copy_tree(tmpdir):
    """Copy the skill project tree to tmpdir excluding temporary/cache files."""
    dst = os.path.join(tmpdir, "skill")
    shutil.copytree(
        ROOT_DIR,
        dst,
        ignore=shutil.ignore_patterns(".git", ".pytest_cache", ".staging", "__pycache__"),
    )
    return dst


def _extract_skill_group_table_references():
    """Parse the group table in SKILL.md and return references/ paths."""
    skill_path = os.path.join(ROOT_DIR, "SKILL.md")
    with open(skill_path, "r", encoding="utf-8") as f:
        content = f.read()

    lines = content.splitlines()
    in_table = False
    rules_col_idx = None
    found_paths = set()
    for line in lines:
        line_str = line.strip()
        if line_str.startswith("|") and line_str.endswith("|"):
            cols = [c.strip() for c in line_str.split("|")[1:-1]]
            if "Rules file" in cols:
                rules_col_idx = cols.index("Rules file")
                in_table = True
                continue
            if in_table and rules_col_idx is not None:
                if all(set(c).issubset({"-", " ", ":"}) for c in cols):
                    continue
                if len(cols) > rules_col_idx:
                    cell = cols[rules_col_idx]
                    m = re.search(r"references/[A-Za-z0-9_\-\.]+", cell)
                    if m:
                        found_paths.add(m.group(0))
        else:
            in_table = False
            rules_col_idx = None
    return sorted(found_paths)


def _extract_render_group_metadata_files():
    """Extract rules file names from group_meta in scripts/render.py using AST."""
    render_path = os.path.join(SCRIPTS_DIR, "render.py")
    with open(render_path, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read())
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "group_meta":
                    files = []
                    for elt in node.value.elts:
                        if isinstance(elt, ast.Tuple) and len(elt.elts) >= 3:
                            files.append(elt.elts[2].value)
                    return files
    raise RuntimeError("group_meta not found in render.py")


def test_inventory_matches_template():
    """Output of render.py --inventory matches inventory section of report-template.md."""
    cmd = [sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "--inventory"]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"render.py --inventory failed: {res.stderr}"

    actual_inventory = res.stdout.strip()
    expected_inventory = _extract_template_inventory()

    assert actual_inventory == expected_inventory, (
        "render.py --inventory does not match inventory section of report-template.md"
    )


def test_render_check_clean_tree():
    """Clean tree: --check exits 0 on this tree and prints nothing."""
    cmd = [sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "--check"]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"render.py --check failed (rc={res.returncode}):\n{res.stdout}\n{res.stderr}"
    assert res.stdout == "", f"Expected empty stdout on clean tree, got:\n{res.stdout}"
    assert res.stderr == "", f"Expected empty stderr on clean tree, got:\n{res.stderr}"


def test_render_check_catches_version_drift():
    """Version drift is caught: Status != changelog causes non-zero exit and informative message."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dst = _copy_tree(tmpdir)
        rules_path = os.path.join(dst, "references", "client-identity.md")
        with open(rules_path, "r", encoding="utf-8") as f:
            content = f.read()

        assert "draft v0.6" in content, "Fixture assumption failed: expected draft v0.6 in client-identity.md"
        altered_content = content.replace("draft v0.6", "draft v0.5", 1)
        with open(rules_path, "w", encoding="utf-8") as f:
            f.write(altered_content)

        cmd = [sys.executable, os.path.join(dst, "scripts", "render.py"), "--check"]
        res = subprocess.run(cmd, capture_output=True, text=True)
        assert res.returncode != 0, f"Expected non-zero exit code on version drift, got {res.returncode}"
        assert "client-identity.md" in res.stdout, f"Message should name file, got: {res.stdout}"
        assert "v0.5" in res.stdout, f"Message should name status version v0.5, got: {res.stdout}"
        assert "v0.6" in res.stdout, f"Message should name changelog version v0.6, got: {res.stdout}"


def test_render_check_catches_inventory_drift():
    """Inventory drift is caught: altered component row in template inventory causes non-zero exit."""
    with tempfile.TemporaryDirectory() as tmpdir:
        dst = _copy_tree(tmpdir)
        tmpl_path = os.path.join(dst, "references", "report-template.md")
        with open(tmpl_path, "r", encoding="utf-8") as f:
            content = f.read()

        target_row = "| C1 | Agreement Clarity | Critical | 33 |"
        assert target_row in content, "Fixture assumption failed: target row not found in report-template.md"
        altered_content = content.replace(target_row, "| C1 | Agreement Clarity MODIFIED | Critical | 33 |", 1)
        with open(tmpl_path, "w", encoding="utf-8") as f:
            f.write(altered_content)

        cmd = [sys.executable, os.path.join(dst, "scripts", "render.py"), "--check"]
        res = subprocess.run(cmd, capture_output=True, text=True)
        assert res.returncode != 0, f"Expected non-zero exit code on inventory drift, got {res.returncode}"
        assert "report-template.md: inventory section does not match --inventory output" in res.stdout


def test_skill_rules_files_exist():
    """Every rules file named by SKILL.md group table must exist on disk."""
    skill_refs = _extract_skill_group_table_references()
    assert len(skill_refs) >= 6, f"Expected at least 6 rules files in SKILL.md group table, found: {skill_refs}"
    for ref_path in skill_refs:
        disk_path = os.path.join(ROOT_DIR, ref_path)
        assert os.path.isfile(disk_path), (
            f"Rules file named in SKILL.md group table does not exist: {disk_path}"
        )


def test_registry_group_metadata_files_exist():
    """The rules files named by the registry's group metadata in render.py must exist on disk."""
    files = _extract_render_group_metadata_files()
    assert len(files) >= 6, f"Expected at least 6 rules files in group_meta, found: {files}"
    for fname in files:
        disk_path = os.path.join(ROOT_DIR, "references", fname)
        assert os.path.isfile(disk_path), (
            f"Rules file named in render.py group_meta does not exist: {disk_path}"
        )
