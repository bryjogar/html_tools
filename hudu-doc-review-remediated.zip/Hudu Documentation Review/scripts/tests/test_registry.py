#!/usr/bin/env python3
"""Tests for the single-source rubric registry in scripts/rubric.py."""
import ast
import os
import sys
import pytest

SCRIPTS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, SCRIPTS_DIR)

import rubric
from rubric import (
    REGISTRY,
    SCOPE_LAYOUTS,
    SCOPE_ALL,
    GROUP_ORDER,
    SEV_ORDER,
    TIER,
    check_registry,
)
import coverage


def _extract_emitted_component_ids():
    """Extract all component IDs emitted in evaluate.py using AST analysis."""
    eval_path = os.path.join(SCRIPTS_DIR, "evaluate.py")
    with open(eval_path, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read())

    emitted = set()
    for node in ast.walk(tree):
        # Match F.add(asset, cid, sev, ...) or findings.add(...)
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Attribute) and func.attr == "add":
                if (
                    len(node.args) >= 2
                    and isinstance(node.args[1], ast.Constant)
                    and isinstance(node.args[1].value, str)
                ):
                    emitted.add(node.args[1].value)
        # Match direct findings dictionary with "component": "..."
        if isinstance(node, ast.Dict):
            for k, v in zip(node.keys, node.values):
                if isinstance(k, ast.Constant) and k.value == "component":
                    if isinstance(v, ast.Constant) and isinstance(v.value, str):
                        emitted.add(v.value)
    return emitted


def test_check_registry_passes():
    """check_registry() passes with no exceptions."""
    check_registry()


def test_all_registry_components_reachable_or_dormant():
    """Every component in REGISTRY is either emitted by evaluate.py or is C1, C2, PH13."""
    emitted = _extract_emitted_component_ids()
    dormant_or_prose = {"C1", "C2", "PH13"}
    unaccounted = set(REGISTRY.keys()) - (emitted | dormant_or_prose)
    assert not unaccounted, f"Components in REGISTRY not emitted or dormant: {unaccounted}"


def test_all_emitted_components_in_registry():
    """Every component emitted by evaluate.py appears in REGISTRY."""
    emitted = _extract_emitted_component_ids()
    unregistered = emitted - set(REGISTRY.keys())
    assert not unregistered, f"Components emitted by evaluate.py not in REGISTRY: {unregistered}"


def test_registry_structure_invariants():
    """Verify registry invariants: counts, tiers, orders, and sentinels."""
    assert len(REGISTRY) == 68
    assert len(SCOPE_LAYOUTS) == 31
    assert GROUP_ORDER == ["client-identity", "infrastructure", "services", "commercial", "physical"]
    assert SEV_ORDER == ["Critical", "High", "Medium", "Low"]
    assert TIER == {"Critical": 1, "High": 1, "Medium": 2, "Low": 3}

    # SCOPE_ALL contains all 31 layouts
    assert len(SCOPE_ALL) == 31
    for lid in SCOPE_LAYOUTS:
        assert lid in SCOPE_ALL


def test_scope_layouts_matches_coverage():
    """SCOPE_LAYOUTS matches coverage.py REVIEW_LAYOUTS exactly."""
    assert list(SCOPE_LAYOUTS) == list(coverage.REVIEW_LAYOUTS)


def test_check_registry_raises_on_invalid_group():
    """check_registry raises ValueError when a component has an invalid group."""
    orig = REGISTRY["C1"]["group"]
    try:
        REGISTRY["C1"]["group"] = "invalid-group"
        with pytest.raises(ValueError, match="invalid group"):
            check_registry()
    finally:
        REGISTRY["C1"]["group"] = orig


def test_check_registry_raises_on_invalid_severity():
    """check_registry raises ValueError when a component has an invalid severity."""
    orig = REGISTRY["C1"]["severity"]
    try:
        REGISTRY["C1"]["severity"] = "Urgent"
        with pytest.raises(ValueError, match="is not in SEV_ORDER"):
            check_registry()
    finally:
        REGISTRY["C1"]["severity"] = orig


def test_check_registry_raises_on_invalid_kind():
    """check_registry raises ValueError when a component has an invalid kind."""
    orig = REGISTRY["C1"]["kind"]
    try:
        REGISTRY["C1"]["kind"] = "manual"
        with pytest.raises(ValueError, match="is not one of"):
            check_registry()
    finally:
        REGISTRY["C1"]["kind"] = orig


def test_check_registry_raises_on_layout_outside_scope():
    """check_registry raises ValueError when a component declares a layout outside SCOPE_LAYOUTS."""
    orig = REGISTRY["C1"]["layouts"]
    try:
        REGISTRY["C1"]["layouts"] = [9999]
        with pytest.raises(ValueError, match="outside SCOPE_LAYOUTS"):
            check_registry()
    finally:
        REGISTRY["C1"]["layouts"] = orig
