#!/usr/bin/env python3
"""Tests for collection integrity and coverage gate (Unit C Part 2).

Covers all Part 2 requirements:
1. a stale asset row is removed by a subsequent collection, and the removal is reported.
2. a finding whose asset vanished is left in the ledger with status resolved.
3. a pagination response with no total_count exits non-zero and prints the reason.
4. render exits 2 when a layout in scope was never collected.
5. render with --allow-partial emits the banner naming the missing layouts.
6. an evaluator failure is printed and reported in the article as not reviewed.
"""
import io
import json
import os
import sqlite3
import subprocess
import sys
import time
import pytest

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPTS_DIR = os.path.dirname(TESTS_DIR)
if SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, SCRIPTS_DIR)
if TESTS_DIR not in sys.path:
    sys.path.insert(0, TESTS_DIR)

import collect
import render
from fixture_build import build_fixture
from rubric import SCOPE_LAYOUTS


# -----------------------------------------------------------------------------
# 1. Stale asset row is removed by subsequent collection and removal reported
# -----------------------------------------------------------------------------
def test_stale_asset_row_removed_and_reported(tmp_path, monkeypatch):
    monkeypatch.setenv("HUDU_STATE_DIR", str(tmp_path))
    monkeypatch.setattr(collect, "STATE", str(tmp_path))

    # First run: returns asset 101 and 102
    page1_data = [
        {"id": 101, "name": "Asset 1", "company_id": 1, "asset_layout_id": 2, "asset_layout_name": "Sites",
         "hudu_url": "http://h/a/1", "fields": [{"label": "Name", "value": "A1", "field_type": "Text", "position": 1}],
         "cards": [{"integrator_name": "CW", "data": {"foo": "bar"}}]},
        {"id": 102, "name": "Asset 2", "company_id": 1, "asset_layout_id": 2, "asset_layout_name": "Sites",
         "hudu_url": "http://h/a/2", "fields": [{"label": "Name", "value": "A2", "field_type": "Text", "position": 1}],
         "cards": []},
    ]

    def mock_call_tool_1(token, name, args, _id=1):
        return {"data": page1_data, "pagination": {"page": 1, "total_pages": 1, "total_count": 2}}

    monkeypatch.setattr(collect, "call_tool", mock_call_tool_1)
    got, total, path, removed = collect.collect("tok", 1, 2, per_page=25)
    assert got == 2
    assert removed == 0

    # Verify both assets in database
    con = sqlite3.connect(path)
    assert con.execute("select count(*) from assets").fetchone()[0] == 2
    assert con.execute("select count(*) from fields").fetchone()[0] == 2
    assert con.execute("select count(*) from cards").fetchone()[0] == 1
    con.close()

    # Artificially set fetched_at in the past so the next collection run can detect staleness
    con = sqlite3.connect(path)
    con.execute("update assets set fetched_at = fetched_at - 100")
    con.commit()
    con.close()

    # Second run: asset 101 is gone in Hudu (only 102 returned)
    page2_data = [
        {"id": 102, "name": "Asset 2", "company_id": 1, "asset_layout_id": 2, "asset_layout_name": "Sites",
         "hudu_url": "http://h/a/2", "fields": [{"label": "Name", "value": "A2", "field_type": "Text", "position": 1}],
         "cards": []},
    ]

    def mock_call_tool_2(token, name, args, _id=1):
        return {"data": page2_data, "pagination": {"page": 1, "total_pages": 1, "total_count": 1}}

    monkeypatch.setattr(collect, "call_tool", mock_call_tool_2)
    got2, total2, path2, removed2 = collect.collect("tok", 1, 2, per_page=25)
    assert got2 == 1
    assert removed2 == 1  # Exactly 1 stale asset removed!

    # Verify asset 101 is deleted and its fields/cards are gone
    con = sqlite3.connect(path)
    assert con.execute("select count(*) from assets").fetchone()[0] == 1
    assert con.execute("select id from assets").fetchone()[0] == 102
    assert con.execute("select count(*) from fields where asset_id = 101").fetchone()[0] == 0
    assert con.execute("select count(*) from cards where asset_id = 101").fetchone()[0] == 0
    con.close()


# -----------------------------------------------------------------------------
# 2. Finding whose asset vanished is left in ledger with status resolved
# -----------------------------------------------------------------------------
def test_vanished_asset_finding_marked_resolved(tmp_path):
    db_file = tmp_path / "777.sqlite"
    con = sqlite3.connect(str(db_file))
    con.executescript("""
    create table assets(id integer primary key, name text, company_id int, layout_id int, layout_name text, hudu_url text, raw text, fetched_at int);
    create table fields(asset_id int, label text, value text, field_type text, position int);
    create table cards(asset_id int, integrator text, data text);
    create table fetch_log(company_id int, layout_id int, page int, n int, bytes int, ts int);
    """)
    # Layout 3: Servers. Asset 301 missing OS -> High finding SV1/I2
    con.execute("insert into assets values(301, 'SRV-01', 777, 3, 'Servers', 'http://h/301', '{}', 1700000000)")
    con.execute("insert into fields values(301, 'Manufacturer', 'Dell', 'text', 1)")
    con.execute("insert into fields values(301, 'Model', 'PowerEdge', 'text', 2)")
    con.execute("insert into fields values(301, 'Device Type', 'Server', 'text', 3)")
    con.execute("insert into fields values(301, 'Operating System', '', 'text', 4)")
    con.execute("insert into fetch_log values(777, 3, 1, 1, 100, 1700000000)")
    con.commit()
    con.close()

    env = os.environ.copy()
    env["HUDU_STATE_DIR"] = str(tmp_path)

    # First evaluation: records open finding
    cmd = [sys.executable, os.path.join(SCRIPTS_DIR, "evaluate.py"), "777", "3", "Servers", "--json"]
    subprocess.run(cmd, env=env, capture_output=True, text=True, check=True)

    con = sqlite3.connect(str(db_file))
    findings = con.execute("select asset_id, status from findings where company_id = 777 and layout_id = 3").fetchall()
    assert len(findings) > 0
    assert all(st == "open" for aid, st in findings)
    con.close()

    # Simulate asset 301 vanishing / being deleted in Hudu:
    con = sqlite3.connect(str(db_file))
    con.execute("delete from assets where id = 301")
    con.execute("delete from fields where asset_id = 301")
    con.commit()
    con.close()

    # Re-evaluate: finding is not deleted, but marked resolved!
    subprocess.run(cmd, env=env, capture_output=True, text=True, check=True)

    con = sqlite3.connect(str(db_file))
    findings_after = con.execute("select asset_id, status from findings where company_id = 777 and layout_id = 3 and asset_id = '301'").fetchall()
    con.close()

    assert len(findings_after) > 0
    assert all(st == "resolved" for aid, st in findings_after)


# -----------------------------------------------------------------------------
# 3. Pagination response with no total_count exits non-zero and prints reason
# -----------------------------------------------------------------------------
def test_pagination_missing_total_count_exits_nonzero(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("HUDU_STATE_DIR", str(tmp_path))
    monkeypatch.setattr(collect, "STATE", str(tmp_path))

    # Pagination block lacks total_count
    def mock_call_tool(token, name, args, _id=1):
        return {"data": [], "pagination": {"page": 1, "total_pages": 1}}

    monkeypatch.setattr(collect, "call_tool", mock_call_tool)

    with pytest.raises(SystemExit) as exc_info:
        collect.collect("tok", 1, 2)
    assert exc_info.value.code != 0

    out, err = capsys.readouterr()
    assert "missing 'total_count'" in err
    assert "unverified collection" in err


# -----------------------------------------------------------------------------
# 4. Render exits 2 when a layout in scope was never collected
# -----------------------------------------------------------------------------
def test_render_exits_2_on_uncollected_layout(tmp_path):
    db_file = tmp_path / "999.sqlite"
    build_fixture(str(db_file), company_id=999)  # Fixture 999 only has 19 layouts collected

    env = os.environ.copy()
    env["HUDU_STATE_DIR"] = str(tmp_path)

    out_file = tmp_path / "out.html"
    cmd = [sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--out", str(out_file)]
    res = subprocess.run(cmd, env=env, capture_output=True, text=True)

    assert res.returncode == 2
    assert "Error: incomplete coverage" in res.stderr
    assert "6" in res.stderr or "8" in res.stderr or "15" in res.stderr


# -----------------------------------------------------------------------------
# 5. Render with --allow-partial emits banner naming missing layouts
# -----------------------------------------------------------------------------
def test_render_allow_partial_emits_banner(tmp_path):
    db_file = tmp_path / "999.sqlite"
    build_fixture(str(db_file), company_id=999)

    env = os.environ.copy()
    env["HUDU_STATE_DIR"] = str(tmp_path)

    out_file = tmp_path / "out.html"
    cmd = [sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial", "--out", str(out_file)]
    res = subprocess.run(cmd, env=env, capture_output=True, text=True)

    assert res.returncode == 0
    html = out_file.read_text(encoding="utf-8")
    expected_banner = "Partial review: 19 of 31 layouts collected. Missing: 6, 8, 9, 10, 11, 15, 16, 21, 23, 24, 30, 35. Findings for the missing layouts are absent, not clean."
    assert expected_banner in html
    # Assert banner is placed right after <h1>
    h1_idx = html.find("<h1>Documentation Review")
    banner_idx = html.find(expected_banner)
    assert h1_idx != -1 and banner_idx != -1
    assert banner_idx > h1_idx
    assert banner_idx < html.find("<h2>", h1_idx)


# -----------------------------------------------------------------------------
# 6. Evaluator failure is printed and reported in article as not reviewed
# -----------------------------------------------------------------------------
def test_evaluator_failure_printed_and_reported_not_reviewed(tmp_path, monkeypatch, capsys):
    # Setup a state db with all 31 layouts logged as collected
    db_file = tmp_path / "555.sqlite"
    con = sqlite3.connect(str(db_file))
    con.executescript("""
    create table assets(id integer primary key, name text, company_id int, layout_id int, layout_name text, hudu_url text, raw text, fetched_at int);
    create table fields(asset_id int, label text, value text, field_type text, position int);
    create table cards(asset_id int, integrator text, data text);
    create table fetch_log(company_id int, layout_id int, page int, n int, bytes int, ts int);
    """)
    for lid in SCOPE_LAYOUTS:
        con.execute("insert into fetch_log values(555, ?, 1, 0, 0, 1700000000)", (lid,))
    con.commit()
    con.close()

    monkeypatch.setenv("HUDU_STATE_DIR", str(tmp_path))
    monkeypatch.setattr(render, "STATE", str(tmp_path))

    # Mock evaluate.py subprocess run so layout 3 (Servers) fails with stderr
    orig_run = subprocess.run

    def mock_run(cmd, *args, **kwargs):
        if "evaluate.py" in cmd[1] and str(cmd[2]) == "555" and str(cmd[3]) == "3":
            # Simulate failure
            return subprocess.CompletedProcess(args=cmd, returncode=1, stdout="", stderr="Fatal error in server layout evaluation!")
        return orig_run(cmd, *args, **kwargs)

    monkeypatch.setattr(subprocess, "run", mock_run)

    out_file = tmp_path / "555.html"
    sys_argv = ["render.py", "555", "--out", str(out_file)]
    monkeypatch.setattr(sys, "argv", sys_argv)

    # Run render.py main logic
    out, failed_lids = render.run_evaluator(555)
    assert 3 in failed_lids

    captured = capsys.readouterr()
    assert "Evaluator failed for layout 3 (Servers)" in captured.err
    assert "Fatal error in server layout evaluation!" in captured.err

    # Render doc with failed_layouts
    doc = render.render(555, out, failed_layouts=failed_lids)
    assert "<h3>Servers</h3>" in doc
    assert "Not reviewed: evaluator failed." in doc
