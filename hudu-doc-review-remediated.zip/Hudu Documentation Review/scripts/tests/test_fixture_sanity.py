#!/usr/bin/env python3
"""Tests verifying the synthetic fixture covers all required cases and invariants."""
import json
import os
import sqlite3
import sys
import pytest

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
if TESTS_DIR not in sys.path:
    sys.path.insert(0, TESTS_DIR)

from fixture_build import build_fixture


@pytest.fixture(scope="module")
def fixture_db(tmp_path_factory):
    """Build the fixture database once for module testing."""
    tmp_dir = tmp_path_factory.mktemp("fixture_test")
    db_file = tmp_dir / "test_999.sqlite"
    build_fixture(str(db_file), company_id=999)
    return str(db_file)


def test_fixture_creates_required_tables(fixture_db):
    """Fixture database contains tables assets, fields, cards, fetch_log."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = {row[0] for row in cursor.fetchall()}
    conn.close()

    assert {"assets", "fields", "cards", "fetch_log"}.issubset(tables)


def test_fixture_contains_blank_field(fixture_db):
    """Fixture contains a field holding a blank string."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute("SELECT asset_id, label, value FROM fields WHERE value = ''")
    rows = cursor.fetchall()
    conn.close()

    assert len(rows) > 0, "No blank field value found in fixture"


def test_fixture_contains_na_field(fixture_db):
    """Fixture contains a field holding 'N/A'."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute("SELECT asset_id, label, value FROM fields WHERE value = 'N/A'")
    rows = cursor.fetchall()
    conn.close()

    assert len(rows) > 0, "No 'N/A' field value found in fixture"


def test_fixture_contains_none_field(fixture_db):
    """Fixture contains a field holding 'None'."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute("SELECT asset_id, label, value FROM fields WHERE value = 'None'")
    rows = cursor.fetchall()
    conn.close()

    assert len(rows) > 0, "No 'None' field value found in fixture"


def test_fixture_contains_unknown_field(fixture_db):
    """Fixture contains a field holding 'Unknown'."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute("SELECT asset_id, label, value FROM fields WHERE value = 'Unknown'")
    rows = cursor.fetchall()
    conn.close()

    assert len(rows) > 0, "No 'Unknown' field value found in fixture"


def test_fixture_contains_heading_field(fixture_db):
    """Fixture contains a Heading-type field."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute("SELECT asset_id, label, field_type FROM fields WHERE field_type = 'Heading'")
    rows = cursor.fetchall()
    conn.close()

    assert len(rows) > 0, "No 'Heading' field_type found in fixture"


def test_fixture_contains_empty_relation_array(fixture_db):
    """Fixture contains a relation field holding an empty JSON array '[]'."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute("SELECT asset_id, label, value FROM fields WHERE value = '[]'")
    rows = cursor.fetchall()
    conn.close()

    assert len(rows) > 0, "No empty relation array '[]' found in fixture"


def test_fixture_contains_duplicate_mac(fixture_db):
    """Fixture contains two assets sharing a MAC address."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT value, count(distinct asset_id) FROM fields "
        "WHERE label = 'MAC Address' GROUP BY value HAVING count(distinct asset_id) >= 2"
    )
    rows = cursor.fetchall()
    conn.close()

    assert len(rows) > 0, "No duplicate MAC address pair found in fixture"


def test_fixture_contains_placeholder_name(fixture_db):
    """Fixture contains an asset whose name is a placeholder (Device@10.0.0.1)."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name FROM assets WHERE name = 'Device@10.0.0.1'")
    rows = cursor.fetchall()
    conn.close()

    assert len(rows) > 0, "Placeholder asset 'Device@10.0.0.1' not found in fixture"


def test_fixture_contains_paired_and_unpaired_ups(fixture_db):
    """Fixture contains one UPS with a matching UPS Battery and one UPS with no battery."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT a.id, a.name, f.value FROM assets a "
        "JOIN fields f ON a.id = f.asset_id "
        "WHERE a.layout_id = 36 AND f.label = 'Device Type'"
    )
    rows = cursor.fetchall()
    conn.close()

    ups_names = {name for aid, name, val in rows if val == "UPS"}
    battery_names = {name for aid, name, val in rows if val == "UPS Battery"}

    assert "UPS-Main" in ups_names, "UPS-Main not found"
    assert "UPS-Solo" in ups_names, "UPS-Solo not found"
    assert any("UPS-Main" in b for b in battery_names), "Matching UPS Battery not found for UPS-Main"
    assert not any("UPS-Solo" in b for b in battery_names), "UPS-Solo unexpectedly has matching battery"


def test_fixture_contains_client_overview_prose(fixture_db):
    """Fixture contains Client Overview prose fields Support Details & Exceptions and Preferred Maintenance Window."""
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT f.label, f.value FROM fields f "
        "JOIN assets a ON a.id = f.asset_id "
        "WHERE a.layout_id = 33"
    )
    rows = dict(cursor.fetchall())
    conn.close()

    has_support = any("support details" in k.lower() for k in rows.keys())
    has_maint = any("maintenance window" in k.lower() for k in rows.keys())

    assert has_support, "Support Details prose field not found in layout 33"
    assert has_maint, "Preferred Maintenance Window prose field not found in layout 33"


def test_fixture_includes_required_layouts(fixture_db):
    """Fixture includes at least layout ids: 33, 2, 3, 4, 17, 18, 25, 29, 27, 13, 14, 12, 19, 32, 22, 5, 20, 36, 34."""
    required_lids = {33, 2, 3, 4, 17, 18, 25, 29, 27, 13, 14, 12, 19, 32, 22, 5, 20, 36, 34}
    conn = sqlite3.connect(fixture_db)
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT layout_id FROM assets")
    present_lids = {row[0] for row in cursor.fetchall()}
    conn.close()

    missing = required_lids - present_lids
    assert not missing, f"Missing required layout ids in fixture: {missing}"
