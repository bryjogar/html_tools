#!/usr/bin/env python3
"""Regression test asserting rendered HTML is byte identical to golden file."""
import os
import subprocess
import sys

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
if TESTS_DIR not in sys.path:
    sys.path.insert(0, TESTS_DIR)

from fixture_build import build_fixture


def test_golden_render(tmp_path):
    """Build fixture in temp dir, render with HUDU_STATE_DIR, compare with golden file."""
    db_file = tmp_path / "999.sqlite"
    build_fixture(str(db_file), company_id=999)

    out_file = tmp_path / "999.html"
    env = os.environ.copy()
    env["HUDU_STATE_DIR"] = str(tmp_path)

    scripts_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cmd = [sys.executable, os.path.join(scripts_dir, "render.py"), "999", "--allow-partial", "--out", str(out_file)]
    res = subprocess.run(cmd, env=env, capture_output=True, text=True)
    assert res.returncode == 0, f"render.py failed: {res.stderr}"

    golden_path = os.path.join(TESTS_DIR, "golden", "999.html")
    with open(golden_path, "r", encoding="utf-8") as f:
        golden_content = f.read()

    with open(out_file, "r", encoding="utf-8") as f:
        rendered_content = f.read()

    if rendered_content != golden_content:
        import difflib
        diff = "\n".join(difflib.unified_diff(
            golden_content.splitlines(),
            rendered_content.splitlines(),
            fromfile=f"golden/999.html",
            tofile="fresh_render",
            lineterm="",
        ))
        assert rendered_content == golden_content, (
            f"Golden file does not match fresh render! A forgotten regeneration must be loud, not silent.\n"
            f"Golden file: {golden_path}\n"
            f"If this change is intentional, regenerate the golden file and document the hunks and justification in CHANGELOG.md.\n"
            f"Diff:\n{diff}"
        )


def test_golden_matches_fresh_render(tmp_path):
    """Explicit test asserting golden file in the tree matches fresh render; fails loudly on mismatch."""
    test_golden_render(tmp_path)


def test_golden_render_deterministic(tmp_path):
    """Render twice and verify outputs are identical."""
    db_file = tmp_path / "999.sqlite"
    build_fixture(str(db_file), company_id=999)

    env = os.environ.copy()
    env["HUDU_STATE_DIR"] = str(tmp_path)
    scripts_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    out1 = tmp_path / "out1.html"
    out2 = tmp_path / "out2.html"
    cmd1 = [sys.executable, os.path.join(scripts_dir, "render.py"), "999", "--allow-partial", "--out", str(out1)]
    cmd2 = [sys.executable, os.path.join(scripts_dir, "render.py"), "999", "--allow-partial", "--out", str(out2)]

    res1 = subprocess.run(cmd1, env=env, capture_output=True, text=True)
    res2 = subprocess.run(cmd2, env=env, capture_output=True, text=True)

    assert res1.returncode == 0
    assert res2.returncode == 0
    assert out1.read_text(encoding="utf-8") == out2.read_text(encoding="utf-8")


def test_golden_header_layouts_count():
    """Verify golden HTML reports exactly 31 layouts reviewed."""
    golden_path = os.path.join(TESTS_DIR, "golden", "999.html")
    with open(golden_path, "r", encoding="utf-8") as f:
        content = f.read()
    assert "31 layouts reviewed" in content or "layouts reviewed: 31" in content


def test_golden_changelog_rule_and_entries():
    """Verify CHANGELOG.md exists, states rule at top, and contains all seeded entries."""
    changelog_path = os.path.join(TESTS_DIR, "golden", "CHANGELOG.md")
    assert os.path.isfile(changelog_path), "CHANGELOG.md missing in golden directory"
    with open(changelog_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Rule in one sentence
    rule = "a golden file changes only with an entry here, in the same commit, and never inside a commit whose message is about behaviour"
    assert rule in content.lower(), "CHANGELOG.md must state rule at the top"

    # Seeded entries
    assert "pre-change capture" in content.lower()
    assert "layout-7" in content.lower()
    assert "partial-review banner" in content.lower()

