#!/usr/bin/env python3
"""Build a synthetic SQLite database with the exact schema collect.py creates.

Populates company_id 999 with deterministic synthetic data exercising all
required evaluation paths.
"""
import json
import os
import sqlite3
import sys

FIXED_TS = 1700000000

SCHEMA = """
create table if not exists assets(
  id integer primary key, name text, company_id int, layout_id int,
  layout_name text, hudu_url text, raw text, fetched_at int);
create table if not exists fields(
  asset_id int, label text, value text, field_type text, position int);
create table if not exists cards(
  asset_id int, integrator text, data text);
create table if not exists fetch_log(
  company_id int, layout_id int, page int, n int, bytes int, ts int);
"""


def build_fixture(path, company_id=999):
    if os.path.exists(path):
        os.remove(path)
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    c = sqlite3.connect(path)
    c.executescript(SCHEMA)

    company_name = "Synthetic Test Client"

    # Layout definitions to include:
    # 33, 2, 3, 4, 17, 18, 25, 29, 27, 13, 14, 12, 19, 32, 22, 5, 20, 36, 34
    layouts_meta = {
        33: "Client Overview",
        2: "Sites",
        3: "Servers",
        4: "Network Devices",
        17: "WAN",
        18: "LAN",
        25: "Wi-Fi",
        29: "SSIDs",
        27: "IPMI",
        13: "Applications & Services",
        14: "Backups",
        12: "Identity Providers (IdP)",
        19: "Licensing",
        32: "Contracts",
        22: "Vendors",
        5: "Printers & Scanners",
        20: "Printing",
        36: "Power Management",
        34: "Security & Compliance",
    }

    assets_data = [
        # Layout 33: Client Overview
        {
            "id": 101,
            "name": "Overview",
            "layout_id": 33,
            "fields": [
                ("Support Details & Exceptions", "Standard 8-5 M-F support. No weekend coverage.", "RichText", 1),
                ("Support Details and Exceptions", "Standard 8-5 M-F support. No weekend coverage.", "RichText", 2),
                ("Preferred Maintenance Window", "Saturday 22:00-02:00", "Text", 3),
                ("Primary POC", json.dumps([{"id": 1, "name": "Alice Smith"}]), "Contacts", 4),
                ("Access Authorizers", json.dumps([{"id": 1, "name": "Alice Smith"}]), "Contacts", 5),
                ("Emergency Contacts", json.dumps([{"id": 1, "name": "Alice Smith"}]), "Contacts", 6),
                ("Services", "Servers, Network", "Checkboxes", 7),
                ("General Info Heading", "", "Heading", 8),
                ("Notes", "N/A", "Text", 9),
            ],
            "cards": [],
        },
        # Layout 2: Sites
        {
            "id": 201,
            "name": "Main Office",
            "layout_id": 2,
            "fields": [
                ("Site", "[]", "AssetTag", 1),
                ("Blank Field", "", "Text", 2),
            ],
            "cards": [
                ("ConnectWise", json.dumps({"addressLine1": "100 Main St", "city": "Dallas", "zip": "75001"})),
            ],
        },
        {
            "id": 202,
            "name": "cloud",
            "layout_id": 2,
            "fields": [],
            "cards": [],
        },
        # Layout 3: Servers (two assets sharing a MAC)
        {
            "id": 301,
            "name": "SRV-DC01",
            "layout_id": 3,
            "fields": [
                ("Device Type", "Server", "Text", 1),
                ("Operating System", "Windows Server 2022", "Text", 2),
                ("Manufacturer", "Dell", "Text", 3),
                ("Model", "PowerEdge R640", "Text", 4),
                ("Primary IP", "192.168.1.10", "Text", 5),
                ("Site", json.dumps([{"id": 201, "name": "Main Office"}]), "AssetTag", 6),
                ("MAC Address", "00:11:22:33:44:55", "Text", 7),
                ("Serial Number", "Unknown", "Text", 8),
                ("Secondary", "None", "Text", 9),
            ],
            "cards": [],
        },
        {
            "id": 302,
            "name": "SRV-DC02",
            "layout_id": 3,
            "fields": [
                ("Device Type", "Server", "Text", 1),
                ("Operating System", "Windows Server 2022", "Text", 2),
                ("Manufacturer", "Dell", "Text", 3),
                ("Model", "PowerEdge R640", "Text", 4),
                ("Primary IP", "192.168.1.11", "Text", 5),
                ("Site", json.dumps([{"id": 201, "name": "Main Office"}]), "AssetTag", 6),
                ("MAC Address", "00:11:22:33:44:55", "Text", 7),
                ("Serial Number", "ABC1234", "Text", 8),
            ],
            "cards": [],
        },
        # Layout 4: Network Devices (includes a placeholder name)
        {
            "id": 401,
            "name": "Device@10.0.0.1",
            "layout_id": 4,
            "fields": [
                ("Device Type", "Switch", "Text", 1),
                ("Manufacturer", "Cisco", "Text", 2),
                ("Model", "Catalyst 2960", "Text", 3),
                ("Primary IP", "10.0.0.1", "Text", 4),
                ("Site", json.dumps([{"id": 201, "name": "Main Office"}]), "AssetTag", 5),
            ],
            "cards": [],
        },
        # Layout 17: WAN
        {
            "id": 1701,
            "name": "Primary WAN - AT&T",
            "layout_id": 17,
            "fields": [
                ("Circuit ID", "ATT-CIR-9999", "Text", 1),
                ("Carrier", "AT&T", "Text", 2),
                ("Site", json.dumps([{"id": 201, "name": "Main Office"}]), "AssetTag", 3),
                ("Static IP(s)", "203.0.113.1", "Text", 4),
            ],
            "cards": [],
        },
        # Layout 18: LAN
        {
            "id": 1801,
            "name": "Corporate Data VLAN",
            "layout_id": 18,
            "fields": [
                ("Subnet", "192.168.10.0/24", "Text", 1),
                ("VLAN ID", "10", "Text", 2),
                ("Site", json.dumps([{"id": 201, "name": "Main Office"}]), "AssetTag", 3),
                ("Gateway IP", "192.168.10.1", "Text", 4),
            ],
            "cards": [],
        },
        # Layout 25: Wi-Fi
        {
            "id": 2501,
            "name": "Main Office Wi-Fi",
            "layout_id": 25,
            "fields": [
                ("Site", json.dumps([{"id": 201, "name": "Main Office"}]), "AssetTag", 1),
                ("SSID(s)", "[]", "AssetTag", 2),
                ("Wireless Access Point(s)", "[]", "AssetTag", 3),
            ],
            "cards": [],
        },
        # Layout 29: SSIDs
        {
            "id": 2901,
            "name": "Corp-Secure",
            "layout_id": 29,
            "fields": [
                ("Security Type", "WPA3 Enterprise", "Text", 1),
                ("Broadcast SSID", "1", "Checkbox", 2),
                ("LAN", "[]", "AssetTag", 3),
            ],
            "cards": [],
        },
        # Layout 27: IPMI
        {
            "id": 2701,
            "name": "iDRAC SRV-DC01",
            "layout_id": 27,
            "fields": [
                ("IP Address", "192.168.1.20", "Text", 1),
                ("Associated Server", json.dumps([{"id": 301, "name": "SRV-DC01"}]), "AssetTag", 2),
            ],
            "cards": [],
        },
        # Layout 13: Applications & Services
        {
            "id": 1301,
            "name": "Accounting Software",
            "layout_id": 13,
            "fields": [
                ("Application Type", "Accounting", "Text", 1),
                ("Application Location", "Cloud", "Text", 2),
                ("Hosted System URL", "https://app.example.com", "Text", 3),
                ("Application Champion", "[]", "AssetTag", 4),
            ],
            "cards": [],
        },
        # Layout 14: Backups
        {
            "id": 1401,
            "name": "Daily Veeam Backup",
            "layout_id": 14,
            "fields": [
                ("Backup Type", "Image", "Text", 1),
                ("Backup Frequency", "Daily", "Text", 2),
                ("Offsite Storage Provider", "Wasabi", "Text", 3),
                ("Protected Systems", "[]", "AssetTag", 4),
            ],
            "cards": [],
        },
        # Layout 12: Identity Providers (IdP)
        {
            "id": 1201,
            "name": "Microsoft Entra ID",
            "layout_id": 12,
            "fields": [
                ("IdP Type", "Cloud", "Text", 1),
                ("Primary Domain", "example.com", "Text", 2),
            ],
            "cards": [],
        },
        # Layout 19: Licensing
        {
            "id": 1901,
            "name": "Microsoft 365 Business Premium",
            "layout_id": 19,
            "fields": [
                ("License Type", "Subscription", "Text", 1),
                ("Seats", "50", "Text", 2),
                ("Expiration Date", "2027-01-01", "Text", 3),
            ],
            "cards": [],
        },
        # Layout 32: Contracts
        {
            "id": 3201,
            "name": "Internet Service Agreement",
            "layout_id": 32,
            "fields": [
                ("Contract Type", "Service", "Text", 1),
                ("Vendor", "[]", "AssetTag", 2),
                ("Account Number", "ACT-12345", "Text", 3),
                ("Term", "36 Months", "Text", 4),
            ],
            "cards": [],
        },
        # Layout 22: Vendors
        {
            "id": 2201,
            "name": "Dell Technologies",
            "layout_id": 22,
            "fields": [
                ("Support Phone", "1-800-555-DELL", "Text", 1),
                ("Support Portal", "https://support.dell.com", "Text", 2),
            ],
            "cards": [],
        },
        # Layout 5: Printers & Scanners
        {
            "id": 501,
            "name": "PRN-OFFICE-01",
            "layout_id": 5,
            "fields": [
                ("Device Type", "Printer", "Text", 1),
                ("Manufacturer", "HP", "Text", 2),
                ("Model", "LaserJet Pro", "Text", 3),
                ("Primary IP", "192.168.1.50", "Text", 4),
                ("Site", "[]", "AssetTag", 5),
            ],
            "cards": [],
        },
        # Layout 20: Printing
        {
            "id": 2001,
            "name": "Office Follow-Me Queue",
            "layout_id": 20,
            "fields": [
                ("Deployment", "Manual", "Text", 1),
                ("Printers", "[]", "AssetTag", 2),
            ],
            "cards": [],
        },
        # Layout 36: Power Management (one UPS with battery, one without)
        {
            "id": 3601,
            "name": "UPS-Main",
            "layout_id": 36,
            "fields": [
                ("Device Type", "UPS", "Text", 1),
                ("Manufacturer", "APC", "Text", 2),
                ("Model", "Smart-UPS 1500", "Text", 3),
                ("Primary IP", "192.168.1.90", "Text", 4),
                ("Site", json.dumps([{"id": 201, "name": "Main Office"}]), "AssetTag", 5),
            ],
            "cards": [],
        },
        {
            "id": 3602,
            "name": "UPS-Main Battery",
            "layout_id": 36,
            "fields": [
                ("Device Type", "UPS Battery", "Text", 1),
                ("Manufacturer", "APC", "Text", 2),
                ("Model", "RBC7", "Text", 3),
                ("Site", json.dumps([{"id": 201, "name": "Main Office"}]), "AssetTag", 4),
            ],
            "cards": [],
        },
        {
            "id": 3603,
            "name": "UPS-Solo",
            "layout_id": 36,
            "fields": [
                ("Device Type", "UPS", "Text", 1),
                ("Manufacturer", "CyberPower", "Text", 2),
                ("Model", "OR1500LCDRT2U", "Text", 3),
                ("Primary IP", "192.168.1.95", "Text", 4),
                ("Site", json.dumps([{"id": 201, "name": "Main Office"}]), "AssetTag", 5),
            ],
            "cards": [],
        },
        # Layout 34: Security & Compliance
        {
            "id": 3401,
            "name": "Endpoint Security Policy",
            "layout_id": 34,
            "fields": [
                ("EDR Deployed", "1", "Checkbox", 1),
                ("MFA Enforced", "1", "Checkbox", 2),
            ],
            "cards": [],
        },
    ]

    for a in assets_data:
        lid = a["layout_id"]
        lname = layouts_meta.get(lid, f"Layout {lid}")
        hudu_url = f"https://kb.enabletech.com/a/{a['name'].lower().replace(' ', '-')}-{a['id']}"
        raw = json.dumps({
            "id": a["id"],
            "name": a["name"],
            "company_id": company_id,
            "company_name": company_name,
            "asset_layout_id": lid,
            "asset_layout_name": lname,
            "hudu_url": hudu_url,
        })
        c.execute("insert into assets values(?,?,?,?,?,?,?,?)",
                  (a["id"], a["name"], company_id, lid, lname, hudu_url, raw, FIXED_TS))
        for fld in a.get("fields", []):
            label, val, ftype, pos = fld
            c.execute("insert into fields values(?,?,?,?,?)",
                      (a["id"], label, val, ftype, pos))
        for card in a.get("cards", []):
            integrator, data = card
            c.execute("insert into cards values(?,?,?)",
                      (a["id"], integrator, data))

    # Log fetches for the layouts included
    for lid in layouts_meta:
        c.execute("insert into fetch_log values(?,?,?,?,?,?)",
                  (company_id, lid, 1, 1, 1024, FIXED_TS))

    c.commit()
    c.close()
    return path


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "..", "state", "999.sqlite"
    )
    build_fixture(out)
    print(f"Fixture built at {out}")
