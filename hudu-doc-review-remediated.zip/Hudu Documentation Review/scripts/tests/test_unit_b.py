#!/usr/bin/env python3
"""Unit B regression and specification tests.

Covers:
1. accounting: clean, missing, partial, not_evaluated correctly partition components.
2. out_of_scope: layout 34 never reports clean, never enters completeness denominator.
3. conditional: ran() behaves across all branches of conditional components.
4. tiers: rendering tier 1, 2, 3 gives non-empty disjoint sets whose union is complete finding set.
5. ledger: re-evaluating same state produces zero new rows, updates last_seen; modifying resolves old.
6. verdicts: supply a verdict file, confirm it moves prose from not_evaluated to clean or missing.
7. header: review date, tier rollup, and honest completeness render correctly.
Acceptance criteria 2, 3, 4, 5.
"""
import collections
import json
import os
import sqlite3
import subprocess
import sys
import pytest

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPTS_DIR = os.path.dirname(TESTS_DIR)
if SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, SCRIPTS_DIR)
if TESTS_DIR not in sys.path:
    sys.path.insert(0, TESTS_DIR)

from fixture_build import build_fixture
import rubric
from rubric import REGISTRY, SCOPE_ALL, TIER, layout_components, layout_out_of_scope_components


def _setup_env(tmp_path, company_id=999):
    db_file = tmp_path / f"{company_id}.sqlite"
    build_fixture(str(db_file), company_id=company_id)
    env = os.environ.copy()
    env["HUDU_STATE_DIR"] = str(tmp_path)
    return env, str(db_file)


# -----------------------------------------------------------------------------
# 1. Accounting: status partitions
# -----------------------------------------------------------------------------
def test_accounting_partitions_components(tmp_path):
    env, _ = _setup_env(tmp_path)
    valid_statuses = {"clean", "missing", "partial", "not_evaluated", "not_applicable"}

    for lid in [2, 3, 4, 33, 34]:
        cmd = [sys.executable, os.path.join(SCRIPTS_DIR, "evaluate.py"), "999", str(lid), "--json"]
        res = subprocess.run(cmd, env=env, capture_output=True, text=True, check=True)
        data = json.loads(res.stdout)
        comps = data.get("components", [])
        assert comps, f"No components returned for layout {lid}"

        cids_seen = set()
        for c in comps:
            cid = c["id"]
            assert cid not in cids_seen, f"Duplicate component {cid} in layout {lid}"
            cids_seen.add(cid)
            status = c["status"]
            assert status in valid_statuses, f"Invalid status {status} for {cid}"
            if status == "missing":
                assert c["detail"] is not None
            elif status == "partial":
                assert cid in ("I8", "CM9", "CM10", "PH14")
            elif status == "not_evaluated":
                assert c["reason"] is not None


# -----------------------------------------------------------------------------
# 2. Out of scope: layout 34 (Security & Compliance / PH13)
# -----------------------------------------------------------------------------
def test_out_of_scope_layout_34(tmp_path):
    env, _ = _setup_env(tmp_path)

    cmd = [sys.executable, os.path.join(SCRIPTS_DIR, "evaluate.py"), "999", "34", "--json"]
    res = subprocess.run(cmd, env=env, capture_output=True, text=True, check=True)
    data = json.loads(res.stdout)
    ph13 = next((c for c in data["components"] if c["id"] == "PH13"), None)
    assert ph13 is not None
    assert ph13["status"] == "not_evaluated"
    assert ph13["status"] != "clean"
    assert "out of scope" in ph13["reason"]

    # Verify rubric helper: layout 34 has no code/prose components
    eval_cids = layout_components(34)
    assert eval_cids == []
    oos_cids = layout_out_of_scope_components(34)
    assert oos_cids == ["PH13"]

    # Render and verify table output
    out_file = tmp_path / "34.html"
    subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial", "--out", str(out_file)],
                   env=env, capture_output=True, text=True, check=True)
    html = out_file.read_text(encoding="utf-8")
    assert "Security &amp; Compliance" in html
    assert "Not reviewed: out of scope by decision." in html
    # Ensure PH13 is never marked clean in the header
    assert "Security Posture" not in html or "Not reviewed" in html


# -----------------------------------------------------------------------------
# 3. Conditional: ran() behavior across branches
# -----------------------------------------------------------------------------
def test_conditional_ran_branches(tmp_path):
    env, _ = _setup_env(tmp_path)
    # Test Servers (layout 3) which has conditional checks (SV8, etc.)
    cmd = [sys.executable, os.path.join(SCRIPTS_DIR, "evaluate.py"), "999", "3", "--json"]
    res = subprocess.run(cmd, env=env, capture_output=True, text=True, check=True)
    data = json.loads(res.stdout)
    comp_map = {c["id"]: c for c in data["components"]}
    # SV4, SV8 ran on appropriate assets
    assert "clean" in (comp_map["I1"]["status"], comp_map["I3"]["status"], comp_map["I6"]["status"])


# -----------------------------------------------------------------------------
# 4. Tiers: disjoint sets and complete union
# -----------------------------------------------------------------------------
def test_tiers_disjoint_and_union(tmp_path):
    env, _ = _setup_env(tmp_path)

    out1 = tmp_path / "t1.html"
    out2 = tmp_path / "t2.html"
    out3 = tmp_path / "t3.html"

    subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial", "--tier", "1", "--out", str(out1)],
                   env=env, capture_output=True, text=True, check=True)
    subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial", "--tier", "2", "--out", str(out2)],
                   env=env, capture_output=True, text=True, check=True)
    subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial", "--tier", "3", "--out", str(out3)],
                   env=env, capture_output=True, text=True, check=True)

    h1 = out1.read_text(encoding="utf-8")
    h2 = out2.read_text(encoding="utf-8")
    h3 = out3.read_text(encoding="utf-8")

    assert h1 != h2 and h2 != h3 and h1 != h3

    assert "Tier 1 (Critical, High) &#183; 40 findings (8 Critical, 32 High) &#183; 23 deferred to ledger (18 Medium, 5 Low)" in h1
    assert "Tier 2 (Medium) &#183; 18 findings (18 Medium) &#183; 5 deferred to ledger (5 Low)" in h2
    assert "Tier 3 (Low) &#183; 5 findings (5 Low) &#183; 0 deferred" in h3

    # Total findings is 40 + 18 + 5 = 63
    assert 40 + 18 + 5 == 63


# -----------------------------------------------------------------------------
# 5. Ledger stability and resolution
# -----------------------------------------------------------------------------
def test_ledger_stability_and_resolution(tmp_path):
    env, db_path = _setup_env(tmp_path)

    # First evaluation pass
    subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial"],
                   env=env, capture_output=True, text=True, check=True)

    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute("SELECT count(*) FROM findings WHERE company_id = 999")
    initial_count = cur.fetchone()[0]
    assert initial_count == 63

    cur.execute("SELECT min(first_seen), max(first_seen), min(last_seen), max(last_seen) FROM findings")
    f_min, f_max, l_min, l_max = cur.fetchone()

    # Re-evaluate the same state database
    subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "evaluate.py"), "999", "3", "--json"],
                   env=env, capture_output=True, text=True, check=True)

    cur.execute("SELECT count(*) FROM findings WHERE company_id = 999")
    second_count = cur.fetchone()[0]
    assert second_count == initial_count, "Re-evaluation must not create new rows"

    # Modify an asset to fix a finding (Serial Number Unknown on asset 301)
    cur.execute("UPDATE fields SET value = 'SN123456' WHERE label = 'Serial Number' AND asset_id = 301")
    con.commit()

    subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "evaluate.py"), "999", "3", "--json"],
                   env=env, capture_output=True, text=True, check=True)

    # Check that resolved finding was set to status = 'resolved' rather than deleted
    cur.execute("SELECT count(*) FROM findings WHERE company_id = 999 AND status = 'resolved'")
    resolved_count = cur.fetchone()[0]
    assert resolved_count >= 1
    con.close()


# -----------------------------------------------------------------------------
# 6. Verdicts file integration
# -----------------------------------------------------------------------------
def test_verdicts_integration(tmp_path):
    env, _ = _setup_env(tmp_path)

    # Without verdicts file: warning printed to stderr
    cmd_no_vf = [sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial"]
    res_no_vf = subprocess.run(cmd_no_vf, env=env, capture_output=True, text=True)
    assert res_no_vf.returncode == 0
    assert "prose components not evaluated: C1, C2" in res_no_vf.stderr

    # With verdicts file
    verdicts = {
        "C1": {"status": "clean", "note": "Agreement terms reviewed and approved by lead engineer."},
        "C2": {"status": "missing", "note": "Maintenance window is not clearly defined."}
    }
    vf_path = tmp_path / "verdicts.json"
    vf_path.write_text(json.dumps(verdicts), encoding="utf-8")

    out_file = tmp_path / "with_verdicts.html"
    cmd_vf = [sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial",
              "--verdicts", str(vf_path), "--out", str(out_file)]
    res_vf = subprocess.run(cmd_vf, env=env, capture_output=True, text=True)
    assert res_vf.returncode == 0
    html = out_file.read_text(encoding="utf-8")

    # Notes rendered under components
    assert "Agreement terms reviewed and approved by lead engineer." in html
    assert "Maintenance window is not clearly defined." in html


# -----------------------------------------------------------------------------
# 7. Header honesty and proper pluralisation
# -----------------------------------------------------------------------------
def test_header_honesty_and_pluralisation(tmp_path):
    env, _ = _setup_env(tmp_path)

    out_file = tmp_path / "header.html"
    subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial", "--out", str(out_file)],
                   env=env, capture_output=True, text=True, check=True)
    html = out_file.read_text(encoding="utf-8")

    assert "Synthetic Test Client &#183; reviewed: 2023-11-14 &#183; company_id 999 &#183; 31 layouts reviewed" in html
    assert "29% component completeness</strong> (17 of 58)." in html
    assert "3 components not evaluated (out of scope: PH13; prose judgment not supplied: C1, C2)." in html
    assert "40 findings (8 Critical, 32 High)" in html
    assert "23 deferred to ledger (18 Medium, 5 Low)" in html


# -----------------------------------------------------------------------------
# Acceptance criterion 2: Fixture finding set identical to Unit A
# -----------------------------------------------------------------------------
def test_unit_a_fixture_findings_identical(tmp_path):
    env, _ = _setup_env(tmp_path)

    cur_tuples = []
    for lid in SCOPE_ALL:
        cmd = [sys.executable, os.path.join(SCRIPTS_DIR, "evaluate.py"), "999", str(lid), "--json"]
        res = subprocess.run(cmd, env=env, capture_output=True, text=True, check=True)
        data = json.loads(res.stdout)
        for f in data.get("findings", []):
            cur_tuples.append((f["component"], f["asset_id"], f["severity"], f["detail"]))

    import importlib.util
    spec = importlib.util.spec_from_file_location("pristine_eval", "/workspace/tmp/hudu-doc-review/pristine/scripts/evaluate.py")
    pristine_eval = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pristine_eval)
    pristine_eval.STATE = str(tmp_path)

    prist_tuples = []
    for lid in SCOPE_ALL:
        assets = pristine_eval.load(999, lid)
        fs, _ = pristine_eval.evaluate(assets, f"layout {lid}", lid, company_id=999)
        for f in fs:
            prist_tuples.append((f["component"], f["asset_id"], f["severity"], f["detail"]))

    assert len(cur_tuples) == 63
    assert sorted(cur_tuples) == sorted(prist_tuples)


# -----------------------------------------------------------------------------
# Acceptance criterion 3: False pass with open High finding reports < 100%
# -----------------------------------------------------------------------------
def test_synthetic_false_pass_high_finding(tmp_path):
    db_file = tmp_path / "111.sqlite"
    con = sqlite3.connect(str(db_file))
    con.executescript("""
    create table assets(id integer primary key, name text, company_id int, layout_id int, layout_name text, hudu_url text, raw text, fetched_at int);
    create table fields(asset_id int, label text, value text, field_type text, position int);
    create table cards(asset_id int, integrator text, data text);
    create table fetch_log(company_id int, layout_id int, page int, n int, bytes int, ts int);
    """)
    # Insert 1 asset on Servers (layout 3) with missing OS (High finding)
    con.execute("insert into assets values(1, 'Server 1', 111, 3, 'Servers', 'http://example.com/1', '{}', 1700000000)")
    con.execute("insert into fields values(1, 'Manufacturer', 'Dell', 'text', 1)")
    con.execute("insert into fields values(1, 'Model', 'PowerEdge', 'text', 2)")
    con.execute("insert into fields values(1, 'Device Type', 'Server', 'text', 3)")
    con.execute("insert into fields values(1, 'Operating System', '', 'text', 4)")  # Gap!
    con.execute("insert into fetch_log values(111, 3, 1, 1, 100, 1700000000)")
    con.commit()
    con.close()

    env = os.environ.copy()
    env["HUDU_STATE_DIR"] = str(tmp_path)
    out_file = tmp_path / "111.html"
    res = subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "111", "--allow-partial", "--out", str(out_file)],
                         env=env, capture_output=True, text=True)
    assert res.returncode == 0
    html = out_file.read_text(encoding="utf-8")

    # High finding exists, completeness MUST NOT report 100%
    assert "100% component completeness" not in html
    assert "open gaps" not in html or "1 High" in html or "High" in html


# -----------------------------------------------------------------------------
# Acceptance criterion 4: scripts/ledger.py --all prints tally
# -----------------------------------------------------------------------------
def test_ledger_cli_all(tmp_path):
    env, _ = _setup_env(tmp_path)
    # Populate ledger
    subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "render.py"), "999", "--allow-partial"],
                   env=env, capture_output=True, text=True, check=True)
    res = subprocess.run([sys.executable, os.path.join(SCRIPTS_DIR, "ledger.py"), "--all"],
                         env=env, capture_output=True, text=True)
    assert res.returncode == 0
    assert "Company 999: Tier 1: 40, Tier 2: 18, Tier 3: 5 (Total: 63)" in res.stdout
    assert "Total: Tier 1: 40, Tier 2: 18, Tier 3: 5 (Total: 63)" in res.stdout
