#!/usr/bin/env python3
"""Publish a rendered review article to Hudu, bypassing model context entirely.

The model-mediated MCP tool path fails on large tool arguments (the same class
of failure that truncates large tool *results*). A 22KB HTML article passed as
a `content` argument through the model layer does not survive. Calling the MCP
server directly over HTTP avoids that: the payload goes from disk to Hudu with
no model in the loop.

Idempotent: looks up an existing article by exact title or normalized slug in
the company and edits it in place; creates it only when absent AND --allow-create
is passed.

Usage:
    python3 publish.py <company_id> <html_file> [options]

Options:
    --title TITLE       Default: "00 - Automated Documentation Review Findings"
    --publish           Explicitly write as live publish (default is draft)
    --draft             Explicitly write as draft (default behavior, no-op alias)
    --allow-create      Required to create a new article when no match exists
    --dry-run           Report what would happen without writing anything
    --verify-only       Fetch existing article and compare without writing
    --max-bytes N       Payload size limit in bytes (default: 30000)
    --force-size        Allow payloads exceeding --max-bytes
    --accept-unknowns   Allow payloads carrying unevaluated components

Prints the article id and hudu_url on success.
"""
import json, sqlite3, urllib.request, sys, os, time, re

HERE = os.path.dirname(os.path.abspath(__file__))

from hudu import get_token, rpc, call_tool

DEFAULT_TITLE = "00 - Automated Documentation Review Findings"
DEFAULT_MAX_BYTES = 30000


def normalize_slug(s):
    """Normalize a title or slug for comparison: lowercase, non-alphanumerics to hyphen."""
    if not s:
        return ""
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def check_payload(content, accept_unknowns=False):
    """Verify the payload contains no verdict placeholders or unevaluated components."""
    # 1.1 Refuse verdict placeholder:
    # Marker 1: VERDICT: inside an HTML comment
    comment_matches = re.findall(r"<!--[\s\S]*?-->", content)
    for c in comment_matches:
        if "VERDICT:" in c:
            raise RuntimeError(f"Refusing to publish: verdict placeholder found: {c.strip()!r}")

    # Marker 2: the phrase "model writes the systemic-issues paragraph"
    if "model writes the systemic-issues paragraph" in content:
        raise RuntimeError(
            "Refusing to publish: verdict placeholder found: "
            "'model writes the systemic-issues paragraph'"
        )

    # Unevaluated component marker emitted by renderer
    # Renderer emits: "N component(s) not evaluated (<cat>: <ids>; ...)."
    unknown_cids = []
    not_eval_match = re.search(r"(\d+)\s+components?\s+not\s+evaluated\s*\(([^)]+)\)", content)
    if not_eval_match:
        inner = not_eval_match.group(2)
        for part in inner.split(";"):
            part = part.strip()
            if ":" in part:
                ids_str = part.split(":", 1)[1]
            else:
                ids_str = part
            for token in ids_str.split(","):
                token = token.strip()
                if token:
                    unknown_cids.append(token)

    for m in re.finditer(r"(?:unevaluated|unknown)[-_ ]components?[:\s]+([^\n<->]+)", content, re.IGNORECASE):
        for token in m.group(1).split(","):
            token = token.strip()
            if token and token not in unknown_cids:
                unknown_cids.append(token)

    if unknown_cids and not accept_unknowns:
        cids_list = ", ".join(sorted(set(unknown_cids)))
        raise RuntimeError(
            f"Refusing to publish: payload carries unevaluated components ({cids_list}). "
            f"Pass --accept-unknowns to override."
        )


def check_size(content, max_bytes=DEFAULT_MAX_BYTES, force_size=False):
    """Pre-flight size check: print size, warn > 90%, refuse > max_bytes unless force_size."""
    payload_size = len(content.encode("utf-8"))
    print(f"payload size: {payload_size} bytes (max: {max_bytes})")
    if payload_size > max_bytes:
        if not force_size:
            raise RuntimeError(
                f"Payload size {payload_size} bytes exceeds limit of {max_bytes} bytes. "
                f"Pass --force-size to override."
            )
        print(f"warning: payload size {payload_size} bytes exceeds limit of {max_bytes} bytes; "
              f"continuing due to --force-size", file=sys.stderr)
    elif payload_size > int(max_bytes * 0.9):
        print(f"warning: payload size {payload_size} bytes is above 90% of limit ({max_bytes} bytes)",
              file=sys.stderr)
    return payload_size


def find_articles(token, company_id, title):
    """Return every article in the company whose name or slug matches `title`.

    Two passes, because the article index is not immediately consistent:
    pass 1 searches by title with `q`, pass 2 walks the company listing.
    Compares the requested title against both article name and normalized slug.

    Returns: (exact_matches, near_matches)
    """
    found = {}
    near = {}
    title_slug = normalize_slug(title)

    def collect(rows):
        for a in rows:
            aid = a.get("id")
            name = a.get("name") or ""
            slug = a.get("slug") or ""
            norm_name = normalize_slug(name)
            norm_s = normalize_slug(slug)
            if name == title or (norm_s and norm_s == title_slug):
                found[aid] = a
            elif norm_name == title_slug or (title_slug and (title_slug in norm_name or norm_name in title_slug)):
                near[aid] = a

    # pass 1 — targeted search
    try:
        res = call_tool(token, "article_index_tool",
                        {"company_id": company_id, "q": title, "per_page": 100})
        collect(res.get("data", res if isinstance(res, list) else []))
    except Exception:
        pass

    # pass 2 — walk the company listing
    page = 1
    while True:
        try:
            res = call_tool(token, "article_index_tool",
                            {"company_id": company_id, "per_page": 100,
                             "page": page})
        except Exception:
            break
        rows = res.get("data", [])
        collect(rows)
        pag = res.get("pagination", {})
        if not rows or page >= pag.get("total_pages", 1):
            break
        page += 1

    for aid in found:
        near.pop(aid, None)

    return list(found.values()), list(near.values())


def publish(token, company_id, title, content, draft=True, dry_run=False, allow_create=False):
    matches, near_matches = find_articles(token, company_id, title)

    if len(matches) > 1:
        lines = [
            f"{len(matches)} articles matching title {title!r} already exist in company {company_id}:"
        ]
        for m in matches:
            lines.append(f"  id={m.get('id')} name={m.get('name')!r} slug={m.get('slug')!r} url={m.get('hudu_url')}")
        lines.append("Refusing to guess which to edit.")
        lines.append("Surplus articles must be archived by hand before repeating this run. "
                     "There is no automated delete tool on the Hudu server.")
        raise RuntimeError("\n".join(lines))

    if matches:
        aid = matches[0]["id"]
        if dry_run:
            return aid, "would-edit"
        call_tool(token, "article_edit_tool",
                  {"id": aid, "name": title, "content": content, "draft": draft})
        return aid, "edited"

    if near_matches:
        for c in near_matches:
            print(f"Candidate near-match: id={c.get('id')} name={c.get('name')!r} "
                  f"slug={c.get('slug')!r} url={c.get('hudu_url')}")

    if not allow_create:
        raise RuntimeError(
            f"No existing article matching title {title!r} found in company {company_id}. "
            f"Refusing to create new article without --allow-create."
        )

    if dry_run:
        return None, "would-create"

    res = call_tool(token, "article_create_tool",
                    {"name": title, "content": content,
                     "company_id": company_id, "draft": draft})
    aid = res.get("id") if isinstance(res, dict) else None
    if aid is None:
        aid = (res.get("data") or {}).get("id") if isinstance(res, dict) else None
    return aid, "created"


def verify(token, aid):
    res = call_tool(token, "article_show_tool", {"id": aid})
    art = res.get("data", res) if isinstance(res, dict) else res
    if isinstance(art, list):
        art = art[0] if art else {}
    return art


def normalize(s):
    """Hudu decodes numeric character entities on save.

    Decode both decimal and hexadecimal numeric character references,
    strip whitespace between tags, collapse runs of whitespace in text
    nodes to a single space, and strip outer whitespace.
    """
    if not s:
        return ""

    def repl(m):
        code = m.group(1)
        if code.lower().startswith("x"):
            return chr(int(code[1:], 16))
        return chr(int(code, 10))

    s = re.sub(r"&#([xX][0-9a-fA-F]+|\d+);", repl, s)
    s = re.sub(r"\s+", " ", s)
    while True:
        new_s = re.sub(r">\s+<", "><", s)
        if new_s == s:
            break
        s = new_s
    return s.strip()


def diff_report(stored, local):
    """Compare stored vs local normalized text and report first divergence if differing."""
    norm_stored = normalize(stored)
    norm_local = normalize(local)
    if norm_stored == norm_local:
        return True, ""
    idx = 0
    min_len = min(len(norm_stored), len(norm_local))
    while idx < min_len and norm_stored[idx] == norm_local[idx]:
        idx += 1
    start = max(0, idx - 40)
    win_stored = norm_stored[start : start + 80]
    win_local = norm_local[start : start + 80]
    detail = (
        f"first divergence at offset {idx} "
        f"(stored length={len(stored)} [normalized={len(norm_stored)}], "
        f"local length={len(local)} [normalized={len(norm_local)}]):\n"
        f"  stored window: {win_stored!r}\n"
        f"  local window:  {win_local!r}"
    )
    return False, detail


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(2)
    company = int(sys.argv[1])
    path = sys.argv[2]
    title = DEFAULT_TITLE
    draft = True  # Default to draft
    dry_run = False
    allow_create = False
    verify_only = False
    accept_unknowns = False
    force_size = False
    max_bytes = DEFAULT_MAX_BYTES

    args = sys.argv[3:]
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--title" and i + 1 < len(args):
            title = args[i + 1]
            i += 1
        elif a == "--draft":
            draft = True  # no-op alias
        elif a == "--publish":
            draft = False  # explicit live publish
        elif a == "--allow-create":
            allow_create = True
        elif a == "--dry-run":
            dry_run = True
        elif a == "--verify-only":
            verify_only = True
        elif a == "--accept-unknowns":
            accept_unknowns = True
        elif a == "--force-size":
            force_size = True
        elif a == "--max-bytes" and i + 1 < len(args):
            max_bytes = int(args[i + 1])
            i += 1
        i += 1

    with open(path) as fh:
        content = fh.read()

    # Pre-flight checks:
    check_payload(content, accept_unknowns=accept_unknowns)
    check_size(content, max_bytes=max_bytes, force_size=force_size)

    tok = get_token()

    if verify_only:
        matches, _ = find_articles(tok, company, title)
        if not matches:
            raise RuntimeError(f"Cannot verify: no article matching {title!r} found in company {company}")
        if len(matches) > 1:
            lines = [f"{len(matches)} articles matching {title!r} exist in company {company}:"]
            for m in matches:
                lines.append(f"  id={m.get('id')} name={m.get('name')!r} slug={m.get('slug')!r} url={m.get('hudu_url')}")
            raise RuntimeError("\n".join(lines))
        aid = matches[0]["id"]
        art = verify(tok, aid)
        got = art.get("content", "") if isinstance(art, dict) else ""
        same, diff = diff_report(got, content)
        print(f"verify: stored {len(got)} bytes; match={'yes' if same else 'NO'} (entity-normalized)")
        if not same:
            print(diff)
        print(f"draft: {art.get('draft') if isinstance(art, dict) else '?'}")
        print(f"hudu_url: {art.get('hudu_url') if isinstance(art, dict) else '?'}")
        sys.exit(0)

    print(f"write mode: {'draft' if draft else 'live publish'}")
    aid, action = publish(tok, company, title, content, draft=draft, dry_run=dry_run, allow_create=allow_create)
    print(f"{action} article id={aid} title={title!r} draft={draft}")

    if dry_run:
        sys.exit(0)

    art = verify(tok, aid)
    got = art.get("content", "") if isinstance(art, dict) else ""
    same, diff = diff_report(got, content)
    print(f"verify: stored {len(got)} bytes; match={'yes' if same else 'NO'} (entity-normalized)")
    if not same:
        print(diff)
    print(f"draft: {art.get('draft') if isinstance(art, dict) else '?'}")
    print(f"hudu_url: {art.get('hudu_url') if isinstance(art, dict) else '?'}")