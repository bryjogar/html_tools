#!/usr/bin/env python3
"""Evaluate Hudu assets against the Enable documentation rubric.

Reads collected assets from local SQLite. Emits findings only.
No model in the loop. Every finding carries the asset's hudu_url so the
report can link straight to the record.

Counting: one finding per (asset, component, severity tier). Field-level
misses within a tier collapse into a single finding whose detail lists
every missing field.

C1 and C2 are prose judgments and are NOT decided here. The evaluator
surfaces their raw values so the model can read them without re-fetching.

Usage:
    python3 evaluate.py <company_id> <layout_id> [layout_name]
    python3 evaluate.py <company_id> <layout_id> --json
"""
import sqlite3, sys, json, os, re, time, hashlib

HERE = os.path.dirname(os.path.abspath(__file__))
STATE = os.environ.get("HUDU_STATE_DIR") or os.path.join(HERE, "..", "state")

from rubric import layout_group, REGISTRY, SCOPE_ALL, TIER

# Value semantics (see references/*.md)
#
# A blank is a BLIND SPOT, not a pass. If a field is not relevant, the author
# must say so with a deliberate marker. Silence is indistinguishable from an
# oversight, so it is always flagged.
ACCEPTABLE = {"n/a", "na", "none"}   # deliberate; author stated it does not apply
PLACEHOLDERS = {"tbd", "-", "?", "xxx", "unknown", "null", ""}  # blind spots

VIRTUAL_HINTS = ("vm", "virtual", "cloud", "colo")

SEV_ORDER = ["Critical", "High", "Medium", "Low"]

# Physical layouts that share the device field set (PH1-PH5)
DEVICE_CORE_LAYOUTS = {5, 6, 8, 9, 10, 11, 36}

# Network vendors whose devices require a license record. Cross-layout check:
# reads Network Devices (4) and Licensing (19) from the same company database.
# 'types' scopes the count to the device types that actually carry a license —
# a UniFi or Aruba switch needs no license, so counting it would be a false
# positive. See references/commercial.md, CM9/CM10.
LICENSE_VENDORS = {
    "Ruckus":    {"aliases": ["ruckus"],
                  "types": ["Wireless Access Point"]},
    "SonicWall": {"aliases": ["sonicwall", "sonic wall"],
                  "types": ["Firewall"]},
    "Meraki":    {"aliases": ["meraki"],
                  "types": ["Wireless Access Point"]},
    "Aruba":     {"aliases": ["aruba"],
                  "types": ["Wireless Access Point"]},
    "Ubiquiti":  {"aliases": ["ubiquiti", "unifi"],
                  "types": ["Wireless Access Point"]},
    "Sangoma":   {"aliases": ["sangoma", "switchvox"],
                  "types": ["PBX"]},
    "HostiFi":   {"aliases": ["hostifi"],
                  "types": ["Network Controller"]},
}

# Sites that are not real, dispatchable locations (S1)
NON_LOCATIONS = {"cloud", "other building", "remote", "n/a", "na", "various",
                 "none", "unknown", "tbd", "-", "?"}

# C4 checkbox sets
SERVICE_BOXES = ["Servers", "Network", "Workstations - Full Support",
                 "Workstations - Patching/AV Only", "Service Desk for End Users",
                 "Managed Backup Services", "Phone System"]
EXCLUSIVE_BOXES = ["Consulting/Ad Hoc Only", "Project Only", "Products Only"]
ALERT_BOXES = {
    "Workstation Alert Routing": "Workstation Alert Routing Destination",
    "Critical Network/Server Alert Notifications":
        "Critical Network/Server Alert Notification Destination",
}

# Prose fields the model must judge; surfaced, never decided here.
PROSE_FIELDS = {
    "client-identity": [
        ("C1", "Support Details & Exceptions"),
        ("C2", "Preferred Maintenance Window"),
    ],
}


def db_path(company_id):
    state_dir = os.environ.get("HUDU_STATE_DIR") or STATE
    return os.path.join(state_dir, f"{company_id}.sqlite")


def norm(v):
    return "" if v is None else str(v).strip()


def is_gap(v):
    """True when the value counts as a documentation gap."""
    s = norm(v).lower()
    if s in ACCEPTABLE:
        return False
    return s in PLACEHOLDERS


def is_empty_relation(v):
    """Relation fields (Site, Vendor, Contract, Router/Firewall) are JSON
    arrays of linked assets. An empty array is missing, same as a blank."""
    s = norm(v)
    if not s or s.lower() in ("none", "null"):
        return True
    try:
        d = json.loads(s)
    except Exception:
        return False  # free text; treat as populated
    return isinstance(d, list) and len(d) == 0


def is_virtual(dtype):
    return any(h in norm(dtype).lower() for h in VIRTUAL_HINTS)


def truthy(v):
    """Hudu checkboxes arrive as '1'/'0', sometimes 'None' for empty."""
    return norm(v).lower() in ("1", "true", "yes", "on")


def parse_contacts(v):
    """Contact fields are JSON arrays of {id,name,url}. Return the names."""
    s = norm(v)
    if not s or s.lower() in ("none", "null", "[]"):
        return []
    try:
        d = json.loads(s)
    except Exception:
        return []
    if isinstance(d, list):
        return [x.get("name") for x in d
                if isinstance(x, dict) and x.get("name")]
    return []


def site_address(a):
    """Sites carry no address field; it lives in the ConnectWise card."""
    for card in a.get("cards") or []:
        d = card.get("data") or {}
        line1, city = norm(d.get("addressLine1")), norm(d.get("city"))
        if line1 and city:
            return {"line1": line1, "city": city, "zip": norm(d.get("zip"))}
    return None


def load(company_id, layout_id):
    path = db_path(company_id)
    if not os.path.exists(path):
        raise SystemExit(f"no collected data at {path}; run collect.py first")
    c = sqlite3.connect(path)
    c.row_factory = sqlite3.Row
    assets = [dict(r) for r in c.execute(
        "select * from assets where company_id=? and layout_id=? order by id",
        (company_id, layout_id))]
    for a in assets:
        a["f"] = {}
        for r in c.execute("select label,value,field_type from fields where asset_id=? order by position", (a["id"],)):
            # Heading fields are section labels, not data. They carry an empty
            # value and must never be tested for presence.
            if (r["field_type"] or "").lower() == "heading":
                continue
            a["f"][r["label"]] = r["value"]
        a["cards"] = []
        try:
            for r in c.execute("select integrator,data from cards where asset_id=?",
                               (a["id"],)):
                a["cards"].append({"integrator_name": r["integrator"],
                                   "data": json.loads(r["data"]) if r["data"] else {}})
        except sqlite3.OperationalError:
            pass  # pre-cards database; re-run collect.py
    return assets


class FindingsList(list):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.ran_components = set()


class Findings:
    """Collects field-level misses, then collapses to (asset, component, severity)."""

    def __init__(self):
        self._raw = []
        self._ran = set()

    def ran(self, component):
        self._ran.add(component)

    def add(self, asset, component, severity, field, detail, **extra):
        item = {
            "asset_id": asset["id"], "asset": asset["name"],
            "hudu_url": asset.get("hudu_url"),
            "component": component, "severity": severity,
            "field": field, "detail": detail,
        }
        item.update(extra)
        self._raw.append(item)

    def collapsed(self):
        groups = {}
        for r in self._raw:
            key = (r["asset_id"], r["component"], r["severity"])
            g = groups.setdefault(key, {
                "asset_id": r["asset_id"], "asset": r["asset"],
                "hudu_url": r["hudu_url"], "component": r["component"],
                "severity": r["severity"], "fields": [], "details": [],
            })
            g["fields"].append(r["field"])
            g["details"].append(r["detail"])
            if "other_id" in r:
                g["other_id"] = r["other_id"]
            if "other_url" in r:
                g["other_url"] = r["other_url"]
        out = FindingsList(groups.values())
        out.ran_components = set(self._ran)
        for g in out:
            g["detail"] = "; ".join(g["details"])
            g["field"] = ", ".join(dict.fromkeys(g["fields"])) if g.get("fields") else ""
        out.sort(key=lambda x: (SEV_ORDER.index(x["severity"]), x["asset_id"] or 0))
        return out


# ---------------------------------------------------------------- infrastructure

def evaluate_infrastructure(assets, layout_name, layout_id):
    """Layouts 3, 4 (devices), 17, 18 (segments), 25, 29 (wireless), 27 (IPMI).
    See references/infrastructure.md."""
    if layout_id in (17, 18):
        return evaluate_network_segments(assets, layout_name, layout_id)
    if layout_id in (25, 29):
        return evaluate_wireless(assets, layout_name, layout_id)
    if layout_id == 27:
        return evaluate_ipmi(assets, layout_name, layout_id)
    return evaluate_devices(assets, layout_name, layout_id)


def evaluate_ipmi(assets, layout_name, layout_id):
    """Layout 27 — IPMI. See references/infrastructure.md, Part 4."""
    F = Findings()
    for a in assets:
        f = a["f"]
        # IP1 — Management Interface · High
        F.ran("IP1")
        if is_empty_relation(f.get("Server")):
            F.add(a, "IP1", "High", "Server", "Server missing")
        if is_gap(f.get("IP Address")):
            F.add(a, "IP1", "High", "IP Address", "IP Address missing")
    return F


def evaluate_devices(assets, layout_name, layout_id=None):
    F = Findings()

    for a in assets:
        f = a["f"]
        dtype = norm(f.get("Device Type"))
        virt = is_virtual(dtype)
        has_os = "Operating System" in f
        has_host = "Hosting Provider" in f

        # I1 — Device Identity · Critical
        F.ran("I1")
        for fld in ("Manufacturer", "Model", "Device Type"):
            if is_gap(f.get(fld)):
                F.add(a, "I1", "Critical", fld, f"{fld} missing ({norm(f.get(fld))!r})")

        # I2 — Location · High
        F.ran("I2")
        if is_gap(f.get("Site")):
            F.add(a, "I2", "High", "Site", "Site missing")
        if not virt and is_gap(f.get("Physical Location")):
            F.add(a, "I2", "High", "Physical Location",
                  "Physical Location missing")

        # I3 — Reachability · High
        # 'DHCP' is an acceptable entry: it states the device takes a leased
        # address, which is a deliberate answer, not a blind spot.
        F.ran("I3")
        if is_gap(f.get("IP Address")):
            F.add(a, "I3", "High", "IP Address", "IP Address missing")

        # I4 — Lifecycle (mixed severities)
        # Install Date is NOT checked — it is not worth flagging.
        F.ran("I4")
        if is_gap(f.get("Purchase Date")):
            F.add(a, "I4", "High", "Purchase Date", "Purchase Date missing")
        if not virt and is_gap(f.get("Warranty Expiration Date")):
            F.add(a, "I4", "Low", "Warranty Expiration Date",
                  "Warranty Expiration Date missing")

        # I5 — Hardware Identity · Medium (physical only)
        F.ran("I5")
        if not virt:
            if is_gap(f.get("Serial Number")):
                F.add(a, "I5", "Medium", "Serial Number",
                      "Serial Number missing")
            # MAC is only a gap when the IP is missing too. A device with a
            # recorded IP is reachable, so a missing MAC is not worth flagging.
            if is_gap(f.get("MAC Address")) and is_gap(f.get("IP Address")):
                F.add(a, "I5", "Medium", "MAC Address",
                      "MAC Address missing (IP also missing)")

        # I6 — Platform · Medium · Servers only (skip when fields absent)
        if layout_id == 3 or (layout_id is None and "server" in layout_name.lower()):
            F.ran("I6")
            if has_os and is_gap(f.get("Operating System")):
                F.add(a, "I6", "Medium", "Operating System", "Operating System missing")
            if has_host and is_gap(f.get("Hosting Provider")):
                F.add(a, "I6", "Medium", "Hosting Provider", "Hosting Provider missing")

        # I7 — Layout Correctness · Medium
        if layout_id == 4 or (layout_id is None and "network" in layout_name.lower()):
            F.ran("I7")
            if norm(dtype).lower() in ("ups", "ups battery"):
                F.add(a, "I7", "Medium", "Device Type",
                      f"Device Type {dtype!r} belongs in Power Management")

    return F


# --------------------------------------------------------------- client identity

def check_c4(f):
    """C4 — Service Scope Consistency. Returns a list of problem strings."""
    out = []
    services = [b for b in SERVICE_BOXES if truthy(f.get(b))]
    exclusives = [b for b in EXCLUSIVE_BOXES if truthy(f.get(b))]

    if not services and not exclusives:
        out.append("no supported-services checkbox is true")
    if len(exclusives) > 1:
        out.append("multiple engagement types set: " + ", ".join(exclusives))
    if truthy(f.get("Workstations - Full Support")) and \
       truthy(f.get("Workstations - Patching/AV Only")):
        out.append("Workstations Full Support and Patching/AV Only both set")
    if truthy(f.get("Products Only")) and services:
        out.append("Products Only set but service checkboxes also true: "
                   + ", ".join(services))
    for flag, dest in ALERT_BOXES.items():
        if truthy(f.get(flag)) and not norm(f.get(dest)):
            out.append(f"{flag} true but destination empty")
        if truthy(f.get("Products Only")) and truthy(f.get(flag)):
            out.append(f"alert routing {flag} set on a Products Only client")
    return out


def evaluate_network_segments(assets, layout_name, layout_id):
    """Layouts 17 (WAN) and 18 (LAN). See references/infrastructure.md, Part 2."""
    F = Findings()

    for a in assets:
        f = a["f"]

        if layout_id == 18:  # LAN — a VLAN / segment record
            # L1 — Segment Identity · Critical
            F.ran("L1")
            for fld in ("Subnet", "VLAN ID"):
                if is_gap(f.get(fld)):
                    F.add(a, "L1", "Critical", fld,
                          f"{fld} missing ({norm(f.get(fld))!r})")

            # L2 — Site · High
            F.ran("L2")
            if is_empty_relation(f.get("Site")):
                F.add(a, "L2", "High", "Site", "Site missing")

            # L3 — Gateway & DNS · tiered
            F.ran("L3")
            if is_gap(f.get("Gateway")):
                F.add(a, "L3", "Medium", "Gateway", "Gateway missing")
            if is_gap(f.get("DNS Server(s)")):
                F.add(a, "L3", "High", "DNS Server(s)", "DNS Server(s) missing")

            # L4 — DHCP · Medium. Enable runs DHCP on every network, so a blank
            # DHCP pair is a blind spot, not a static-only VLAN. The only way to
            # pass without values is a deliberate marker (N/A / NA / None).
            F.ran("L4")
            srv, scope = f.get("DHCP Server"), f.get("DHCP Scope")
            srv_gap, scope_gap = is_gap(srv), is_gap(scope)
            if srv_gap and scope_gap:
                F.add(a, "L4", "Medium", "DHCP",
                      "DHCP Server and DHCP Scope both missing "
                      "(Enable runs DHCP on every network)")
            elif srv_gap:
                F.add(a, "L4", "Medium", "DHCP Server", "DHCP Server missing")
            elif scope_gap:
                F.add(a, "L4", "Medium", "DHCP Scope", "DHCP Scope missing")

        elif layout_id == 17:  # WAN — a carrier circuit
            # W1 — Circuit Identity · Critical
            F.ran("W1")
            for fld in ("Circuit ID", "Account Number"):
                if is_gap(f.get(fld)):
                    F.add(a, "W1", "Critical", fld,
                          f"{fld} missing ({norm(f.get(fld))!r})")
            for fld in ("Vendor", "Contract"):
                if is_empty_relation(f.get(fld)):
                    F.add(a, "W1", "Critical", fld, f"{fld} missing")

            # W2 — Site · High
            F.ran("W2")
            if is_empty_relation(f.get("Site")):
                F.add(a, "W2", "High", "Site", "Site missing")

            # W3 — Transport · High
            F.ran("W3")
            for fld in ("Media Type", "Transport", "Upload Speed (Mbps)",
                        "Download Speed (Mbps)"):
                if is_gap(f.get(fld)):
                    F.add(a, "W3", "High", fld, f"{fld} missing")

            # W4 — Termination · Medium
            F.ran("W4")
            if is_empty_relation(f.get("Router/Firewall")):
                F.add(a, "W4", "Medium", "Router/Firewall",
                      "Router/Firewall missing")
            if is_gap(f.get("IP Address(es)")):
                F.add(a, "W4", "Medium", "IP Address(es)",
                      "IP Address(es) missing")

            # W5 — Redundancy · Medium
            F.ran("W5")
            if is_gap(f.get("Redundancy Configuration")):
                F.add(a, "W5", "Medium", "Redundancy Configuration",
                      "Redundancy Configuration missing")

    return F


def evaluate_wireless(assets, layout_name, layout_id):
    """Layouts 25 (Wi-Fi) and 29 (SSIDs). See references/infrastructure.md, Part 3."""
    F = Findings()

    for a in assets:
        f = a["f"]

        if layout_id == 25:  # Wi-Fi — a wireless system record
            # WF1 — Site · High
            F.ran("WF1")
            if is_empty_relation(f.get("Site")):
                F.add(a, "WF1", "High", "Site", "Site missing")

            # WF2 — Controller · High
            F.ran("WF2")
            if is_empty_relation(f.get("Wireless Controller(s)")):
                F.add(a, "WF2", "High", "Wireless Controller(s)",
                      "Wireless Controller(s) missing")

            # WF3 — Access Points · High
            F.ran("WF3")
            if is_empty_relation(f.get("Wireless Access Point(s)")):
                F.add(a, "WF3", "High", "Wireless Access Point(s)",
                      "Wireless Access Point(s) missing")

            # WF4 — SSIDs · Medium
            F.ran("WF4")
            if is_empty_relation(f.get("SSID(s)")):
                F.add(a, "WF4", "Medium", "SSID(s)", "SSID(s) missing")

            # WF5 — Management · Medium
            F.ran("WF5")
            if is_gap(f.get("Management Address")):
                F.add(a, "WF5", "Medium", "Management Address",
                      "Management Address missing")

        elif layout_id == 29:  # SSIDs — one broadcast network
            ntype = norm(f.get("Network Type"))
            proto = norm(f.get("Security Protocol"))
            is_open = ntype.lower() == "open"
            is_psk = "psk" in ntype.lower() or "pre-shared" in ntype.lower()

            # SS1 — Security Configuration · Critical
            F.ran("SS1")
            for fld, val in (("Network Type", ntype), ("Security Protocol", proto)):
                if is_gap(val):
                    F.add(a, "SS1", "Critical", fld,
                          f"{fld} missing ({val!r})")
            if not is_gap(ntype) and not is_gap(proto):
                if is_open and proto.lower() != "none":
                    F.add(a, "SS1", "Critical", "Security Protocol",
                          f"Network Type is Open but Security Protocol is {proto!r}")
                if is_psk and proto.lower() == "none":
                    F.add(a, "SS1", "Critical", "Security Protocol",
                          "PSK network with Security Protocol None")

            # SS2 — Passphrase · Critical (conditional on Network Type)
            F.ran("SS2")
            passphrase = f.get("Passphrase")
            if is_psk and is_gap(passphrase):
                F.add(a, "SS2", "Critical", "Passphrase",
                      "PSK network with no passphrase")
            if is_open and not is_gap(passphrase):
                F.add(a, "SS2", "Critical", "Passphrase",
                      "Open network carrying a passphrase")

            # SS3 — LAN · High
            F.ran("SS3")
            if is_empty_relation(f.get("LAN")):
                F.add(a, "SS3", "High", "LAN", "LAN missing")

            # SS4 — Client Isolation · Medium (0/1 are deliberate; absent is a gap)
            F.ran("SS4")
            if "Client Isolation" not in f or is_gap(f.get("Client Isolation")):
                F.add(a, "SS4", "Medium", "Client Isolation",
                      "Client Isolation missing")

    return F


def evaluate_services(assets, layout_name, layout_id):
    """Layouts 12, 13, 14, 15, 16, 21, 23. See references/services.md."""
    F = Findings()

    for a in assets:
        f = a["f"]

        if layout_id == 13:  # Applications & Services
            # SV1 — Application Identity & Hosting · Critical
            F.ran("SV1")
            for fld in ("Category", "Importance", "Application Location"):
                if is_gap(f.get(fld)):
                    F.add(a, "SV1", "Critical", fld,
                          f"{fld} missing ({norm(f.get(fld))!r})")
            loc = norm(f.get("Application Location")).lower()
            if "on premise" in loc or "on-premise" in loc or "datacenter" in loc:
                if is_empty_relation(f.get("Application Server(s)")) and \
                   is_gap(f.get("On-Prem System URL")):
                    F.add(a, "SV1", "Critical", "hosting",
                          "On-premise application with no server and no on-prem URL")
            elif "hosted" in loc or "saas" in loc:
                if is_gap(f.get("Hosted System URL")):
                    F.add(a, "SV1", "Critical", "Hosted System URL",
                          "Hosted/SaaS application with no Hosted System URL")

            # SV2 — Application Ownership · Medium
            F.ran("SV2")
            if is_empty_relation(f.get("Application Champion")):
                F.add(a, "SV2", "Medium", "Application Champion",
                       "Application Champion missing")
            if is_empty_relation(f.get("Vendor")):
                F.add(a, "SV2", "Medium", "Vendor", "Vendor missing")

        elif layout_id == 14:  # Backups
            # SV3 — Backup Coverage · Critical
            F.ran("SV3")
            if is_gap(f.get("Backup Type")):
                F.add(a, "SV3", "Critical", "Backup Type", "Backup Type missing")
            if is_empty_relation(f.get("Protected Systems")):
                F.add(a, "SV3", "Critical", "Protected Systems",
                      "Protected Systems missing")
            if is_gap(f.get("Offsite Storage Provider")):
                F.add(a, "SV3", "Critical", "Offsite Storage Provider",
                      "Offsite Storage Provider missing")

            # SV4 — Backup Retention · Medium
            F.ran("SV4")
            if not is_empty_relation(f.get("Local Backup Server(s)")):
                for fld in ("Local Backup Storage Location", "Local Backup Retention"):
                    if is_gap(f.get(fld)):
                        F.add(a, "SV4", "Medium", fld, f"{fld} missing")

        elif layout_id == 15:  # Email
            # SV5 — Email Platform · High
            F.ran("SV5")
            for fld in ("Type", "Inbound SMTP Gateway", "Webmail URL"):
                if is_gap(f.get(fld)):
                    F.add(a, "SV5", "High", fld, f"{fld} missing")

        elif layout_id == 16:  # File Sharing
            # SV6 — File Share Access · High
            # NOTE: 'On-Premises File Share' and 'Cloud Hosted File Share' are
            # Heading fields (section labels), not flags. The real data is
            # Share Name / Folder Path (on-prem) and Hosted System URL (cloud).
            F.ran("SV6")
            onprem = not is_gap(f.get("Share Name")) or not is_gap(f.get("Folder Path"))
            cloud = not is_gap(f.get("Hosted System URL"))
            if onprem:
                for fld in ("Share Name", "Folder Path"):
                    if is_gap(f.get(fld)):
                        F.add(a, "SV6", "High", fld, f"{fld} missing")
            if not onprem and not cloud:
                F.add(a, "SV6", "High", "share",
                      "no share details: Share Name, Folder Path, and "
                      "Hosted System URL are all blank")

        elif layout_id == 12:  # Identity Providers
            # SV7 — Directory Identity · Critical
            F.ran("SV7")
            dtype = norm(f.get("Directory Type"))
            if is_gap(dtype):
                F.add(a, "SV7", "Critical", "Directory Type",
                      f"Directory Type missing ({dtype!r})")
            if "active directory" in dtype.lower():
                if is_gap(f.get("AD Full Name (FQDN)")):
                    F.add(a, "SV7", "Critical", "AD Full Name (FQDN)",
                          "Active Directory with no FQDN")
                if is_empty_relation(f.get("AD Server(s)")):
                    F.add(a, "SV7", "Critical", "AD Server(s)",
                          "Active Directory with no AD Server(s)")

            # SV8 — Directory Sync · Medium
            F.ran("SV8")
            sync = norm(f.get("Directory Sync"))
            if sync and sync.lower() != "none" and \
               is_empty_relation(f.get("Directory Sync Server(s)")):
                F.add(a, "SV8", "Medium", "Directory Sync Server(s)",
                      f"Directory Sync is {sync!r} but no sync server linked")

        elif layout_id == 21:  # Remote Access
            # SV9 — Remote Access Method · High
            # NOTE: 'VPN' and 'Remote Desktop' are Heading fields, not flags.
            # Presence is read from the real fields under each heading.
            # ScreenConnect access is itself a valid remote access method — a
            # client with it does not need a VPN or Remote Desktop entry.
            F.ran("SV9")
            vpn = any(not is_gap(f.get(x)) for x in
                      ("VPN Endpoint", "VPN Protocol", "VPN Authentication")) \
                or not is_empty_relation(f.get("VPN Host"))
            rdp = not is_gap(f.get("Remote Desktop Endpoint")) \
                or not is_empty_relation(f.get("Remote Desktop Server(s)"))
            sc = truthy(f.get("Client Access to Enable ScreenConnect")) \
                or not is_empty_relation(
                    f.get("Client Users with Enable ScreenConnect Access")) \
                or not is_empty_relation(
                    f.get("Co-Managed Client IT Users with Enable ScreenConnect Access"))
            if vpn:
                for fld in ("VPN Endpoint", "VPN Protocol", "VPN Authentication"):
                    if is_gap(f.get(fld)):
                        F.add(a, "SV9", "High", fld, f"{fld} missing")
            if rdp and is_gap(f.get("Remote Desktop Endpoint")):
                F.add(a, "SV9", "High", "Remote Desktop Endpoint",
                      "Remote Desktop with no endpoint")
            if not vpn and not rdp and not sc:
                F.add(a, "SV9", "High", "method",
                      "no remote access method documented (no VPN, no Remote "
                      "Desktop, and no ScreenConnect access)")

        elif layout_id == 23:  # Virtualization
            # SV10 — Virtualization Platform · High
            F.ran("SV10")
            tech = norm(f.get("Virtualization Technology")).lower()
            is_cloud = "cloud" in tech
            if is_gap(f.get("Virtualization Technology")):
                F.add(a, "SV10", "High", "Virtualization Technology",
                      "Virtualization Technology missing")
            # A public-cloud platform has no on-prem host; the provider is the
            # host. Requiring Virtualization Host(s) there is a false positive.
            if not is_cloud and is_empty_relation(f.get("Virtualization Host(s)")):
                F.add(a, "SV10", "High", "Virtualization Host(s)",
                      "Virtualization Host(s) missing")
            if is_empty_relation(f.get("Virtual Machine(s)")):
                F.add(a, "SV10", "High", "Virtual Machine(s)",
                      "Virtual Machine(s) missing")
            if is_cloud and is_empty_relation(f.get("Hosting Provider")):
                F.add(a, "SV10", "High", "Hosting Provider",
                      "public-cloud virtualization with no Hosting Provider")

    return F


# Cloud-managed controller platforms. A Network Controller record that is
# cloud-hosted belongs in Applications & Services (13), not Network Devices (4).
# See references/infrastructure.md, I8.
CLOUD_CONTROLLER_HINTS = ("cloud", "meraki", "hostifi", "instanton")


def is_cloud_controller(f):
    """True when a Network Controller record is a cloud platform.

    Positive evidence only — a controller that is merely under-documented is
    not flagged. A local controller (e.g. a Unifi controller on a site box)
    has no cloud signal and correctly stays in Network Devices.
    """
    if norm(f.get("Device Type")) != "Network Controller":
        return False
    model = norm(f.get("Model")).lower()
    mfr = norm(f.get("Manufacturer")).lower()
    ip = norm(f.get("IP Address")).lower()
    loc = norm(f.get("Physical Location")).lower()
    if ip.startswith("http"):      # a URL, not an IP — no on-prem presence
        return True
    if loc == "cloud":
        return True
    return any(h in model or h in mfr for h in CLOUD_CONTROLLER_HINTS)


def evaluate_controller_placement(company_id, F):
    """I8 — Controller Placement · Medium.

    Cross-layout: Network Devices (4) vs Applications & Services (13). A
    cloud-managed controller is an application, not a network device.
    """
    F.ran("I8")
    try:
        devices = load(company_id, 4)
        apps = load(company_id, 13)
    except SystemExit:
        return
    app_names = {norm(a["name"]).lower() for a in apps}
    for d in devices:
        if not is_cloud_controller(d["f"]):
            continue
        detail = (f"cloud controller {d['name']!r} belongs in Applications & "
                  f"Services, not Network Devices")
        if norm(d["name"]).lower() in app_names:
            detail += (" — a matching Applications record already exists, so "
                       "the move was left half-done")
        F.add(d, "I8", "Medium", "Device Type", detail)


def _pair_key(name):
    """Normalize a name for UPS/battery pairing.

    Separators and case are noise: 'MPC-MDF-UPS01' and 'MPC-MDF-UPS-01' are
    the same device, and a hyphen must not decide whether a battery exists.
    Strip everything but letters and digits, then lowercase.
    """
    return "".join(ch for ch in norm(name).lower() if ch.isalnum())


# Trailing words a battery record carries after the UPS name.
BATTERY_SUFFIX = ("internalbattery", "externalbattery", "battery", "bat")


def evaluate_ups_battery_pairing(company_id, F):
    """PH14 — UPS Battery Pairing · High.

    Every UPS entry must have a corresponding UPS Battery entry. A UPS without
    its battery documented is an incomplete record: the battery is the part
    that actually fails and gets replaced.

    Pairing is by name, normalized: separators and case are stripped, and the
    battery's trailing word (' - Battery', ' - Internal battery') is removed
    before comparing. Without normalization a hyphen splits a real pair and
    reports a battery that exists as missing.
    """
    F.ran("PH14")
    try:
        assets = load(company_id, 36)
    except SystemExit:
        return

    ups = [a for a in assets if norm(a["f"].get("Device Type")).lower() == "ups"]
    bat = [a for a in assets
           if norm(a["f"].get("Device Type")).lower() == "ups battery"]
    if not ups:
        return

    def battery_base(b):
        """Battery name with its trailing battery word removed."""
        k = _pair_key(b["name"])
        for suf in BATTERY_SUFFIX:
            if k.endswith(suf) and len(k) > len(suf):
                return k[:-len(suf)]
        return k

    bat_keys = [(battery_base(b), _pair_key(b["name"])) for b in bat]

    def has_battery(u):
        uk = _pair_key(u["name"])
        if not uk:
            return True  # unnamed record; X3 covers it, do not double-report
        for base, full in bat_keys:
            # the battery name carries the UPS name, or the UPS name carries
            # the battery's base once the trailing battery word is stripped
            if full.startswith(uk) or uk.startswith(base):
                return True
        return False

    for u in ups:
        if not has_battery(u):
            F.add(u, "PH14", "High", "Device Type",
                  f"UPS {u['name']!r} has no corresponding UPS Battery entry")


def evaluate_license_coverage(company_id, F):
    """CM9/CM10 — network device license coverage.

    Cross-layout: Network Devices (4) vs Licensing (19). A network vendor's
    devices must have a license record, and the recorded seat count must cover
    the device count. See references/commercial.md.
    """
    F.ran("CM9")
    F.ran("CM10")
    try:
        devices = load(company_id, 4)
        licenses = load(company_id, 19)
    except SystemExit:
        return

    for vendor, spec in LICENSE_VENDORS.items():
        # Devices of this vendor that actually carry a license.
        devs = [d for d in devices
                if any(al in norm(d["f"].get("Manufacturer")).lower()
                       for al in spec["aliases"])
                and norm(d["f"].get("Device Type")) in spec["types"]]
        if not devs:
            continue

        # License records for this vendor.
        lic = [l for l in licenses
               if any(al in norm(l["name"]).lower() for al in spec["aliases"])]

        # CM9 — Network License Coverage · High
        if not lic:
            F.add({"id": None, "name": "(licensing)", "hudu_url": None},
                  "CM9", "High", vendor,
                  f"{len(devs)} {vendor} {spec['types'][0]}(s) documented but no "
                  f"{vendor} license record exists")
            continue

        # CM10 — Network License Count · Medium
        seats = 0
        for l in lic:
            try:
                seats += int(float(norm(l["f"].get("Seats")) or 0))
            except ValueError:
                pass
        if seats < len(devs):
            F.add({"id": None, "name": "(licensing)", "hudu_url": None},
                  "CM10", "Medium", vendor,
                  f"{vendor}: {len(devs)} licensed device(s) but only {seats} "
                  f"seat(s) recorded across {len(lic)} license record(s)")


def evaluate_commercial(assets, layout_name, layout_id):
    """Layouts 19, 22, 32. See references/commercial.md."""
    F = Findings()

    for a in assets:
        f = a["f"]

        if layout_id == 19:  # Licensing
            # CM1 — License Identity · Critical
            # NOTE: License Key(s) is deliberately NOT required. Subscription
            # licenses (M365, Google Workspace, Mosyle, HostiFi) have no key by
            # nature, and no field distinguishes subscription from perpetual.
            # Requiring it false-positives on every SaaS license. Flagged for
            # review — see references/commercial.md.
            F.ran("CM1")
            for fld in ("Version", "Seats"):
                if is_gap(f.get(fld)):
                    F.add(a, "CM1", "Critical", fld,
                          f"{fld} missing ({norm(f.get(fld))!r})")
            # CM2 — License Lifecycle · High
            # Purchase and renewal dates are what the strategy consultants need
            # most; they stay High.
            F.ran("CM2")
            for fld in ("Purchase Date", "Renewal Date"):
                if is_gap(f.get(fld)):
                    F.add(a, "CM2", "High", fld, f"{fld} missing")
            # CM2a — Renewal Price · Low
            # Real gap, but a procurement detail rather than a support-critical
            # one. Demoted from High.
            F.ran("CM2a")
            if is_gap(f.get("Renewal Price")):
                F.add(a, "CM2a", "Low", "Renewal Price", "Renewal Price missing")
            # CM3 (Reseller) — DROPPED. Procurement detail, not triage-relevant.
            # It generated 38 findings on PCPC alone.

        elif layout_id == 32:  # Contracts
            # CM4 — Contract Identity · Critical
            F.ran("CM4")
            if is_gap(f.get("Account Number")):
                F.add(a, "CM4", "Critical", "Account Number",
                      "Account Number missing")
            if is_empty_relation(f.get("Vendor")):
                F.add(a, "CM4", "Critical", "Vendor", "Vendor missing")
            if is_gap(f.get("Term")):
                F.add(a, "CM4", "Critical", "Term", "Term missing")
            # CM5 — Contract Lifecycle · High
            F.ran("CM5")
            for fld in ("Date Signed", "Expiration Date", "Expiration Action Date"):
                if is_gap(f.get(fld)):
                    F.add(a, "CM5", "High", fld, f"{fld} missing")
            # CM6 — Contract Price · Medium
            F.ran("CM6")
            for fld in ("Price", "Price Frequency"):
                if is_gap(f.get(fld)):
                    F.add(a, "CM6", "Medium", fld, f"{fld} missing")

        elif layout_id == 22:  # Vendors
            # CM7 — Vendor Contact · High
            # At least one support channel must exist. Requiring all three
            # false-positives on vendors reachable by website or rep email only.
            F.ran("CM7")
            channels = ["Support Phone Number", "Support Email Address",
                        "Support Website"]
            if all(is_gap(f.get(c)) for c in channels):
                F.add(a, "CM7", "High", "support contact",
                      "no support contact channel: phone, email, and website "
                      "are all blank")
            # CM8 (Vendor Account) — DROPPED. Account rep name/email is a named
            # human contact at a vendor, the same category as the PE/SE/CRM
            # names already ruled out of scope. It generated 63 findings on PCPC.

    return F


def evaluate_physical(assets, layout_name, layout_id):
    """Layouts 5, 6, 8, 9, 10, 11, 20, 24, 30, 34, 35, 36.
    See references/physical.md."""
    F = Findings()

    for a in assets:
        f = a["f"]

        # ---- shared device core (PH1-PH5) ----
        if layout_id in DEVICE_CORE_LAYOUTS:
            # PH1 — Device Identity · Critical
            F.ran("PH1")
            for fld in ("Manufacturer", "Model", "Device Type"):
                if is_gap(f.get(fld)):
                    F.add(a, "PH1", "Critical", fld,
                          f"{fld} missing ({norm(f.get(fld))!r})")
            # PH2 — Device Location · High
            F.ran("PH2")
            if is_empty_relation(f.get("Site")):
                F.add(a, "PH2", "High", "Site", "Site missing")
            if is_gap(f.get("Physical Location")):
                F.add(a, "PH2", "High", "Physical Location",
                      "Physical Location missing")
            # PH3 — Device Reachability · High
            # A UPS Battery is a sub-component of a UPS, not a networked device:
            # it has no IP and no MAC. Same class as a VM having no rack position.
            # 'DHCP' is an acceptable entry — a leased address is a deliberate
            # answer, not a blind spot.
            F.ran("PH3")
            is_battery = norm(f.get("Device Type")).lower() == "ups battery"
            if not is_battery and is_gap(f.get("IP Address")):
                F.add(a, "PH3", "High", "IP Address", "IP Address missing")
            # PH4 — Device Hardware Identity · Medium
            # MAC is only a gap when the IP is missing too — a device with a
            # recorded IP is reachable, so a missing MAC is not worth flagging.
            F.ran("PH4")
            if is_gap(f.get("Serial Number")):
                F.add(a, "PH4", "Medium", "Serial Number", "Serial Number missing")
            if not is_battery and is_gap(f.get("MAC Address")) \
               and is_gap(f.get("IP Address")):
                F.add(a, "PH4", "Medium", "MAC Address",
                      "MAC Address missing (IP also missing)")
            # PH5 — Device Lifecycle · High (flattened)
            # Purchase Date only. Warranty Expiration is low priority and is
            # excluded from triage — the value is still collected in SQLite for
            # future runs, it is simply not reported. Install Date is not checked.
            F.ran("PH5")
            if is_gap(f.get("Purchase Date")):
                F.add(a, "PH5", "High", "Purchase Date", "Purchase Date missing")

        # ---- layout-specific ----
        if layout_id == 5:  # Printers & Scanners
            # PH6 — Printer Driver Config · Medium
            F.ran("PH6")
            for fld in ("Windows Driver Name", "macOS Driver Name"):
                if is_gap(f.get(fld)):
                    F.add(a, "PH6", "Medium", fld, f"{fld} missing")

        elif layout_id == 20:  # Printing
            # PH7 — Printing Deployment · High
            # Print Servers is required ONLY when the deployment method needs a
            # server (Group Policy or Print Management). A direct-to-IP script
            # or a manual install has no print server by design.
            F.ran("PH7")
            if is_empty_relation(f.get("Printers")):
                F.add(a, "PH7", "High", "Printers", "Printers missing")
            if is_gap(f.get("Deployment")):
                F.add(a, "PH7", "High", "Deployment", "Deployment missing")
            dep = norm(f.get("Deployment")).lower()
            needs_server = "group policy" in dep or "print management" in dep
            if needs_server and is_empty_relation(f.get("Print Servers")):
                F.add(a, "PH7", "High", "Print Servers",
                      f"Print Servers missing for {norm(f.get('Deployment'))!r} "
                      f"deployment")

        elif layout_id == 24:  # Phone Systems
            # PH8 — Phone System Identity · Critical
            F.ran("PH8")
            if is_gap(f.get("Type")):
                F.add(a, "PH8", "Critical", "Type", "Type missing")
            if is_gap(f.get("Management Address")):
                F.add(a, "PH8", "Critical", "Management Address",
                      "Management Address missing")
            if is_empty_relation(f.get("PSTN Provider")):
                F.add(a, "PH8", "Critical", "PSTN Provider",
                      "PSTN Provider missing")

        elif layout_id == 30:  # Analog Lines
            # PH9 — Analog Line Identity · High
            F.ran("PH9")
            if is_gap(f.get("Phone Number")):
                F.add(a, "PH9", "High", "Phone Number", "Phone Number missing")
            if is_empty_relation(f.get("Carrier")):
                F.add(a, "PH9", "High", "Carrier", "Carrier missing")
            if is_empty_relation(f.get("Site")):
                F.add(a, "PH9", "High", "Site", "Site missing")

        elif layout_id == 36:  # Power Management
            # PH10 — Power Device Identity · Critical
            # Manufacturer/Model are covered by PH1 (36 is in the device core);
            # this component's unique job is the Device Type validation.
            F.ran("PH10")
            dtype = norm(f.get("Device Type")).lower()
            if dtype not in ("ups", "ups battery"):
                F.add(a, "PH10", "Critical", "Device Type",
                      f"Device Type {norm(f.get('Device Type'))!r} is not a UPS type")

        elif layout_id == 35:  # SSL Certificates
            # PH11 — Certificate Identity · Critical
            F.ran("PH11")
            for fld in ("Common Name", "Issuer", "Cert Expires"):
                if is_gap(f.get(fld)):
                    F.add(a, "PH11", "Critical", fld, f"{fld} missing")
            # PH12 — Certificate Validity: OUT OF SCOPE (monitoring concern)

        elif layout_id == 34:  # Security & Compliance
            # PH13 — Security Posture: OUT OF SCOPE (user decision).
            pass

    return F


def evaluate_client_identity(assets, layout_name, layout_id):
    F = Findings()

    if layout_id == 33:  # Client Overview
        for a in assets:
            f = a["f"]

            # C3 — Contact & Authorization Chain · Critical
            F.ran("C3")
            pocs = parse_contacts(f.get("Primary POC"))
            auths = parse_contacts(f.get("Access Authorizers"))
            emer = parse_contacts(f.get("Emergency Contacts"))
            missing = []
            if not pocs:
                missing.append("Primary POC")
            if not auths:
                missing.append("Access Authorizers")
            if not emer:
                missing.append("Emergency Contacts")
            if missing:
                F.add(a, "C3", "Critical", "contacts",
                      "empty: " + ", ".join(missing))

            # C3a — Single point of contact · Low (advisory)
            F.ran("C3a")
            if pocs and auths and emer and \
               len(pocs) == 1 and len(auths) == 1 and len(emer) == 1 and \
               pocs[0] == auths[0] == emer[0]:
                F.add(a, "C3a", "Low", "contacts",
                      f"single point of contact: {pocs[0]}")

            # C4 — Service Scope Consistency · Critical
            F.ran("C4")
            for msg in check_c4(f):
                F.add(a, "C4", "Critical", "services", msg)

    elif layout_id == 2:  # Sites
        # Address readability depends on the ConnectWise integration. If the
        # client has no cards at all, addresses are unreadable for every site —
        # that is a missing integration, not a per-site documentation gap.
        # Report it once as unknown rather than failing every site.
        any_cards = any(a.get("cards") for a in assets)
        for a in assets:
            F.ran("S1")
            name = norm(a["name"])
            if name.lower() in NON_LOCATIONS:
                F.add(a, "S1", "Medium", "name",
                      f"Site {name!r} is not a real location")
            if any_cards and not site_address(a):
                F.add(a, "S1", "Medium", "address", "no address on record")

    return F


def site_address_unknown(assets, layout_id):
    """True when Sites addresses cannot be read at all (no integration)."""
    if layout_id != 2 or not assets:
        return False
    return not any(a.get("cards") for a in assets)


# ------------------------------------------------------------------ cross-cutting

def _norm_mac(v):
    return "".join(ch for ch in norm(v).lower() if ch.isalnum())


# Names an integration generates when it creates a record it cannot identify.
# 'Device@10.16.1.192' is Auvik's fallback: the device was discovered, a record
# was made, and nobody ever gave it a real identity. The record looks populated
# in a list view and is useless in practice — you cannot tell what the device is
# or where it lives without opening the integration card.
PLACEHOLDER_NAME = re.compile(
    r"^(device@|asset@|host@|node@|unknown\b|new asset\b|unnamed\b|no name\b)",
    re.IGNORECASE)


def placeholder_names(assets, F):
    """X3 — record name is an integration placeholder. Adds to F.

    High, not Medium: the name is the one field every other record is matched
    against, and a placeholder means the asset cannot be identified from the
    documentation at all. It also hides real gaps — a UPS that never got a
    name is invisible to the UPS/battery pairing check.
    """
    for a in assets:
        name = norm(a.get("name"))
        if name and PLACEHOLDER_NAME.match(name):
            F.add(a, "X3", "High", "Name",
                  f"name {name!r} is an integration placeholder")


def duplicates(assets, F):
    """X2 — two assets sharing a non-blank MAC or serial. Adds to F."""
    seen = {}
    for a in assets:
        for key, normer in (("MAC Address", _norm_mac),
                            ("Serial Number", lambda v: norm(v).lower())):
            raw = a["f"].get(key)
            # Ignore blanks, placeholders, AND deliberate N/A — a shared "n/a"
            # is not a duplicate, it is two records that both say "not applicable".
            if is_gap(raw) or norm(raw).lower() in ACCEPTABLE:
                continue
            v = normer(raw)
            if not v:
                continue
            if (key, v) in seen:
                first = seen[(key, v)]
                F.add(a, "X2", "Medium", key,
                      f"{key} {norm(raw)} shared with {first[0]} ({first[1]})",
                      other_id=first[0], other_url=first[2])
            else:
                seen[(key, v)] = (a["id"], a["name"], a.get("hudu_url"))


def _layout_was_collected(company_id, layout_id):
    """True when fetch_log shows this layout was actually queried.

    Distinguishes a genuinely empty layout (a real X1 finding) from one we
    never fetched (a hole in our own data). Falls back to True when the
    coverage module is unavailable, so a missing helper degrades to the old
    behaviour rather than silently suppressing every X1.
    """
    try:
        import doc_coverage as _cov
        return _cov.is_collected(company_id, layout_id)
    except ImportError:
        # Default when doc_coverage helper is unavailable: True.
        # This preserves the original behavior (treating the layout as collected)
        # rather than suppressing X1 findings on empty layouts.
        return True


def evaluate(assets, layout_name, layout_id, company_id=None):
    group = layout_group(layout_id)
    if group == "infrastructure":
        F = evaluate_infrastructure(assets, layout_name, layout_id)
    elif group == "client-identity":
        F = evaluate_client_identity(assets, layout_name, layout_id)
    elif group == "services":
        F = evaluate_services(assets, layout_name, layout_id)
    elif group == "commercial":
        F = evaluate_commercial(assets, layout_name, layout_id)
    elif group == "physical":
        F = evaluate_physical(assets, layout_name, layout_id)
    else:
        F = Findings()

    # PH14 — UPS/battery pairing (cross-record, layout 36 only)
    if layout_id == 36 and assets:
        cid = company_id or assets[0]["company_id"]
        evaluate_ups_battery_pairing(cid, F)

    # I8 — cloud controller placement (cross-layout, layout 4 only)
    if layout_id == 4 and assets:
        cid = company_id or assets[0]["company_id"]
        evaluate_controller_placement(cid, F)

    # CM9/CM10 — network device license coverage (cross-layout, layout 19 only)
    if layout_id == 19 and assets:
        cid = company_id or assets[0]["company_id"]
        evaluate_license_coverage(cid, F)

    # X2 applies to every layout
    F.ran("X2")
    duplicates(assets, F)

    # X3 applies to every layout
    F.ran("X3")
    placeholder_names(assets, F)

    # X1 — Empty Layout · Medium
    if _layout_was_collected(company_id, layout_id):
        F.ran("X1")

    findings = F.collapsed()

    if not assets and _layout_was_collected(company_id, layout_id):
        findings.append({
            "asset_id": None, "asset": "(layout)", "hudu_url": None,
            "component": "X1", "severity": "Medium", "fields": [], "field": "",
            "detail": f"0 objects in {layout_name}",
        })

    findings.sort(key=lambda x: (SEV_ORDER.index(x["severity"]), x["asset_id"] or 0))
    if company_id is not None:
        record_findings_ledger(company_id, layout_id, findings)
    return findings, group


def prose(assets, group):
    """Raw values the model must judge. Never decided in code."""
    out = []
    for comp, label in PROSE_FIELDS.get(group, []):
        for a in assets:
            v = a["f"].get(label)
            if v is not None:
                out.append({"component": comp, "field": label,
                            "asset_id": a["id"], "asset": a["name"],
                            "hudu_url": a.get("hudu_url"), "value": norm(v)})
    return out


def counts(findings):
    c = {}
    for f in findings:
        c[f["severity"]] = c.get(f["severity"], 0) + 1
    return c


def record_findings_ledger(company_id, layout_id, findings):
    """Write findings to the company state database findings table.

    Stable identity: (company_id, layout_id, component, asset_id or 'none', hash(detail))
    """
    if not _layout_was_collected(company_id, layout_id):
        return

    path = db_path(company_id)
    if not os.path.exists(path):
        return

    con = sqlite3.connect(path)
    cur = con.cursor()
    cur.execute("""
    create table if not exists findings(
        run_id int,
        company_id int,
        layout_id int,
        component text,
        severity text,
        tier int,
        asset_id text,
        asset_name text,
        hudu_url text,
        detail text,
        field text,
        status text,
        first_seen int,
        last_seen int
    )
    """)

    cur.execute("select coalesce(max(run_id), 0) from findings")
    max_run = cur.fetchone()[0]
    now = int(time.time())
    run_id = max(now, max_run + 1)

    cur.execute("""
    select rowid, component, asset_id, detail, first_seen, status
    from findings
    where company_id = ? and layout_id = ?
    """, (company_id, layout_id))
    existing_rows = cur.fetchall()

    existing_map = {}
    for rowid, comp, aid, det, fseen, st in existing_rows:
        aid_norm = str(aid) if aid is not None and str(aid) != "" else "none"
        det_norm = det or ""
        det_hash = hashlib.sha256(det_norm.encode("utf-8")).hexdigest()
        key = (company_id, layout_id, comp, aid_norm, det_hash)
        existing_map[key] = (rowid, fseen, st)

    current_keys = set()
    for f in findings:
        comp = f["component"]
        sev = f["severity"]
        tier = TIER.get(sev, 1)
        aid_val = f.get("asset_id")
        aid_norm = str(aid_val) if aid_val is not None and str(aid_val) != "" else "none"
        aname = f.get("asset") or ""
        url = f.get("hudu_url") or ""
        det = f.get("detail", "")
        fld = f.get("field") or (", ".join(dict.fromkeys(f.get("fields", []))) if f.get("fields") else "")
        det_hash = hashlib.sha256(det.encode("utf-8")).hexdigest()

        key = (company_id, layout_id, comp, aid_norm, det_hash)
        current_keys.add(key)

        if key in existing_map:
            rowid, fseen, prev_status = existing_map[key]
            cur.execute("""
            update findings
            set run_id = ?, severity = ?, tier = ?, asset_name = ?, hudu_url = ?,
                detail = ?, field = ?, status = 'open', last_seen = ?
            where rowid = ?
            """, (run_id, sev, tier, aname, url, det, fld, now, rowid))
        else:
            cur.execute("""
            insert into findings(
                run_id, company_id, layout_id, component, severity, tier,
                asset_id, asset_name, hudu_url, detail, field, status,
                first_seen, last_seen
            ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', ?, ?)
            """, (run_id, company_id, layout_id, comp, sev, tier,
                  aid_norm, aname, url, det, fld, now, now))

    for key, (rowid, fseen, st) in existing_map.items():
        if key not in current_keys and st == "open":
            cur.execute("""
            update findings
            set status = 'resolved', last_seen = ?
            where rowid = ?
            """, (now, rowid))

    con.commit()
    con.close()


def record_layout_evaluation(company_id, layout_id, payload):
    """Save layout evaluation payload to company state database."""
    path = db_path(company_id)
    if not os.path.exists(path):
        return
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        cur.execute("""
        create table if not exists layout_evaluations(
            company_id int,
            layout_id int,
            data text,
            updated_at int,
            primary key (company_id, layout_id)
        )
        """)
        now = int(time.time())
        cur.execute("""
        insert or replace into layout_evaluations(company_id, layout_id, data, updated_at)
        values (?, ?, ?, ?)
        """, (company_id, layout_id, json.dumps(payload), now))
        con.commit()
        con.close()
    except Exception:
        pass


def compute_layout_components(company_id, layout_id, layout_name, assets, findings, ran_components):
    """Compute per-component status dicts for this layout.

    Statuses:
    - missing: findings emitted
    - partial: findings emitted AND component is partially evaluable (I8, CM9, CM10, PH14)
    - clean: ran() called, no findings
    - not_evaluated: component exists for this layout but nothing ran
    - not_applicable: component's layout is not part of this render / not collected
    """
    is_collected = _layout_was_collected(company_id, layout_id)
    finding_map = {}
    for f in findings:
        finding_map.setdefault(f["component"], []).append(f)

    layout_comps = []
    for cid, info in REGISTRY.items():
        layouts = info.get("layouts")
        is_scope_all = (layouts is SCOPE_ALL)
        if not is_scope_all and (layouts is None or layout_id not in layouts):
            continue

        sev = info.get("severity")
        comp_findings = finding_map.get(cid, [])
        detail = "; ".join(f.get("detail", "") for f in comp_findings) if comp_findings else None

        if not is_collected:
            layout_comps.append({
                "id": cid,
                "status": "not_applicable",
                "severity": sev,
                "detail": None,
                "reason": "the component's layout is not part of this render",
            })
            continue

        if comp_findings:
            if cid in ("I8", "CM9", "CM10", "PH14"):
                status = "partial"
            else:
                status = "missing"
            reason = None
        else:
            if cid in ran_components:
                status = "clean"
                reason = None
            else:
                status = "not_evaluated"
                if info.get("kind") == "out_of_scope":
                    reason = info.get("reason") or "out of scope by decision"
                elif info.get("kind") == "prose":
                    reason = "prose judgment not supplied"
                elif not assets:
                    reason = f"0 objects in {layout_name}"
                else:
                    reason = "component did not run"

        layout_comps.append({
            "id": cid,
            "status": status,
            "severity": sev,
            "detail": detail,
            "reason": reason,
        })
    return layout_comps


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(2)
    company = int(sys.argv[1]); layout = int(sys.argv[2])
    as_json = "--json" in sys.argv
    args = [a for a in sys.argv[3:] if a != "--json"]
    layout_name = args[0] if args else f"layout {layout}"

    assets = load(company, layout)
    findings, group = evaluate(assets, layout_name, layout, company)
    prose_items = prose(assets, group)
    addr_unknown = site_address_unknown(assets, layout)

    if as_json:
        ran_comps = getattr(findings, "ran_components", set())
        layout_comps = compute_layout_components(
            company, layout, layout_name, assets, findings, ran_comps
        )

        payload = {
            "company_id": company, "layout_id": layout,
            "layout_name": layout_name, "group": group,
            "assets": len(assets), "counts": counts(findings),
            "findings": findings, "prose": prose_items,
            "address_unreadable": addr_unknown,
            "components": layout_comps,
        }
        record_layout_evaluation(company, layout, payload)
        print(json.dumps(payload, indent=2))
        sys.exit(0)

    print(f"=== {layout_name} | company {company} | group {group} | "
          f"{len(assets)} assets ===\n")
    for f in findings:
        print(f"{f['severity']:8} | {f['component']:3} | {f['asset_id']} | "
              f"{f['asset']} | {f['detail']}")
        print(f"{'':8} |     | {f['hudu_url']}")
    if prose_items:
        print("\n--- PROSE (model must judge) ---")
        for p in prose_items:
            print(f"{p['component']} | {p['field']} | {p['asset']}")
            print(f"   {p['value'][:300]}")
    if addr_unknown:
        print("\n--- UNKNOWN ---")
        print("S1 address: no ConnectWise cards on any site — addresses unreadable.")
        print("  This is a missing integration, not a per-site gap. Not counted.")
    print()
    c = counts(findings)
    print("COUNTS:", " | ".join(f"{k}: {c.get(k,0)}" for k in SEV_ORDER))
    print("TOTAL FINDINGS:", len(findings))