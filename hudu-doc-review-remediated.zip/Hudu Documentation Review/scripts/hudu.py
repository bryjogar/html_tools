#!/usr/bin/env python3
"""Shared MCP client for Hudu API interactions.

Single source of truth for OAuth token retrieval, JSON-RPC transport,
and MCP tool calls across collect.py and publish.py.
"""
import json
import os
import sqlite3
import sys
import time
import urllib.request

# Default locations, overridable by environment variables.
DEFAULT_STORE = "file:/home/openclaw/.openclaw/state/openclaw.sqlite?mode=ro"
DEFAULT_URL = "https://kb.enabletech.com/mcp"

# Timeout is 180s: publish sends large HTML payloads and collect fetches
# large layout responses; 180s accommodates both safely under load without premature timeouts.
DEFAULT_TIMEOUT = 180


def get_store_path():
    """OAuth token store URI, overridable via HUDU_OAUTH_STORE."""
    return os.environ.get("HUDU_OAUTH_STORE") or DEFAULT_STORE


def get_mcp_url():
    """Hudu MCP server URL, overridable via HUDU_MCP_URL."""
    return os.environ.get("HUDU_MCP_URL") or DEFAULT_URL


def get_token(store=None):
    """Read OAuth access token from read-only SQLite token store."""
    path = store or get_store_path()
    c = sqlite3.connect(path, uri=True)
    row = c.execute("select store_json from mcp_oauth_stores").fetchone()
    if not row:
        raise RuntimeError("no MCP OAuth store found; is the hudu server authorized?")
    d = json.loads(row[0])
    return d["tokens"]["access_token"]


def rpc(token, method, params=None, _id=1, tries=5, url=None, timeout=DEFAULT_TIMEOUT):
    """Execute JSON-RPC 2.0 call with retries against Hudu MCP endpoint."""
    endpoint = url or get_mcp_url()
    body = {"jsonrpc": "2.0", "id": _id, "method": method}
    if params is not None:
        body["params"] = params
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(
                endpoint, data=json.dumps(body).encode(),
                headers={"Authorization": "Bearer " + token,
                         "Content-Type": "application/json",
                         "Accept": "application/json, text/event-stream"},
                method="POST")
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read().decode()
            # streamable-http may frame the reply as SSE
            if raw.lstrip().startswith("event:") or "\ndata:" in raw:
                out = [l[5:].strip() for l in raw.splitlines() if l.startswith("data:")]
                raw = out[-1] if out else raw
            return json.loads(raw)
        except Exception as e:
            # The Hudu MCP endpoint intermittently returns 401 for a valid
            # token, and occasionally drops the connection. Both clear on a
            # retry; do not treat either as a dead token.
            last = e
            time.sleep(1.0 * (i + 1))
    raise last


def call_tool(token, name, args, _id=1, url=None, timeout=DEFAULT_TIMEOUT):
    """Call an MCP tool and parse its text content as JSON or plain string."""
    r = rpc(token, "tools/call", {"name": name, "arguments": args}, _id, url=url, timeout=timeout)
    if "error" in r:
        raise RuntimeError(r["error"])
    content = r.get("result", {}).get("content", [])
    txt = "".join(c.get("text", "") for c in content if c.get("type") == "text")
    return json.loads(txt) if txt.strip().startswith(("{", "[")) else txt
