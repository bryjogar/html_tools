---
name: hudu-doc-review
description: "Review a Hudu client's documentation completeness against the Enable rubric and publish findings as a KB article."
version: 0.9.0
---

# Hudu Documentation Review

Audit one client's Hudu documentation against the Enable completeness rubrics and
publish the findings as a KB article in that client's company.

The article is **internal**. Its reader is the primary field engineer who will
correct the documentation. Write for that person: the actionable item first, the
asset linked, the fix named.

## Scope

**One client per run.** The unit of work is *client × layout group*. A client
report is a rollup of the layout groups reviewed.

## Inputs

| Input | Required | Notes |
| --- | --- | --- |
| `company_id` | yes | The Hudu client to review |
| `tier` | no | 1 = Critical/High (default), 2 = Medium, 3 = Low |

## The shape of a run

Collection and evaluation happen **once per client**. Tiers are a rendering
decision on top of that: tier 2 and tier 3 are re-renders from the same state
database, not re-collects. Run the sweep once, then work Critical/High, then
Medium, then Low, without touching Hudu again.

```
resolve client → coverage gate → collect → evaluate
  → model judges C1/C2 → render --tier N → publish --draft → verify
```

## Procedure

### 1. Resolve the client

Call `hudu__company_show_tool` with the `company_id`. Record the client name.

**Done when:** you have the client name and a confirmed `company_id`.

### 2. Load the rules

Read `{baseDir}/references/{group}.md`. That file is the authority for what is
checked, what passes, and what severity applies. Six files, one per group:

| Group | Rules file |
| --- | --- |
| Client identity | `references/client-identity.md` |
| Infrastructure | `references/infrastructure.md` |
| Services | `references/services.md` |
| Commercial | `references/commercial.md` |
| Physical | `references/physical.md` |
| _(cross-cutting)_ | `references/cross-cutting.md` |

**Done when:** you have the component list and severity table for the group.

### 3. Gather the assets

First check what is already on disk, then collect what is missing:

```bash
python3 {baseDir}/scripts/doc_coverage.py <company_id>            # human-readable
python3 {baseDir}/scripts/doc_coverage.py <company_id> --json     # machine-readable
python3 {baseDir}/scripts/collect.py <company_id> <asset_layout_id>
```

Run the collector once per layout in the group. Data lands in
`{baseDir}/state/<company_id>.sqlite`. Re-running a layout refreshes its rows and
sweeps rows that no longer exist in Hudu, so a deleted or merged record stops
producing findings.

`collect.py` refuses to report success when the pagination block does not carry a
`total_count` it can verify against. Treat that as a stop, not a warning: an
unverifiable collection is how a partly-empty report starts.

**Why not the MCP tool directly:** the model-mediated tool path truncates large
results at roughly 15KB. A 69-asset layout truncates at about 25 assets, and no
`per_page` value fixes it — the cap is on the result as it passes through the
model layer. The direct HTTP call has no such limit: a full layout collects in
seconds with zero truncation and zero model context consumed.

**Done when:** the collector reports `collected N of N` and no rows were left
unverifiable.

### 4. Evaluate

```bash
python3 {baseDir}/scripts/evaluate.py <company_id> <asset_layout_id> --json
```

The evaluator applies the rules file as code — deterministic, no model in the
loop. Every finding carries the asset's `hudu_url`, and every finding is written
to the per-company ledger in `state/<company_id>.sqlite` at every severity, not
only the ones being rendered.

**What the code covers:** the mechanical components across all six groups.
**What it does not cover:** prose judgment. C1 (agreement clarity) and C2
(maintenance window) require reading text, not comparing strings — the evaluator
surfaces their raw values under `prose` and leaves the verdict to you.

**Cross-layout checks.** I8 (controller placement) reads Network Devices (4) and
Applications & Services (13); CM9/CM10 (license coverage) read Network Devices
(4) and Licensing (19); PH14 (UPS/battery pairing) reads Power Management (36)
twice. They are evaluated with their primary layout and reported against the
company or the offending asset.

**Heading fields are never tested.** Hudu layouts use `Heading` fields as section
labels; they carry an empty value and are filtered out in `load()`. Testing one
for presence produces a guaranteed false positive.

**Rules of evidence:**

- Quote the actual value. Do not paraphrase a field you did not read.
- Name asset IDs for every failure, and link each one. "Some records are missing
  X" is not a finding.
- Distinguish a deliberate marker from a blind spot. `N/A`, `NA`, and `None` are
  deliberate and pass; `Unknown`, a placeholder, or a blank is a gap. A blank is
  never a pass — if a field does not apply, the author must say so.
- Never mark an unverifiable component as `pass`.

**Done when:** every component in the rules file has a status.

### 5. Judge the prose components

Read the `prose` values from the evaluator's JSON and decide each one against the
rules file. Write the verdicts to a small JSON file:

```json
{"C1": {"status": "missing", "note": "Support Details names no agreement type"},
 "C2": {"status": "clean",   "note": "Tuesdays 3-10pm, inside the window"}}
```

Pass it to the renderer with `--verdicts`. A prose component with no entry is
reported as **not evaluated** — it is never silently passed, and it is excluded
from the completeness figure rather than counted as clean.

**Done when:** every prose component listed by the evaluator has a verdict.

### 6. Render the article

```bash
python3 {baseDir}/scripts/render.py <company_id> \
    --tier 1 --verdicts <path> [--verdict "one-paragraph verdict"] \
    --out {baseDir}/.staging/<company_id>.html
```

One article per client, titled exactly:

```
00 - Automated Documentation Review Findings
```

The title is the same at every tier. The tier is stated in the header, so the
field engineer always has one current document rather than a shelf of them.

The renderer refuses (exit 2) when a layout in scope was never collected, naming
the missing layout IDs. Pass `--allow-partial` only when you intend a partial
review, and the article will say so at the top.

The header states the tier, the findings shown, the counts deferred to the
ledger, the completeness figure with its numerator and denominator, and how many
components were not evaluated and why. It never prints a zero for a tier that was
evaluated and merely deferred.

**Done when:** the HTML is complete, the title matches exactly, and the header
reconciles.

### 7. Publish

```bash
python3 {baseDir}/scripts/publish.py <company_id> {baseDir}/.staging/<company_id>.html
```

Publishes a **draft** by default. `--publish` makes it live. The script:

- refuses a payload still carrying the verdict placeholder, so a placeholder can
  never reach a live article;
- refuses a payload reporting components that were not evaluated, unless
  `--accept-unknowns` is passed;
- refuses to create a NEW article unless `--allow-create` is passed — editing in
  place is the idempotent path and does not need it;
- looks up an existing article by name **and** slug, refuses when more than one
  matches, and lists every candidate with its id and URL so the surplus can be
  archived by hand;
- refuses a payload above the size ceiling and prints the payload size on every
  run;
- verifies what was stored by re-reading the article and comparing, decoding both
  decimal and hexadecimal entities and ignoring whitespace the editor inserts
  between tags.

**Done when:** the article is written and you have its `id` and `hudu_url`.

### 8. Report back

Return a short summary: client, tier, components passed/total, gap counts by
severity, how many findings were deferred to the ledger, and the article URL. Do
not paste the full article body into chat.

## Scripts

| Script | Purpose |
| --- | --- |
| `scripts/rubric.py` | The registry. Single source of truth for components, severities, layouts, groups, tiers. |
| `scripts/collect.py` | Direct MCP → SQLite. No model, no truncation. Sweeps stale rows. |
| `scripts/evaluate.py` | Rubric as code → findings, per-component status, and ledger rows. `--json` for machine output. |
| `scripts/render.py` | Findings + ledger → HTML article. `--tier`, `--verdicts`, `--inventory`, `--check`. |
| `scripts/publish.py` | HTML → Hudu article. Guarded, idempotent, self-verifying. |
| `scripts/ledger.py` | Inspect the findings ledger: per company, per tier, or the whole sweep. Read-only. |
| `scripts/doc_coverage.py` | Which layouts have actually been collected, and which are missing. |
| `scripts/coverage.py` | CLI alias preserving the original command name. |
| `scripts/hudu.py` | The MCP client: token read, JSON-RPC, tool call. Shared by collect and publish. |

**Nothing declares the rubric except `rubric.py`.** Components, severities,
layout ids, group membership and tier mapping live there and nowhere else. Add or
change a component there and the inventory, the denominator and the dispatch all
follow.

`render.py --check` runs offline and fails on: a registry inconsistency, a rules
file whose `Status:` version disagrees with the newest entry in its own changelog,
or a `report-template.md` inventory that no longer matches `--inventory`. Run it
after any rubric edit.

**Configuration:** `HUDU_STATE_DIR` (default `{baseDir}/state`),
`HUDU_MCP_URL`, `HUDU_OAUTH_STORE`. The OAuth store is opened **read-only**; the
token is never written back and never copied to disk.

## The findings ledger

Every finding at every severity is recorded in `state/<company_id>.sqlite` with a
stable identity, a tier, and `first_seen` / `last_seen` stamps. That is what makes
the three-tier programme possible: Critical/High first, then Medium, then Low,
each a `--tier` re-render with no re-collection, and each able to show what is
new, still open, or resolved since the last run.

```bash
python3 {baseDir}/scripts/ledger.py <company_id>              # tally by tier and component
python3 {baseDir}/scripts/ledger.py <company_id> --tier 2      # just the Medium backlog
python3 {baseDir}/scripts/ledger.py --all                      # the whole sweep, for sequencing
```

A finding that stops being emitted is marked `resolved`, never deleted.

## Boundaries

- **Read-only on assets.** This skill never creates or edits Hudu assets. It
  writes exactly one article per client.
- **Never publish to a company you were not asked to review.**
- **Never invent a rule.** If a rules file does not cover something, it is out of
  scope — do not flag it.
- **There is no delete tool.** Archiving a surplus article is a manual action for
  Bryan. Any duplicate must be reported, not worked around.
- If the rules file for a requested group does not exist, stop and say so.

## Not reviewed, by decision

- **Contacts (1)** — synced from the client's IdP.
- **Workstations (7)** — the layout carries no Manufacturer, Model, Serial, MAC,
  IP, Operating System or Site, so the device core cannot be applied.
- **Catch-All (41)** — inactive layout.
- **PH13 Security Posture (34)** — withdrawn; declared out of scope in the
  registry. Security & Compliance therefore reports as *Not reviewed*, not as
  clean.
- **PH12 certificate validity** — a monitoring concern; the rubric checks that the
  expiry date is recorded, not whether it has passed.

## Open items

Carried here so they are not lost between sessions.

- **Article 7986 is an orphan.** It duplicates 7987 in company 25 and the lookup
  cannot see an archived article. Archive it by hand.
- **The size ceiling is unmeasured.** `publish.py` defaults to a 30000-byte
  pre-flight limit. The real server limit has not been tested; raise it only after
  measuring against one company with a throwaway draft.
- **Workstations duplicates stay invisible.** X2 does not run on layout 7 because
  the layout is out of scope, so a duplicate MAC there is not reported.
- **The prose verdicts step is manual.** C1 and C2 need a model or a human; a run
  that skips `--verdicts` will report them as not evaluated.

## Adding a layout group

1. Write `{baseDir}/references/{group}.md` following the shape of
   `client-identity.md`: purpose, severity table, engagement-type conditionals,
   components with pass/fail criteria, out-of-scope list, changelog.
2. Keep it to 3–5 major components. This is a triage rubric, not a field audit.
3. Add an entry per component to `REGISTRY` in `scripts/rubric.py`, with its
   group, kind, severity and layouts, and add the layouts to `SCOPE_LAYOUTS` if
   they are new.
4. Add a fixture case to `scripts/tests/fixture_build.py` covering the component's
   pass and fail branches.
5. Run `python3 -m pytest scripts/tests -q` and
   `python3 scripts/render.py --check`.

| Group | Layouts | Rules file | Status |
| --- | --- | --- | --- |
| Client identity | Client Overview (33), Sites (2) | `references/client-identity.md` | v0.6 draft |
| Infrastructure | Servers (3), Network Devices (4), LAN (18), WAN (17), Wi-Fi (25), SSIDs (29), IPMI (27) | `references/infrastructure.md` | v0.8 draft |
| Services | Applications & Services (13), Backups (14), Email (15), File Sharing (16), IdP (12), Remote Access (21), Virtualization (23) | `references/services.md` | v0.1 draft |
| Commercial | Licensing (19), Contracts (32), Vendors (22) | `references/commercial.md` | v0.4 draft |
| Physical | Printers & Scanners (5), Printing (20), Phones (11), Phone Systems (24), Analog Lines (30), Audio Visual (9), Building Automation (8), Building Security (6), Mobile Devices (10), Power Management (36), SSL Certificates (35), Security & Compliance (34) | `references/physical.md` | v0.3 draft |
| _(cross-cutting)_ | all layouts | `references/cross-cutting.md` | v0.2 draft |

**One rules file per group.** `network-segments.md` and `wireless.md` were merged
into `infrastructure.md` as Parts 2 and 3 (v0.7).

**Group membership and dispatch are not restated here.** They come from
`scripts/rubric.py`. The table above is the reading order, not the authority.

## Tests

```bash
python3 -m pytest scripts/tests -q
```

The suite covers the registry, the applicability rules, the accounting, the
ledger, tiering, publishing guards, collection integrity, and a byte-exact golden
render of a synthetic fixture at `scripts/tests/golden/`. Changes to a golden file
are recorded in `scripts/tests/golden/CHANGELOG.md` in the same commit; there are
no client records in this tree and there must never be.
