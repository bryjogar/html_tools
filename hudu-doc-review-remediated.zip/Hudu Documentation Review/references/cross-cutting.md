# Cross-Cutting Checks

**Status:** draft v0.2
**Applies to:** every layout in every group

These checks run regardless of which layout group is being reviewed. They are
not part of any group's rules file.

---

## X1 — Empty Layout · Medium

If a layout has **zero** objects for the client, raise a Medium alert.

- **Alert:** 0 objects in the layout.
- **Not a failure.** A cloud-first client may legitimately have no on-prem
  servers, no network devices, or no contracts. The alert exists so the team can
  validate that the absence is real rather than an undocumented gap.

This is the one check that cannot be resolved from data alone. It is always a
review item, never an auto-pass.

**Evaluate for every layout in the reviewed group**, including layouts the client
is not expected to have.

---

## X2 — Duplicate Records · Medium

Two assets in the same layout that share a **MAC Address** or a **Serial
Number** are probable duplicates.

- **Alert:** two or more assets share an identical non-blank MAC or serial.
- **Severity:** Medium. A duplicate record splits the documentation of one
  device across two entries; an engineer reading either one sees a partial
  picture. It also inflates asset counts used for licensing and budgeting.

**Matching:** compare normalized values (trim, lowercase, strip separators from
MACs). Ignore blank, `N/A`, and placeholder values — those are already covered
by the group rules and would produce noise.

**Not a failure.** A shared serial can be legitimate — e.g. a chassis and its
management module, or a device recorded once per site. The alert exists so the
team can confirm whether the pair is a true duplicate or two real records.

---

## X3 — Placeholder Record Name · High

A record whose **name** is an integration placeholder rather than a real device
identity.

- **Alert:** the asset name matches a known placeholder pattern — `Device@<ip>`,
  `Asset@`, `Host@`, `Node@`, `Unknown`, `New Asset`, `Unnamed`, `No Name`.
- **Severity:** High. The name is the one field every other record and every
  engineer is matched against. A placeholder means the asset cannot be
  identified from the documentation at all — you cannot tell what the device is
  or where it lives without opening the integration card.

**Why this is High and not Medium.** A placeholder name is not a cosmetic
problem. It is the visible symptom of a record that was created by an
integration and never curated:

- The device is unidentifiable in any list, report, or search.
- It **hides other gaps.** A UPS that never got a name is invisible to the
  UPS/battery pairing check (PH14), because pairing is by name. The same is true
  of any name-keyed check.
- It inflates the asset count with records that carry no usable information.

**Not a failure of the integration.** Auvik and similar tools create a record
the moment a device is discovered, before anyone has identified it. The gap is
that nobody came back and named it. The alert exists so the team can finish the
job the integration started.

**Matching:** case-insensitive, anchored at the start of the name. A real name
that merely contains `@` (an email-style label) is not a placeholder.

---

## Changelog

- v0.2 — added X3 (placeholder record name).
- v0.1 — moved from `infrastructure.md` (was I8) so it applies to all groups.