# Services — Completeness Rules

**Group:** Services
**Layouts:** Applications & Services (13), Backups (14), Email (15), File Sharing (16), Identity Providers (12), Remote Access (21), Virtualization (23)
**Status:** draft v0.1 — pending review
**Gold standards:** company 25 (Park Cities Presbyterian Church), company 150 (Enable Gold Standards)

---

## Purpose

This is a **triage rubric, not a field audit.**

These layouts describe the *services* a client runs, not the hardware underneath
them. A field is in scope if a documentation audience needs it to do their job.

## Audiences

| Audience | Role | What they need from a service record |
| --- | --- | --- |
| **Service Desk** | Remote tier 1/2 — user support, ticket triage | What the service is, how a user reaches it |
| **Support / Field Engineers** | Remote and on-site tier 3/4 | Where it runs, what it depends on |
| **Senior Engineers** | Tier 5 — solutions architecture | Platform, hosting, identity, integration |
| **Strategy Consultants** | Long-term planning, budgeting, projects | Ownership, vendor, lifecycle |

---

## Severity

| Level | Definition | Test |
| --- | --- | --- |
| **Critical** | Blocks service delivery or creates wrong-action risk. | "Would this stop someone doing their job, or make them do it wrong?" |
| **High** | Degrades service quality or slows response. | "Would this cost us time or cause a bad handoff?" |
| **Medium** | Reduces efficiency; causes hunting. | "Would someone have to ask a person instead of reading the KB?" |
| **Low** | Cosmetic or genuinely optional. | "Would anyone notice?" |

## Value semantics

| Value | Meaning | Verdict |
| --- | --- | --- |
| `N/A`, `NA`, `None` | Deliberate; the author has stated the field does not apply | **Acceptable** |
| `Unknown` | Admission of ignorance | **Gap** |
| blank / null | Never filled in | **Gap** |
| `TBD`, `-`, `?`, `xxx` | Placeholder | **Gap** |

**A blank is a blind spot, not a pass.** If a field is not relevant, say so with
a deliberate marker. Silence is indistinguishable from an oversight, so it is
always flagged. `N/A`, `NA`, and `None` are the three accepted markers.

## Counting

Findings are counted **per asset per component**, not per field. An application
missing both Category and Importance is **one** SV1 finding, not two.

**Relation fields** (`Application Server(s)`, `Vendor`, `Protected Systems`,
`Server(s)`, `AD Server(s)`, `Virtualization Host(s)`, `Virtual Machine(s)`,
`Hosting Provider`, `PSTN Provider`) are JSON arrays of linked assets. An empty
array `[]` counts as missing, exactly like a blank string.

**Conditional components** are evaluated only when their trigger field is
populated. A component whose trigger is blank is not silently passed — the
trigger itself is usually a finding under another component.

---

## Layout 13 — Applications & Services

### SV1 — Application Identity & Hosting · Critical

`Category`, `Importance`, and `Application Location` must be populated, and the
hosting detail must match the stated location.

- **Fail:** any of the three blank, `Unknown`, or a placeholder.
- **Fail:** `Application Location` is `On Premise/DataCenter` but no
  `Application Server(s)` and no `On-Prem System URL`.
- **Fail:** `Application Location` is `Hosted/SaaS` but no `Hosted System URL`.

Without these, nobody can tell what the application is, how important it is, or
where it lives.

### SV2 — Application Ownership · Medium

`Application Champion` and `Vendor` must be populated.

- **Fail:** either blank or an empty relation.

The champion is who the service desk escalates to; the vendor is who supports it.

---

## Layout 14 — Backups

### SV3 — Backup Coverage · Critical

`Backup Type`, `Protected Systems`, and `Offsite Storage Provider` must be
populated.

- **Fail:** any of the three blank or an empty relation.

A backup record that does not say what it protects, or where the offsite copy
lives, cannot be used to restore anything.

### SV4 — Backup Retention · Medium

`Local Backup Storage Location` and `Local Backup Retention` must be populated
when a local backup exists.

- **Fail:** `Local Backup Server(s)` populated but storage location or retention
  blank.

---

## Layout 15 — Email

### SV5 — Email Platform · High

`Type`, `Inbound SMTP Gateway`, and `Webmail URL` must be populated.

- **Fail:** any of the three blank.

---

## Layout 16 — File Sharing

### SV6 — File Share Access · High

The share must be reachable: either on-premises or cloud-hosted.

- **Fail:** `On-Premises File Share` populated but `Share Name` or
  `Folder Path` blank.
- **Fail:** `Cloud Hosted File Share` populated but `Hosted System URL` blank.
- **Fail:** neither on-premises nor cloud-hosted is populated.

---

## Layout 12 — Identity Providers (IdP)

### SV7 — Directory Identity · Critical

`Directory Type` must be populated. When it is Active Directory, `AD Full Name
(FQDN)` and `AD Server(s)` must also be populated.

- **Fail:** `Directory Type` blank, `Unknown`, or a placeholder.
- **Fail:** `Directory Type` is Active Directory but FQDN or server list blank.

### SV8 — Directory Sync · Medium

When `Directory Sync` is anything other than `None`, `Directory Sync Server(s)`
must be populated.

- **Fail:** sync configured but no sync server linked.
- **Pass:** `Directory Sync` is `None`.

---

## Layout 21 — Remote Access

### SV9 — Remote Access Method · High

At least one remote access method must be documented, and the chosen method must
be complete.

- **Fail:** `VPN` populated but `VPN Endpoint`, `VPN Protocol`, or
  `VPN Authentication` blank.
- **Fail:** `Remote Desktop` populated but `Remote Desktop Endpoint` blank.
- **Fail:** neither VPN nor Remote Desktop is populated.

---

## Layout 23 — Virtualization

### SV10 — Virtualization Platform · High

`Virtualization Technology`, `Virtualization Host(s)`, and `Virtual Machine(s)`
must be populated.

- **Fail:** any of the three blank or an empty relation.
- **Fail:** `Virtualization Technology` is a public-cloud type but
  `Hosting Provider` blank.

---

## Out of scope

- `Notes` — free text, on every layout in this group.
- `Licensing & Support Information`, `Compliance Information`,
  `Application Information` (13) — free text.
- `Exceptions` (14) — free text.
- `SMTP Relay` (15) — free text; the platform fields are what matter.
- `Mapped Drive Letter` (16) — cosmetic.
- `Active Directory` (12) — a heading field, not data.
- `Client Access to Enable ScreenConnect` and the ScreenConnect user lists (21)
  — advisory, not a completeness gap.
- `Virtualization Storage` (23) — free text.

---

## Changelog

- v0.1 — initial draft from gold standards 25 / 150. SV1–SV10.