# Commercial — Completeness Rules

**Group:** Commercial
**Layouts:** Licensing (19), Contracts (32), Vendors (22)
**Status:** draft v0.4 — pending review
**Gold standards:** company 25 (Park Cities Presbyterian Church), company 150 (Enable Gold Standards)

---

## Purpose

This is a **triage rubric, not a field audit.**

These layouts describe what the client *pays for* and *who they pay*. A field is
in scope if a documentation audience needs it to do their job.

---

## Severity

| Level | Definition | Test |
| --- | --- | --- |
| **Critical** | Blocks service delivery or creates wrong-action risk. | "Would this stop someone doing their job, or make them do it wrong?" |
| **High** | Degrades service quality or slows response. | "Would this cost us time or cause a bad handoff?" |
| **Medium** | Reduces efficiency; causes hunting. | "Would someone have to ask a person instead of reading the KB?" |
| **Low** | Cosmetic or genuinely optional. | "Would anyone notice?" |

## Value semantics

| Value | Meaning | Verdict |
| --- | --- | --- |
| `N/A`, `NA`, `None` | Deliberate; the author has stated the field does not apply | **Acceptable** |
| `Unknown` | Admission of ignorance | **Gap** |
| blank / null | Never filled in | **Gap** |
| `TBD`, `-`, `?`, `xxx` | Placeholder | **Gap** |

**A blank is a blind spot, not a pass.** If a field is not relevant, say so with
a deliberate marker. Silence is indistinguishable from an oversight, so it is
always flagged. `N/A`, `NA`, and `None` are the three accepted markers.

## Counting

Findings are counted **per asset per component**, not per field. A license
missing both Version and Seats is **one** CM1 finding, not two.

**Relation fields** (`Reseller`, `Vendor`) are JSON arrays of linked assets. An
empty array `[]` counts as missing, exactly like a blank string.

---

## Layout 19 — Licensing

### CM1 — License Identity · Critical

`Version`, `Seats`, and `License Key(s)` must be populated.

- **Fail:** any of the three blank, `Unknown`, or a placeholder.

Without these, nobody can tell what is licensed, how many seats exist, or how to
activate it.

### CM2 — License Lifecycle · High

`Purchase Date` and `Renewal Date` must be populated.

- **Fail:** either blank.

Purchase and renewal dates are what the strategy consultants need most of all,
so this stays High.

### CM2a — Renewal Price · Low

`Renewal Price` must be populated.

- **Fail:** blank.

A real gap, but a procurement detail rather than a support-critical one.
Demoted from High to Low.

### CM3 — License Reseller · **DROPPED**

`Reseller` is no longer checked. It is a procurement detail, not a
triage-relevant field, and it generated 38 findings on PCPC alone. Dropped in
favour of triage.

---

## Layout 32 — Contracts

### CM4 — Contract Identity · Critical

`Account Number`, `Vendor`, and `Term` must be populated.

- **Fail:** any of the three blank or an empty relation.

### CM5 — Contract Lifecycle · High

`Date Signed`, `Expiration Date`, and `Expiration Action Date` must be populated.

- **Fail:** any of the three blank.

### CM6 — Contract Price · Medium

`Price` and `Price Frequency` must be populated.

- **Fail:** either blank.

---

## Layout 22 — Vendors

### CM7 — Vendor Contact · High

At least one support channel must exist.

- **Fail:** `Support Phone Number`, `Support Email Address`, and
  `Support Website` are all blank.

This is the whole point of a vendor record: when a service is down, someone has
to be able to reach the vendor. Requiring all three false-positives on vendors
reachable by website or rep email only.

### CM8 — Vendor Account · **DROPPED**

`Account Number`, `Account Rep Name`, and `Account Rep Email Address` are no
longer checked. A named account rep is a human contact at a vendor — the same
category as the PE/SE/CRM names already ruled out of scope. It generated 63
findings on PCPC alone. Dropped in favour of triage.

---

## Cross-layout — Network device license coverage

**These components read two layouts at once:** Network Devices (4) and
Licensing (19). They are evaluated when the Licensing layout is reviewed, and
reported against the company rather than a single asset.

**Why this exists.** Network hardware is licensed per device, and the license is
recorded as a separate Licensing record. The failure mode is silent: the devices
are documented, the license record is missing or under-counted, and nobody
notices until a renewal or a support call. This is the specific failure point
this check exists to catch.

**Vendor map.** A vendor is checked only when the client has devices of that
vendor *and* the device type actually carries a license. A UniFi or Aruba switch
needs no license, so counting it would be a false positive.

| Vendor | Aliases matched in license names | Device types counted |
| --- | --- | --- |
| Ruckus | `ruckus` | Wireless Access Point |
| SonicWall | `sonicwall`, `sonic wall` | Firewall |
| Meraki | `meraki` | Wireless Access Point |
| Aruba | `aruba` | Wireless Access Point |
| Ubiquiti | `ubiquiti`, `unifi` | Wireless Access Point |
| Sangoma | `sangoma`, `switchvox` | PBX |
| HostiFi | `hostifi` | Network Controller |

**A license is required for every device.** Confirmed by the client owner: a
missing license record is a real gap, not an acceptable absence. This applies to
SonicWall (E/APSS) as much as to Ruckus or Meraki — a SonicWall firewall with no
license record is a CM9 finding, and that is intended.

### CM9 — Network License Coverage · High

A license record must exist for every licensed network vendor present.

- **Fail:** the client has N devices of a mapped vendor and device type, but no
  license record whose name matches that vendor.

### CM10 — Network License Count · Medium

The recorded seat count must cover the device count.

- **Fail:** total `Seats` across the vendor's license records is less than the
  number of licensed devices.
- **Pass:** seats ≥ devices.

**Known limitation — seat semantics.** `Seats` is not consistently a device
count. A Ruckus One record may carry 35 seats for 39 APs, or a Meraki cloud
license may carry 1 seat covering 20 APs. The check reports the discrepancy for
human review rather than asserting a hard failure. Treat CM10 as a prompt to
verify, not a proven defect.

**Known limitation — vendor matching is by name.** License records are matched
to vendors by substring on the record name. A license named in a way that does
not mention the vendor will not be found, producing a CM9 false positive. The
map above is the authority; extend it when a new vendor appears.

---

## Out of scope

- `Notes` — free text, on every layout in this group.
- `SKU` and `ID` (19) — present on only 52 of 62 records in the gold standard;
  the license key and version are the identity fields that matter.
- `License Key(s)` (19) — **not required.** Subscription licenses (M365, Google
  Workspace, Mosyle, HostiFi) have no key by nature, and no field distinguishes
  subscription from perpetual. Requiring it false-positived on 4 of 7 EGS
  licenses.
- `Reseller` (19) — dropped; procurement detail.
- `Account Number`, `Account Rep Name`, `Account Rep Email Address` (22) —
  dropped; named human contacts, same category as PE/SE/CRM names.
- `Expiry Alert Override`, `Automation Control` — operational settings, not
  documentation completeness.
- `Products/Services Provided` (22) — free text.
- `General Support`, `Account Rep` (22) — heading fields, not data.
- `Preferred Payment Method` (22) — present on only 22 of 95 records; a
  billing preference, not a support-critical field.

---

## Changelog

- v0.4 — confirmed a license is required for every device, including SonicWall
  (E/APSS). CM9 on a SonicWall firewall with no license record is intended, not
  a false positive.
- v0.3 — added CM9 (network license coverage) and CM10 (network license count),
  cross-layout checks against Network Devices (4). Vendor map with device-type
  scoping so unlicensed switch vendors do not false-positive.
- v0.2 — triage pass. CM3 (Reseller) and CM8 (Vendor Account) dropped as
  procurement/relationship detail. CM2 split: Purchase/Renewal Date stay High,
  Renewal Price demoted to Low (CM2a). License Key(s) removed from CM1
  (subscriptions have no key). CM7 relaxed to require at least one support
  channel rather than all three.
- v0.1 — initial draft from gold standards 25 / 150. CM1–CM8.