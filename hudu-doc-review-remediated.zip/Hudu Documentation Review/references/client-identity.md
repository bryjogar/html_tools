# Client Identity — Completeness Rules

**Group:** Client identity
**Layouts:** Client Overview (33), Sites (2)
**Status:** draft v0.6 — pending review
**Gold standards:** company 25 (Park Cities Presbyterian Church), company 150 (Enable Gold Standards)

---

## Purpose

This is a **triage rubric, not a field audit.** It checks the few components that
actually affect service delivery. Everything else is out of scope on purpose —
flagging low-value fields creates remediation work that costs the team more than
the gap does.

If a component is not listed here, it is not reviewed.

---

## Severity

| Level | Definition | Test |
| --- | --- | --- |
| **Critical** | Blocks service delivery or creates wrong-action risk. | "Would this stop someone doing their job, or make them do it wrong?" |
| **High** | Degrades service quality or slows response. | "Would this cost us time or cause a bad handoff?" |
| **Medium** | Reduces efficiency; causes hunting. | "Would someone have to ask a person instead of reading the KB?" |
| **Low** | Cosmetic or genuinely optional. | "Would anyone notice?" |

---

## Engagement type

Every rule below is conditional on engagement type. Read it first.

Derived from `Support Details & Exceptions` prose, cross-checked against the
supported-services checkboxes.

| Profile | Signal |
| --- | --- |
| **Managed** | Servers / Network / Workstations / Service Desk true |
| **Products Only** | `Products Only` true; service checkboxes false |
| **Project / Ad Hoc** | `Project Only` or `Consulting/Ad Hoc Only` true |

**Value semantics — this distinction is load-bearing:**

| Value | Meaning | Verdict |
| --- | --- | --- |
| `N/A`, `NA`, `None` | Deliberate; the author has stated the field does not apply | **Acceptable** |
| `Unknown` | Admission of ignorance | **Gap** |
| blank / null | Never filled in | **Gap** |
| `TBD`, `-`, `?`, `xxx` | Placeholder | **Gap** |

**A blank is a blind spot, not a pass.** If a field is not relevant, say so with
a deliberate marker. Silence is indistinguishable from an oversight, so it is
always flagged. `N/A`, `NA`, and `None` are the three accepted markers.

A Products Only client legitimately carries `N/A` in engineering-role fields.
A Managed client carrying `N/A` there has a gap.

---

## Layout 33 — Client Overview

### C1 — Agreement Clarity · Critical

`Support Details & Exceptions` must state the agreement type explicitly.

- **Pass:** names a type — "Full MSA", "Product Solutions", "Project Only".
- **Fail:** blank, or vague prose that never names the agreement.
- **Fail:** contradicts the supported-services checkboxes.

### C2 — Maintenance Window · High

`Preferred Maintenance Window` must be present, specific, and inside the
supported window.

- **Pass:** a specific day/time range — "Mondays or Tuesdays from 12-6 AM",
  "Tuesdays 3-10pm".
- **Pass:** `N/A` for Products Only / Project.
- **Fail:** blank, `Unknown`, `TBD`, or any other placeholder.
- **Fail:** **Friday or Saturday included.** These are not supported maintenance
  days.
- **Fail:** too broad to act on — a day *range* rather than a window, e.g.
  "Monday through Friday", "weeknights", "after hours".

The test: could an engineer schedule the work from this field alone, without
asking anyone? If not, it fails.

### C3 — Contact & Authorization Chain · Critical

`Primary POC`, `Access Authorizers`, and `Emergency Contacts` must each be
non-empty.

- **Fail:** any of the three empty.

Tag resolution is not checked — that is a separate cleanup concern, not a
documentation-completeness one.

**C3a — Single point of contact · Low**

If the same person fills all three roles, raise a Low alert. Some clients
legitimately need only one contact; others do not. This is an advisory, not a
failure — it exists so the team can judge whether the client needs more.

- **Alert:** Primary POC, Access Authorizers, and Emergency Contacts all resolve
  to the same single person.
- **Pass:** any role has a different or additional person.

### C4 — Service Scope Consistency · Critical

- At least one supported-services checkbox is true.
- Checkboxes are consistent with the stated agreement type.
- At most one of `Consulting/Ad Hoc Only`, `Project Only`, `Products Only` is true.
- `Workstations - Full Support` and `Workstations - Patching/AV Only` are mutually exclusive.
- Alert routing: if `Workstation Alert Routing` or `Critical Network/Server Alert
  Notifications` is true, its destination must be populated.
- **Alert routing is `N/A` for Products Only** — those clients are not co-managed.

---

## Layout 2 — Sites

### S1 — Site Validity & Coverage · Medium

Every Site must be a real, supportable location with an address.

- **Fail:** a non-location — "Cloud", "Other Building", "Remote", "N/A",
  "Various". These are not places we can be dispatched to.
- **Fail:** no address on record.
- **Fail:** no Site exists at all.

**Address source:** the Sites layout has no address field. The address comes from
the linked ConnectWise card (`cards[].data.addressLine1` / `city` / `zip`).

**Integration dependency — read this before failing a site.** If the client has
**no cards at all**, addresses are unreadable for every site. That is a missing
ConnectWise integration, not a per-site documentation gap. Report it **once** as
`unknown` and do not count it as a finding. Failing every site would put the same
false positive in the report for every client that has not been integrated yet.

A site with cards present but no address on its own card **is** a finding — the
integration works, the address is simply missing.

`state` is frequently `null` in the ConnectWise payload. Street, city, and zip
are what make an address dispatchable; a null `state` is a sync artifact and is
**not** a finding.

Asset-to-site tagging is **not** checked. Most clients are single-site, so the
check adds cost without adding signal.

`Notes` is optional and is not reviewed.

---

## Out of scope

- **Contacts (layout 1)** — synced from the client's IDP. Not reviewed.
- **Engineering role fields** — Primary Engineer, Senior Engineer/Architect,
  Strategy Consultant, CRM, Secondary Enable Resource(s). Not reviewed.
- **Sites `Notes`** — optional.

---

## Changelog

- v0.6 — value semantics corrected: a blank is a blind spot, not a pass. `None`
  joins `N/A`/`NA` as an accepted deliberate marker.
- v0.5 — S1: integration dependency documented. A client with no cards at all
  reports address as `unknown` once, not as a per-site failure. Null `state`
  explicitly not a finding.
- v0.4 — C3a added (single point of contact, Low). S1 asset-tagging check
  dropped; most clients are single-site.
- v0.3 — C2: Friday/Saturday excluded, specificity required. S1: real-location
  and address checks added.
- v0.2 — C3 reduced to a non-empty check; tag resolution dropped.
- v0.1 — initial draft from gold standards 25 / 150 and POC article 7970.