# Infrastructure — Completeness Rules

**Group:** Infrastructure
**Layouts:** Servers (3), Network Devices (4), LAN (18), WAN (17), Wi-Fi (25), SSIDs (29), IPMI (27)
**Status:** draft v0.8 — pending review
**Gold standards:** company 25 (Park Cities Presbyterian Church), company 150 (Enable Gold Standards)

---

## Purpose

This is a **triage rubric, not a field audit.**

A field is in scope if **any** of the documentation audiences needs it to do
their job. A field that serves nobody is out of scope.

This group covers the network and compute estate. It is organised in four parts
because the layouts are not all the same shape:

| Part | Layouts | What the record is |
| --- | --- | --- |
| **1. Devices** | Servers (3), Network Devices (4) | A physical or virtual device |
| **2. Network segments** | LAN (18), WAN (17) | A VLAN/segment, or a carrier circuit |
| **3. Wireless** | Wi-Fi (25), SSIDs (29) | A wireless system, or one broadcast network |
| **4. IPMI** | IPMI (27) | An out-of-band management interface |

A LAN record is not a device. It carries no Manufacturer, Model, Serial, or MAC,
so the device rules (I1, I5, I6, I7) are structurally inapplicable to it. Each
part below is the authority for its own layouts.

## Audiences

| Audience | Role | What they need from a record |
| --- | --- | --- |
| **Service Desk** | Remote tier 1/2 — user support, ticket triage | What the device is, how to reach it, where it is |
| **Support / Field Engineers** | Remote and on-site tier 3/4 | Physical location, hardware identity, serial |
| **Senior Engineers** | Tier 5 — solutions architecture | MAC, OS, platform, hosting, subnet, transport |
| **Strategy Consultants** | Long-term planning, budgeting, projects | Lifecycle dates — purchase, install, warranty |
| **CRM** | Client relations | Scope and agreement context (see Client identity) |

## Field-to-audience map — devices

| Field | Service Desk | Field Eng | Senior Eng | Strategy |
| --- | :---: | :---: | :---: | :---: |
| Device Type | ● | ● | ● | |
| Manufacturer / Model | ● | ● | ● | |
| Site | ● | ● | | |
| Physical Location | | ● | | |
| IP Address | ● | ● | ● | |
| Serial Number | | ● | ● | |
| MAC Address | | ● | ● | |
| Operating System | ● | | ● | |
| Hosting Provider | | | ● | |
| Purchase Date | | | | ● |
| Install Date | | | | ● |
| Warranty Expiration | | | | ● |

---

## Severity

| Level | Definition | Test |
| --- | --- | --- |
| **Critical** | Blocks service delivery or creates wrong-action risk. | "Would this stop someone doing their job, or make them do it wrong?" |
| **High** | Degrades service quality or slows response. | "Would this cost us time or cause a bad handoff?" |
| **Medium** | Reduces efficiency; causes hunting. | "Would someone have to ask a person instead of reading the KB?" |
| **Low** | Cosmetic or genuinely optional. | "Would anyone notice?" |

## Value semantics

| Value | Meaning | Verdict |
| --- | --- | --- |
| `N/A`, `NA`, `None` | Deliberate; the author has stated the field does not apply | **Acceptable** |
| `Unknown` | Admission of ignorance | **Gap** |
| blank / null | Never filled in | **Gap** |
| `TBD`, `-`, `?`, `xxx` | Placeholder | **Gap** |

**A blank is a blind spot, not a pass.** If a field is not relevant, say so with
a deliberate marker. Silence is indistinguishable from an oversight, so it is
always flagged. `N/A`, `NA`, and `None` are the three accepted markers.

## Counting

Findings are counted **per asset per component**, not per field.

If `Device@10.0.8.99` is missing Manufacturer, Model, and Device Type, that is
**one** I1 finding — "identity missing" — not three. The article reports
distinct problems, not field count. The detail line lists every missing field so
nothing is lost.

This keeps severity totals meaningful: a single empty record should not inflate
the Critical count to three.

**Relation fields** (`Site`, `Vendor`, `Contract`, `Router/Firewall`,
`Wireless Controller(s)`, `Wireless Access Point(s)`, `SSID(s)`, `LAN`, `Server`)
are JSON arrays of linked assets. An empty array `[]` counts as missing, exactly
like a blank string.

**Heading fields are never tested.** Hudu layouts use `Heading` fields as section
labels; they carry an empty value. Testing one for presence is a guaranteed false
positive. The evaluator filters them out at load time.

---

# Part 1 — Devices

**Layouts:** Servers (3), Network Devices (4)

## Device-type conditionals

Several fields describe physical hardware and do not apply to virtual machines.
Read `Device Type` first, then apply the right rule set.

| Field | Physical Server | VM — On-Prem | VM — Cloud / Colo |
| --- | --- | --- | --- |
| Physical Location | Required | `N/A` | `N/A` |
| Serial Number | Required | `N/A` | `N/A` |
| MAC Address | Required | `N/A` | `N/A` |
| Warranty Expiration | Required | `N/A` | `N/A` |
| Purchase Date | Required | Required | Required |
| Install Date | Required | Required | Required |
| Operating System | Required | Required | Required |
| Hosting Provider | `N/A` | `N/A` | Required |

A virtual machine is not a physical object. It has no rack position, no
manufacturer serial, no hardware MAC, and no hardware warranty. Flagging those
as gaps produces false positives on every cloud-first client.

### I1 — Device Identity · Critical

`Manufacturer`, `Model`, and `Device Type` must be populated and real.

- **Fail:** any of the three blank, `Unknown`, or a placeholder.
- **Fail:** a value that does not identify the device — e.g. `n/a` in Model.

Without these, nobody can tell what the device is.

### I2 — Location · High

`Site` must be populated. `Physical Location` must be populated **on physical
hardware**.

- **Fail:** `Site` blank. **High.**
- **Fail:** `Physical Location` blank on a physical server. **High** — the field
  team cannot find the device without it.
- **Pass:** `Physical Location` blank or `N/A` on a virtual machine. A VM has no
  rack position.

### I3 — Reachability · High

`IP Address` must be populated.

- **Fail:** blank, `Unknown`, or a placeholder.
- **Note:** `Network Hostname` is **not** checked. IP is the field that matters.

### I4 — Lifecycle · High

`Purchase Date` must be populated. This is a primary purpose of the review —
many clients are missing lifecycle data and it needs correcting.

- **Fail:** `Purchase Date` blank or a placeholder. **High.**
- **Medium:** `Install Date` blank or a placeholder.
- **Low:** `Warranty Expiration Date` blank or expired on physical hardware.
  Warranty is lower priority because we work from licensing more than warranty.
- **Pass:** `Warranty Expiration Date` blank on a virtual machine — a VM has no
  hardware warranty.

### I5 — Hardware Identity · Medium

`Serial Number` and `MAC Address` must be populated **on physical hardware**.

- **Fail:** `Serial Number` blank, `Unknown`, or a placeholder on a physical
  server. **Medium.**
- **Fail:** `MAC Address` blank, `Unknown`, or a placeholder on a physical
  server. **Medium.**
- **Pass:** both blank or `N/A` on a virtual machine. A VM has no manufacturer
  serial and no stable hardware MAC.

Serial is required for RMA and vendor support. MAC is needed by senior engineers
for network troubleshooting and by field engineers on site. Note the layout
inconsistency: Serial is flagged required on Network Devices but not on Servers.
This rubric applies the same standard to both.

### I6 — Platform · Medium · **Servers only**

`Operating System` and `Hosting Provider` must be populated where they apply.

- **Fail:** `Operating System` blank on a server. **Medium.**
- **Fail:** `Hosting Provider` blank on a cloud or colo device. **Medium.**
- **Pass:** `N/A` where the field genuinely does not apply — e.g. Hosting
  Provider on an on-prem physical server.

**Scope:** this component applies to the **Servers** layout only. The Network
Devices layout has no `Operating System` and no `Hosting Provider` field, so I6
cannot pass or fail there. Evaluating it on Network Devices produces a false
pass — a green result that means "nothing could fail," not "documentation is
complete." Skip I6 entirely when the fields are absent from the layout.

### I7 — Layout Correctness · Medium

`UPS` and `UPS Battery` device types do **not** belong in Network Devices. They
belong in Power Management.

- **Fail:** a Network Devices asset whose `Device Type` is `UPS` or `UPS Battery`.

The selector still exists in the layout because everything was documented
together before the split. Any record still using it is misfiled.

### I8 — Controller Placement · Medium · **cross-layout**

A **cloud-managed** network controller belongs in **Applications & Services
(13)**, not Network Devices (4). It is a hosted platform, not a device on the
network.

- **Fail:** a Network Devices record with `Device Type` = `Network Controller`
  that is cloud-hosted.

**Cloud evidence — positive signals only.** A record is treated as cloud when
any of these is true:

| Signal | Example |
| --- | --- |
| `Model` or `Manufacturer` names a cloud platform | `Cloud`, `Meraki`, `Hostifi`, `InstantOn` |
| `IP Address` is a URL rather than an IP | `https://ruckus.cloud` |
| `Physical Location` is `cloud` | `cloud` |

**A local controller is not flagged.** A ZoneDirector, or a Unifi controller
running on a site box, has a real IP and a physical location — it stays in
Network Devices. A controller that is merely *under-documented* (no IP, no
location) is also not flagged: absence of evidence is not evidence of cloud.
This is deliberate, so the check does not fire on every sparse record.

**Half-done moves are called out.** When a matching record already exists in
Applications & Services, the finding says so — the move was started and not
finished. PCPC's `Ruckus ONE` is exactly this case: it exists in both layouts.

**Known limitation.** Cloud detection is heuristic. A cloud platform whose
`Model` does not name it, with no URL and no location, will not be detected.
The signal list above is the authority; extend it when a new platform appears.

---

# Part 2 — Network segments

**Layouts:** LAN (18), WAN (17)

A **LAN** record is a *VLAN / segment* (one broadcast domain). A **WAN** record
is a *carrier circuit*. Neither carries Manufacturer, Model, Device Type, Serial,
or MAC.

## Layout 18 — LAN

### L1 — Segment Identity · Critical

`Subnet` and `VLAN ID` must be populated.

- **Fail:** either blank, `Unknown`, or a placeholder.

Without these, nobody can tell what network a device is on or how to route to it.

### L2 — Site · High

`Site` must be populated.

- **Fail:** no site linked.

### L3 — Gateway & DNS · tiered

`Gateway` and `DNS Server(s)` must be populated.

- **Fail:** `Gateway` blank. **Medium.** The gateway is almost always the `.1`
  of the subnet, so it is inferable — but a blank still costs someone a lookup,
  and the whole team benefits from it being written down.
- **Fail:** `DNS Server(s)` blank. **High.** DNS is not inferable from the
  subnet; a resolver that is not recorded has to be asked for.

### L4 — DHCP · Medium

Enable runs DHCP on **every** network, so a blank DHCP pair is a blind spot, not
a static-only VLAN.

- **Fail:** `DHCP Server` and `DHCP Scope` both blank. **Medium.**
- **Fail:** either one blank while the other is populated. **Medium.**
- **Pass:** both carry a deliberate marker (`N/A`, `NA`, `None`).

**Trigger note:** `DHCP Information` is **not** the trigger. It is a Heading
field, empty on 100% of records in both gold standards. Using it would make L4 a
check that can never fire.

**Review note:** because Enable runs DHCP everywhere, a `None` marker on the DHCP
fields is almost certainly a wrong assertion rather than a real non-applicability.
The rubric accepts the marker (the author stated a position); whether that
position is correct is a human review question.

## Layout 17 — WAN

### W1 — Circuit Identity · Critical

`Vendor`, `Circuit ID`, `Account Number`, and `Contract` must be populated.

- **Fail:** any of the four blank, `Unknown`, or a placeholder.
- **Fail:** `Vendor` or `Contract` with no linked asset.

This is the whole point of a WAN record: without vendor, circuit ID, and account
number you cannot open a carrier ticket, and without the contract you cannot tell
what you are paying for.

### W2 — Site · High

`Site` must be populated.

- **Fail:** no site linked.

### W3 — Transport · High

`Media Type`, `Transport`, and both speed fields must be populated.

- **Fail:** `Media Type`, `Transport`, `Upload Speed (Mbps)`, or
  `Download Speed (Mbps)` blank.

### W4 — Termination · Medium

`Router/Firewall` and `IP Address(es)` must be populated.

- **Fail:** no router/firewall linked.
- **Fail:** `IP Address(es)` blank.

### W5 — Redundancy · Medium

`Redundancy Configuration` must be populated.

- **Fail:** blank, `Unknown`, or a placeholder.

`No Redundancy` is a valid, deliberate answer — it passes. The gap is silence,
not the absence of redundancy.

---

# Part 3 — Wireless

**Layouts:** Wi-Fi (25), SSIDs (29)

Layout 25 is a **wireless system** record — one per controller/system, linking
the controller, the access points, and the SSIDs it serves. Layout 29 is an
**SSID** record — one per broadcast network.

## Layout 25 — Wi-Fi

### WF1 — Site · High

`Site` must be populated.

- **Fail:** no site linked.

### WF2 — Controller · High

`Wireless Controller(s)` must be populated.

- **Fail:** no controller linked.

Without the controller, nobody can manage the system or find the console.

### WF3 — Access Points · High

`Wireless Access Point(s)` must be populated.

- **Fail:** no access point linked.

The APs are the physical hardware. Without them the field team cannot locate or
replace a radio.

### WF4 — SSIDs · Medium

`SSID(s)` must be populated.

- **Fail:** no SSID linked.

### WF5 — Management · Medium

`Management Address` must be populated.

- **Fail:** blank, `Unknown`, or a placeholder.

## Layout 29 — SSIDs

### SS1 — Security Configuration · Critical

`Network Type` and `Security Protocol` must be populated, and must agree.

- **Fail:** either blank, `Unknown`, or a placeholder.
- **Fail:** `Network Type` is `Open` but `Security Protocol` is not `None`.
- **Fail:** `Network Type` is a PSK type but `Security Protocol` is `None`.

An SSID whose security posture is unstated, or self-contradictory, is a
wrong-action risk: an engineer cannot tell whether the network is open.

### SS2 — Passphrase · Critical

Conditional on `Network Type`.

- **Fail:** a PSK network with no passphrase. **Critical** — nobody can join the
  network, and the service desk cannot walk a user through it.
- **Fail:** an `Open` network carrying a passphrase. **Critical** — the record
  contradicts itself; either the network is not open or the passphrase is stale.
- **Pass:** an `Open` network with a blank passphrase. The field genuinely does
  not apply, and the network type already states the posture.

**Review note:** a deliberate marker (`N/A`, `NA`, `None`) on a PSK passphrase is
accepted — the author stated a position — but it is almost certainly a wrong
assertion, since a PSK network by definition has a passphrase. Whether the
passphrase is *withheld* rather than unknown is a human review question.

### SS3 — LAN · High

`LAN` must be populated.

- **Fail:** no LAN linked.

The SSID-to-VLAN mapping is what tells an engineer which network a wireless
client lands on.

### SS4 — Client Isolation · Medium

`Client Isolation` must be populated.

- **Fail:** the field is absent or empty.

`0` (disabled) and `1` (enabled) are both deliberate answers and pass. The gap is
silence, not the setting.

---

# Part 4 — IPMI

**Layout:** IPMI (27)

An IPMI record is an out-of-band management interface (iDRAC, iLO, IPMI) attached
to a server.

### IP1 — Management Interface · High

`Server` and `IP Address` must be populated.

- **Fail:** no server linked.
- **Fail:** `IP Address` blank, `Unknown`, or a placeholder.

The whole purpose of the record is to say which server this management interface
belongs to and how to reach it. Without either, the record is unusable.

---

## Out of scope

- `Network Hostname` — IP is the reachability field that matters.
- `Asset Tag` — only meaningful where the client runs their own tagging system.
- `Purpose` — blank on 100% of records in the gold standard; the field is not
  in use.
- `Installed By`, `Contact`, `Notes`, `Expiry Alert Override`,
  `Automation Control`.
- `Carrier Equipment` (17) — free-text hardware description; the linked
  Router/Firewall (W4) is the structured field that matters.
- `Static IP Assignment Scheme` (18) — free text; not machine-checkable.
- `Switch(es)` (18) — a link, not segment identity. Candidate for a future
  version.
- `Authentication Server` (25) — **dead field.** Empty (`[]`) on 100% of records
  in all three reference companies. Not in use.
- `Passphrase Sharing` (29) — advisory, not a completeness gap. Whether a
  passphrase should be shared is a client-relationship decision.
- **Referential integrity** between layout 25's `SSID(s)` links and the layout 29
  records they point at. Presence is checked (WF4); whether the link resolves is
  a separate cleanup concern.
- **Coverage** — whether the *right number* of records exist. Cannot be
  determined from the KB alone; X1 in `cross-cutting.md` covers only the zero
  case.

### Not findings — data quality

These are real defects but are **not** documentation-completeness gaps, and the
rubric does not flag them. Recorded here so they are not re-litigated:

- A subnet with host bits set (e.g. `10.40.0.1/23`).
- A gateway carrying a CIDR suffix (e.g. `10.0.0.1/22`).
- An abbreviated DHCP scope (e.g. `.3-.254`) or one with stray whitespace.

Subnet **presence** is checked (L1); subnet **correctness** is not.

---

## Changelog

- v0.8 — added I8 (Controller Placement, cross-layout): a cloud-managed network
  controller belongs in Applications & Services, not Network Devices. Positive
  cloud signals only, so local and under-documented controllers are not flagged.
- v0.7 — merged `network-segments.md` (v0.2) and `wireless.md` (v0.1) into this
  file as Parts 2 and 3. Added Part 4 (IPMI, IP1). One rules file per group.
- v0.6 — value semantics corrected: a blank is a blind spot, not a pass. `None`
  joins `N/A`/`NA` as an accepted deliberate marker.
- v0.5 — I6 scoped to Servers only (fields absent on Network Devices). Counting
  rule added: per asset per component.
- v0.4 — device-type conditionals added to I2, I4, I5. Purpose dropped.
- v0.3 — I8 moved to `cross-cutting.md` as X1; applies to all groups.
- v0.2 — scope re-derived against all five documentation audiences. Added
  Physical Location, MAC Address, Operating System, Hosting Provider, Install
  Date, Purpose. Components regrouped.
- v0.1 — initial draft from gold standards 25 / 150, layout definitions, and
  POC article 7970.