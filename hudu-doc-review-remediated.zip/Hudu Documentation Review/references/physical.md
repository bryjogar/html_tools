# Physical — Completeness Rules

**Group:** Physical
**Layouts:** Printers & Scanners (5), Printing (20), Phones (11), Phone Systems (24), Analog Lines (30), Audio Visual (9), Building Automation (8), Building Security (6), Mobile Devices (10), Power Management (36), SSL Certificates (35), Security & Compliance (34)
**Status:** draft v0.3 — pending review
**Gold standards:** company 25 (Park Cities Presbyterian Church), company 150 (Enable Gold Standards)

---

## Purpose

This is a **triage rubric, not a field audit.**

This is the largest group: the physical and facility-side assets. Seven of its
layouts share an identical device field set, so they are covered by one **shared
device core** rather than seven near-identical rule sets. The remaining layouts
are configuration or record layouts and get their own components.

A field is in scope if a documentation audience needs it to do their job.

## Audiences

| Audience | Role | What they need from a physical record |
| --- | --- | --- |
| **Service Desk** | Remote tier 1/2 — user support, ticket triage | What the device is, how to reach it |
| **Support / Field Engineers** | Remote and on-site tier 3/4 | Physical location, hardware identity, serial |
| **Senior Engineers** | Tier 5 — solutions architecture | Platform, network identity, integration |
| **Strategy Consultants** | Long-term planning, budgeting, projects | Lifecycle dates — purchase, install, warranty |

---

## Severity

| Level | Definition | Test |
| --- | --- | --- |
| **Critical** | Blocks service delivery or creates wrong-action risk. | "Would this stop someone doing their job, or make them do it wrong?" |
| **High** | Degrades service quality or slows response. | "Would this cost us time or cause a bad handoff?" |
| **Medium** | Reduces efficiency; causes hunting. | "Would someone have to ask a person instead of reading the KB?" |
| **Low** | Cosmetic or genuinely optional. | "Would anyone notice?" |

**Severities are flattened.** One severity per component. Where the
infrastructure rubric tiered a component (e.g. lifecycle: purchase High, install
Medium, warranty Low), this group uses a single severity for the whole
component. The detail line still lists every missing field.

## Value semantics

| Value | Meaning | Verdict |
| --- | --- | --- |
| `N/A`, `NA`, `None` | Deliberate; the author has stated the field does not apply | **Acceptable** |
| `Unknown` | Admission of ignorance | **Gap** |
| blank / null | Never filled in | **Gap** |
| `TBD`, `-`, `?`, `xxx` | Placeholder | **Gap** |

**A blank is a blind spot, not a pass.** If a field is not relevant, say so with
a deliberate marker. Silence is indistinguishable from an oversight, so it is
always flagged. `N/A`, `NA`, and `None` are the three accepted markers.

## Counting

Findings are counted **per asset per component**, not per field. A printer
missing Manufacturer, Model, and Device Type is **one** PH1 finding, not three.

**Relation fields** (`Site`, `Contact`, `Print Servers`, `Printers`, `Vendor`,
`PSTN Provider`, `Carrier`) are JSON arrays of linked assets. An empty array `[]`
counts as missing, exactly like a blank string.

---

## Shared device core

**Applies to layouts 5, 6, 8, 9, 10, 11, 36.** These layouts carry the same
device field set.

### PH1 — Device Identity · Critical

`Manufacturer`, `Model`, and `Device Type` must be populated and real.

- **Fail:** any of the three blank, `Unknown`, or a placeholder.
- **Fail:** a value that does not identify the device — e.g. `N/A` in Model.

### PH2 — Device Location · High

`Site` and `Physical Location` must be populated.

- **Fail:** `Site` blank or an empty relation.
- **Fail:** `Physical Location` blank.

The field team cannot find the device without it.

### PH3 — Device Reachability · High

`IP Address` must be populated.

- **Fail:** blank, `Unknown`, or a placeholder.

**Mobile Devices (10) is not exempt.** A tablet with no IP is a real gap, not an
accepted condition. Missing data is not the same as `N/A`: a blank shows the
field was never considered. If a device genuinely has no IP, the author must say
so with a deliberate marker.

### PH4 — Device Hardware Identity · Medium

`Serial Number` and `MAC Address` must be populated.

- **Fail:** either blank, `Unknown`, or a placeholder.

Serial is required for RMA and vendor support; MAC is needed for network
troubleshooting and by field engineers on site.

### PH5 — Device Lifecycle · High

`Purchase Date`, `Install Date`, and `Warranty Expiration Date` must be populated.

- **Fail:** any of the three blank or a placeholder.

Flattened from the infrastructure tiering (was High/Medium/Low) to a single High.
Purchase date is the primary purpose of the review — the strategy consultants
need it most of all — so the component stays High. The detail line names which
dates are missing.

**A uniform absence is still a gap.** When every record in a layout is missing
the same field (e.g. all 16 Cityview tablets have no Install Date), that is a
documentation practice that has never been thought about — not a systemic
exception to be coded around. It is reported per record like any other gap.

---

## Layout-specific components

### PH6 — Printer Driver Config · Medium · Printers & Scanners (5)

`Windows Driver Name` and `macOS Driver Name` must be populated.

- **Fail:** either blank.

Without the driver name, a technician cannot reinstall the printer.

### PH7 — Printing Deployment · High · Printing (20)

`Print Servers`, `Printers`, and `Deployment` must be populated.

- **Fail:** any of the three blank or an empty relation.

### PH8 — Phone System Identity · Critical · Phone Systems (24)

`Type`, `Management Address`, and `PSTN Provider` must be populated.

- **Fail:** any of the three blank or an empty relation.

### PH9 — Analog Line Identity · High · Analog Lines (30)

`Phone Number`, `Carrier`, and `Site` must be populated.

- **Fail:** any of the three blank or an empty relation.

### PH10 — Power Device Identity · Critical · Power Management (36)

`Device Type` must be `UPS` or `UPS Battery`, and `Manufacturer` and `Model` must
be populated.

- **Fail:** `Device Type` is not a UPS type — the record is misfiled.
- **Fail:** `Manufacturer` or `Model` blank.

This is the mirror of infrastructure I7: UPS records belong in Power Management,
not in Network Devices.

### PH11 — Certificate Identity · Critical · SSL Certificates (35)

`Common Name`, `Issuer`, and `Cert Expires` must be populated.

- **Fail:** any of the three blank.

### PH12 — Certificate Validity · **OUT OF SCOPE**

Whether a certificate has expired is a **monitoring** concern, not a
documentation-completeness one. The rubric checks that the expiry date is
*recorded* (PH11); it does not evaluate the date. This is the only time-based
check that was proposed, and it is deliberately excluded.

### PH13 — Security Posture · **OUT OF SCOPE**

`Compliance Requirements`, `Antivirus (Workstations)`, and
`Antivirus (Servers)` were drafted as a High component on Security &
Compliance (34) and then withdrawn by decision. The values come from
integrations and advisory tooling often enough that a blank says more about the
integration than about the client's security posture.

The component remains declared in `scripts/rubric.py` with the kind
`out_of_scope` so the decision is recorded in one place rather than deleted. It
is never counted in the completeness figure and never scored. Restoring it means
changing that kind back to `code` and implementing the check.

**Consequence for the report.** Layout 34 now carries no evaluated component at
all. A layout with nothing evaluated is reported as **Not reviewed**, never as
"No findings." An all-clear on a layout nothing looked at is the one thing this
report must not print.

### PH14 — UPS Battery Pairing · High · Power Management (36)

Every UPS record must have a matching UPS Battery record. A UPS without its
battery documented is an incomplete record: the battery is the part that
actually fails and gets replaced.

- **Fail:** a UPS whose name pairs with no UPS Battery record.
- **Pass:** a battery record whose name pairs with the UPS. Matching is by
  normalized name: case and separators are stripped, so `MPC-MDF-UPS01` pairs
  with `MPC-MDF-UPS-01`, and the battery's trailing word — `Battery`,
  `Internal battery`, `External battery`, `Bat` — is removed before comparing.
  Without that normalization a hyphen would split a real pair and report a
  battery that exists as missing.
- **Not a failure:** an unnamed UPS record. Pairing is impossible without a
  name, and the missing name is already an X3 finding. Reporting it here too
  would be a duplicate.

Pairing is by name, which is why a placeholder name hides this gap — see X3 in
`cross-cutting.md`.

---

## Out of scope

- `Notes` — free text, on every layout in this group.
- `Asset Tag` — only meaningful where the client runs their own tagging system.
- `Installed By`, `Contact`, `Purpose` — free text or advisory.
- `Expiry Alert Override`, `Automation Control` — operational settings.
- `Scripted Install`, `Fiery Attached`, `Fiery Model Name`,
  `Install At Sites`, `Windows Driver Settings`, `Default Collate`,
  `Default Black and White`, `Default Duplexing Mode`, `Default Paper Size`,
  `macOS Driver Settings`, `macOS Driver Options` (5) — deployment detail, not
  completeness. The driver *names* (PH6) are what a technician needs.
- `Deployment Strategy`, `Driver Installation Path`, `Support Information` (20)
  — free text.
- `DHCP Options`, `Vendor` (24) — free text or advisory.
- `Certificate Info`, `Certificate`, `Serial`, `Signature Algorithm`,
  `Enhanced Key Usage List`, `Optional Fields`, `Intermediate chain`,
  `Certificate Signing Request`, `Private Key`, `Organization`, `Country`,
  `Subject Alternative Name`, `Enable HTTPS Check` (35) — certificate internals,
  populated automatically or not needed for triage.
- `User Security`, `Workstation/Server Security`, `Network/Cloud Security`,
  `Antivirus Notes`, and the subscription/managed-by pairs (34) — advisory or
  free text. The Security & Compliance layout carries no evaluated component:
  its only candidate, PH13, is withdrawn (above).
- **Workstations (7)** — out of scope entirely. The layout carries no
  Manufacturer, Model, Serial, MAC, IP, Operating System, or Site, so the device
  core cannot be applied. Excluded by decision.
- **Coverage** — whether the *right number* of records exist for the estate.
  Cannot be determined from the KB alone; X1 in `cross-cutting.md` covers only
  the zero case. This does **not** exclude the count checks that are derivable
  from the KB itself: CM9/CM10 compare licensed seats against the device count,
  and PH14 pairs each UPS with its battery record.

---

## Changelog

- v0.3 — PH13 (Security Posture) withdrawn as a component; declared
  `out_of_scope` in `scripts/rubric.py` and never scored. PH14 (UPS Battery
  Pairing) documented: it was implemented in code and referenced from
  `cross-cutting.md` and `SKILL.md` without a rules entry. The per-layout
  "no findings" wording clarified: a layout with nothing evaluated is reported
  as Not reviewed.
- v0.2 — triage pass. PH5 confirmed High (strategy consultants need purchase
dates). Mobile Devices explicitly not exempt from PH3: a uniform absence is a
real gap, not a systemic exception.
- v0.1 — initial draft from gold standards 25 / 150 and reference company 110.
  Shared device core PH1–PH5 (layouts 5, 6, 8, 9, 10, 11, 36); layout-specific
  PH6–PH11, PH13. Severities flattened to one per component. PH12 (certificate
  validity) excluded as a monitoring concern. Workstations (7) excluded by
  decision.